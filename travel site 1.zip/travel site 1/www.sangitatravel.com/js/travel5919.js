String.prototype.trim = function() {
	return this.replace(/^\s+|\s+$/g, "");
};

String.prototype.removeSpaces = function() {
	return this.split(" ").join("");
};

function searchResult(tableid, company, depart, arrive, duration, price, availability)
{
	this.tableid 	= tableid;
	this.company 	= company;
	this.depart 	= depart;
	this.arrive		= arrive;
	this.duration	= duration;
	this.price		= price;
	this.availability=availability;
}

function _sortBycompanyDesc(a, b)
{
	var c1 = a.company.toLowerCase();
	var c2 = b.company.toLowerCase();

	if 		(c1 < c2) { return  1; }
	else if (c1 > c2) { return -1; }
	else {
		var d1 = a.depart.toLowerCase();
		var d2 = b.depart.toLowerCase();

		if 		(d1 < d2) { return -1; }
		else if (d1 > d2) { return 1; }
		else {
			var p1 = parseInt(a.price);
			var p2 = parseInt(b.price);
			if 		(p1 < p2) { return -1; }
			else if (p1 > p2) { return 1; }
			else {
				if (!(a.availability  == "none" || a.availability  == "--") && (b.availability == "none" || b.availability  == "--")) {
					if (a.availability  == "none" || a.availability  == "--")
						return 1;
					else if (b.availability == "none" || b.availability  == "--")
						return -1;
				}
				
				var a1 = parseInt(a.availability);
				var a2 = parseInt(b.availability);
				return ((a1 < a2) ? 1 : ((a1 > a2) ? -1 : 0));
			}
		}
	}
	
	//return ((x < y) ? -1 : ((x > y) ? 1 : 0));
}

function _sortBycompany(a, b)
{
	var c1 = a.company.toLowerCase();
	var c2 = b.company.toLowerCase();

	if (c1 < c2) { return -1; }
	else if (c1 > c2) { return 1; }
	else {
		var d1 = a.depart.toLowerCase();
		var d2 = b.depart.toLowerCase();

		if 		(d1 < d2) { return -1; }
		else if (d1 > d2) { return 1; }
		else {
			var p1 = parseInt(a.price);
			var p2 = parseInt(b.price);
			if 		(p1 < p2) { return -1; }
			else if (p1 > p2) { return 1; }
			else {
				if (!(a.availability  == "none" || a.availability  == "--") && (b.availability == "none" || b.availability  == "--")) {
					if (a.availability  == "none" || a.availability  == "--")
						return 1;
					else if (b.availability == "none" || b.availability  == "--")
						return -1;
				}
				
				var a1 = parseInt(a.availability);
				var a2 = parseInt(b.availability);
				return ((a1 < a2) ? 1 : ((a1 > a2) ? -1 : 0));
			}
		}
	}
	
	//return ((x < y) ? -1 : ((x > y) ? 1 : 0));
}

function _sortBydepartDesc(a, b)
{
	// pushing the zero availability to the bottom
	
	if (a.availability  == "none")
		return 1;
	else if (b.availability == "none")
		return -1;
	
	var d1 = a.depart.toLowerCase();
	var d2 = b.depart.toLowerCase();

	if 		(d1 < d2) { return  1; }
	else if (d1 > d2) { return -1; }
	else {
		var p1 = parseInt(a.price);
		var p2 = parseInt(b.price);
		if 		(p1 < p2) { return -1; }
		else if (p1 > p2) { return 1; }
		else {
			if (!(a.availability  == "none" || a.availability  == "--") && (b.availability == "none" || b.availability  == "--")) {
				if (a.availability  == "none" || a.availability  == "--")
					return 1;
				else if (b.availability == "none" || b.availability  == "--")
					return -1;
			}
			
			var a1 = parseInt(a.availability);
			var a2 = parseInt(b.availability);
			return ((a1 < a2) ? 1 : ((a1 > a2) ? -1 : 0));
		}
	}
	//return ((x < y) ? -1 : ((x > y) ? 1 : 0));
}

function _sortBydepart(a, b)
{
	// pushing the zero availability to the bottom
	
	if (a.availability  == "none")
		return 1;
	else if (b.availability == "none")
		return -1;
	
	var d1 = a.depart.toLowerCase();
	var d2 = b.depart.toLowerCase();

	if 		(d1 < d2) { return -1; }
	else if (d1 > d2) { return 1; }
	else {
		var p1 = parseInt(a.price);
		var p2 = parseInt(b.price);
		if 		(p1 < p2) { return -1; }
		else if (p1 > p2) { return 1; }
		else {
			if (!(a.availability  == "none" || a.availability  == "--") && (b.availability == "none" || b.availability  == "--")) {
				if (a.availability  == "none" || a.availability  == "--")
					return 1;
				else if (b.availability == "none" || b.availability  == "--")
					return -1;
			}
			
			var a1 = parseInt(a.availability);
			var a2 = parseInt(b.availability);
			return ((a1 < a2) ? 1 : ((a1 > a2) ? -1 : 0));
		}
	}
	//return ((x < y) ? -1 : ((x > y) ? 1 : 0));
}

function _sortByarriveDesc(a, b)
{

	if (a.arrive == "-- NA --" && b.arrive != "-- NA --") { return 1; }
	if (b.arrive == "-- NA --" && a.arrive != "-- NA --") { return -1; }
	else {
		var ar1 = a.arrive.toLowerCase();
		var ar2 = b.arrive.toLowerCase();

		if 		(ar1 < ar2) { return  1; }
		else if (ar1 > ar2) { return -1; }
		else {
			var d1 = a.depart.toLowerCase();
			var d2 = b.depart.toLowerCase();

			if 		(d1 < d2) { return -1; }
			else if (d1 > d2) { return 1; }
			else {
				var p1 = parseInt(a.price);
				var p2 = parseInt(b.price);
				if 		(p1 < p2) { return -1; }
				else if (p1 > p2) { return 1; }
				else {
					if (!(a.availability  == "none" || a.availability  == "--") && (b.availability == "none" || b.availability  == "--")) {
						if (a.availability  == "none" || a.availability  == "--")
							return 1;
						else if (b.availability == "none" || b.availability  == "--")
							return -1;
					}
					
					var a1 = parseInt(a.availability);
					var a2 = parseInt(b.availability);
					return ((a1 < a2) ? 1 : ((a1 > a2) ? -1 : 0));
				}
			}
		}
	} 
	/*
	if (a.arrive == b.arrive && b.arrive == "-- NA --") return 0;
	if (a.arrive == "-- NA --") return 1;
	else if (b.arrive == "-- NA --") return -1;
	*/
	//return ((x < y) ? -1 : ((x > y) ? 1 : 0));
}


function _sortByarrive(a, b)
{

	if (a.arrive == "-- NA --" && b.arrive != "-- NA --") { return 1; }
	if (b.arrive == "-- NA --" && a.arrive != "-- NA --") { return -1; }
	else {
		var ar1 = a.arrive.toLowerCase();
		var ar2 = b.arrive.toLowerCase();

		if 		(ar1 < ar2) { return -1; }
		else if (ar1 > ar2) { return  1; }
		else {
			var d1 = a.depart.toLowerCase();
			var d2 = b.depart.toLowerCase();

			if 		(d1 < d2) { return -1; }
			else if (d1 > d2) { return 1; }
			else {
				var p1 = parseInt(a.price);
				var p2 = parseInt(b.price);
				if 		(p1 < p2) { return -1; }
				else if (p1 > p2) { return 1; }
				else {
					if (!((a.availability  == "none" || a.availability  == "--") && (b.availability == "none" || b.availability  == "--"))) {
						if (a.availability  == "none" || a.availability  == "--")
							return 1;
						else if (b.availability == "none" || b.availability  == "--")
							return -1;
					}
					
					var a1 = parseInt(a.availability);
					var a2 = parseInt(b.availability);
					return ((a1 < a2) ? 1 : ((a1 > a2) ? -1 : 0));
				}
			}
		}
	} 
	/*
	if (a.arrive == b.arrive && b.arrive == "-- NA --") return 0;
	if (a.arrive == "-- NA --") return 1;
	else if (b.arrive == "-- NA --") return -1;
	*/
	//return ((x < y) ? -1 : ((x > y) ? 1 : 0));
}

function _sortBydurationDesc(a, b)
{
	if (a.duration == "-- NA --" && b.duration != "-- NA --") { return 1; }
	if (b.duration == "-- NA --" && a.duration != "-- NA --") { return -1; }
	else {
		var dr1 = a.duration.toLowerCase();
		var dr2 = b.duration.toLowerCase();

		if 		(dr1 < dr2) { return  1; }
		else if (dr1 > dr2) { return -1; }
		else {
			var d1 = a.depart.toLowerCase();
			var d2 = b.depart.toLowerCase();

			if 		(d1 < d2) { return -1; }
			else if (d1 > d2) { return 1; }
			else {
				var p1 = parseInt(a.price);
				var p2 = parseInt(b.price);
				if 		(p1 < p2) { return -1; }
				else if (p1 > p2) { return 1; }
				else {
					if (!(a.availability  == "none" || a.availability  == "--") && (b.availability == "none" || b.availability  == "--")) {
						if (a.availability  == "none" || a.availability  == "--")
							return 1;
						else if (b.availability == "none" || b.availability  == "--")
							return -1;
					}
					
					var a1 = parseInt(a.availability);
					var a2 = parseInt(b.availability);
					return ((a1 < a2) ? 1 : ((a1 > a2) ? -1 : 0));
				}
			}
		}
	}
}

function _sortByduration(a, b)
{
	if (a.duration == "-- NA --" && b.duration != "-- NA --") { return 1; }
	if (b.duration == "-- NA --" && a.duration != "-- NA --") { return -1; }
	else {
		var dr1 = a.duration.toLowerCase();
		var dr2 = b.duration.toLowerCase();

		if 		(dr1 < dr2) { return -1; }
		else if (dr1 > dr2) { return  1; }
		else {
			var d1 = a.depart.toLowerCase();
			var d2 = b.depart.toLowerCase();

			if 		(d1 < d2) { return -1; }
			else if (d1 > d2) { return 1; }
			else {
				var p1 = parseInt(a.price);
				var p2 = parseInt(b.price);
				if 		(p1 < p2) { return -1; }
				else if (p1 > p2) { return 1; }
				else {
					if (!(a.availability  == "none" || a.availability  == "--") && (b.availability == "none" || b.availability  == "--")) {
						if (a.availability  == "none" || a.availability  == "--")
							return 1;
						else if (b.availability == "none" || b.availability  == "--")
							return -1;
					}
					
					var a1 = parseInt(a.availability);
					var a2 = parseInt(b.availability);
					return ((a1 < a2) ? 1 : ((a1 > a2) ? -1 : 0));
				}
			}
		}
	} 

/*
	if (a.duration == b.duration && b.duration == "-- NA --") return 0;
	if (a.duration == "-- NA --") return 1;
	else if (b.duration == "-- NA --") return -1;
	
	var x = a.duration.toLowerCase();
	var y = b.duration.toLowerCase();
	return ((x < y) ? -1 : ((x > y) ? 1 : 0));
*/
}

function _sortBypriceDesc(a, b)
{
	var p1 = parseInt(a.price);
	var p2 = parseInt(b.price);

	if 		(p1 < p2) { return  1; }
	else if (p1 > p2) { return -1; }
	else {
		var d1 = a.depart.toLowerCase();
		var d2 = b.depart.toLowerCase();
	
		if 		(d1 < d2) { return -1; }
		else if (d1 > d2) { return 1; }
		else {
			if (!(a.availability  == "none" || a.availability  == "--") && (b.availability == "none" || b.availability  == "--")) {
				if (a.availability  == "none" || a.availability  == "--")
					return 1;
				else if (b.availability == "none" || b.availability  == "--")
					return -1;
			}
				
			var a1 = parseInt(a.availability);
			var a2 = parseInt(b.availability);
			return ((a1 < a2) ? 1 : ((a1 > a2) ? -1 : 0));
		}
	}

	var x = parseInt(a.price);
	var y = parseInt(b.price);
	
	//return ((x < y) ? -1 : ((x > y) ? 1 : 0));
}

function _sortByprice(a, b)
{
	var p1 = parseInt(a.price);
	var p2 = parseInt(b.price);

	if 		(p1 < p2) { return -1; }
	else if (p1 > p2) { return 1; }
	else {
		var d1 = a.depart.toLowerCase();
		var d2 = b.depart.toLowerCase();
	
		if 		(d1 < d2) { return -1; }
		else if (d1 > d2) { return 1; }
		else {
			if (!(a.availability  == "none" || a.availability  == "--") && (b.availability == "none" || b.availability  == "--")) {
				if (a.availability  == "none" || a.availability  == "--")
					return 1;
				else if (b.availability == "none" || b.availability  == "--")
					return -1;
			}
				
			var a1 = parseInt(a.availability);
			var a2 = parseInt(b.availability);
			return ((a1 < a2) ? 1 : ((a1 > a2) ? -1 : 0));
		}
	}

	var x = parseInt(a.price);
	var y = parseInt(b.price);
	
	//return ((x < y) ? -1 : ((x > y) ? 1 : 0));
}

function _sortByavailabilityDesc(a, b)
{
	a.availability = a.availability == "none" ? -1 : a.availability; 
	a.availability = a.availability == "--" ? 0 : a.availability;

	b.availability = b.availability == "none" ? -1 : b.availability; 
	b.availability = b.availability == "--" ? 0 : b.availability;
	
	var a1 = parseInt(a.availability);
	var a2 = parseInt(b.availability);

	if 		(a1 < a2) { return -1; }
	else if (a1 > a2) { return  1; }
	else {
		var d1 = a.depart.toLowerCase();
		var d2 = b.depart.toLowerCase();

		if 		(d1 < d2) { return -1; }
		else if (d1 > d2) { return 1; }
		else {
			var p1 = parseInt(a.price);
			var p2 = parseInt(b.price);
			return ((p1 < p2) ? -1 : ((p1 > p2) ? 1 : 0));
		}
	}
	// return ((x < y) ? 1 : ((x > y) ? -1 : 0));
}

function _sortByavailability(a, b)
{
	a.availability = a.availability == "none" ? -1 : a.availability; 
	a.availability = a.availability == "--" ? 0 : a.availability;

	b.availability = b.availability == "none" ? -1 : b.availability; 
	b.availability = b.availability == "--" ? 0 : b.availability;
	
	var a1 = parseInt(a.availability);
	var a2 = parseInt(b.availability);

	if 		(a1 < a2) { return 1; }
	else if (a1 > a2) { return -1; }
	else {
		var d1 = a.depart.toLowerCase();
		var d2 = b.depart.toLowerCase();

		if 		(d1 < d2) { return -1; }
		else if (d1 > d2) { return 1; }
		else {
			var p1 = parseInt(a.price);
			var p2 = parseInt(b.price);
			return ((p1 < p2) ? -1 : ((p1 > p2) ? 1 : 0));
		}
	}
	// return ((x < y) ? 1 : ((x > y) ? -1 : 0));
}

function changeTravelMode()
{
	
	if ($("#hop").val() == "onehop")
	{
		loadToCities($("#fromCity").val());
		$("#hop").val("direct");
	}
	if($("input:radio[name=mode]:checked").val() == 'roundtrip')
	{
		//$("#returnDateContainer").removeClass('displayNone');
		$("#returnDateContainer").show();
	}
	else
	{
		//$("#returnDateContainer").addClass('displayNone');
		$("#returnDateContainer").hide();
	}
}


function changeHopMode()
{
	$("#returnDateContainer").hide();
    $("#toCity").html($("#fromCity").html());
    $("#toCity").val("2434|ahmedabad");
    $("#hop").val("onehop");
}

function loadToCities(fromCityID, toCityID)
{
	if($("input:radio[name=mode]:checked").val() == 'onehop') {	return;	}

	if(fromCityID=="") { return; }
	var prevToCity = $('#toCity').val();
	
	$('#toCity').empty();
	$('#toCity').append('<option value="0">Loading...</option>');
	fromCityID = fromCityID.split('|')[0];
	$.ajax({
		url: '/resource/GetToCities/'+fromCityID,
		dataType: "html",
		data: {
			out: 'html',
			ajx: 1
		},
		success: function( htm ) {
			$('#toCity').empty();
			$('#toCity').append(htm);
			if($('#toCity option[value="'+prevToCity+'"]').length > 0)
				$("#toCity").val(prevToCity).attr("selected", "selected");			
			if(typeof toCityID != 'undefined'){
				$("#toCity").val(toCityID).attr("selected", "selected");			
			}
			if(typeof(ty) != 'undefined'){
				if(typeof(ty.home) != 'undefined' && ty.home.data.combobox){
					$("#toCity").trigger("chosen:updated");
				}				
			}
		}
	});
}

function loadCities_crs2(allCities)
{
	var i=0;
	var firstcity = "";
	for(ct in allCities)
	{
		i++;
		var arrFromCity = eval(allCities[ct]);
		if(i == 1){
			firstcity = ct+"|"+arrFromCity["Name"];
			$('#fromCity').append("<option selected value='"+ct+"|"+arrFromCity["Name"]+"'>"+arrFromCity["Name"]+"</option>");
		}else{
			var arrFromCity = eval(allCities[ct]);
			$('#fromCity').append("<option value='"+ct+"|"+arrFromCity["Name"]+"'>"+arrFromCity["Name"]+"</option>");
		}
		
	}
	loadToCities_crs2(firstcity, allCities);
}

function loadToCities_crs2(fromCityValue, allCities)
{
	var fromCityID = fromCityValue.split("|")[0];
	var arr = eval(allCities[fromCityID]);
	var arrToCity = eval(arr["ToCities"]);
	$('#toCity').find('option').remove().end();
	for(ct in arrToCity)
	{
		$('#toCity').append("<option value='"+ct+"|"+arrToCity[ct]+"'>"+arrToCity[ct]+"</option>");
	}
	$('select#toCity>option').tsort();
}

function loadCities_crs2_new(allCities)
{
	$('#fromCity').empty();
	var i=0;
	var firstcity = "";
	for(ct in allCities)
	{
		i++;
		var arrFromCity = eval(allCities[ct]);
		if(i == 1){
			firstcity = ct+"|"+arrFromCity["Name"];
			$('#fromCity').append("<option selected value='"+ct+"|"+arrFromCity["Name"]+"'>"+arrFromCity["Name"]+"</option>");
		}else{
			var arrFromCity = eval(allCities[ct]);
			$('#fromCity').append("<option value='"+ct+"|"+arrFromCity["Name"]+"'>"+arrFromCity["Name"]+"</option>");
		}
		
	}
	$('select#fromCity>option').tsort();
	loadToCities_crs2(firstcity, allCities);
}

function loadToCities_crs2_new(fromCityValue)
{   
	var i=0;
	var firstcity = "";
	for(ct in allCities)
	{
		i++;
		var arrFromCity = eval(allCities[ct]);		
	}
	var fromCityID = fromCityValue.split("|")[0];
	var arr = eval(allCities[fromCityID]);
	if(typeof arr == 'undefined')
		return;
	var arrToCity = eval(arr["ToCities"]);
	$('#toCity').find('option').remove().end();
	for(ct in arrToCity)
	{
		$('#toCity').append("<option value='"+ct+"|"+arrToCity[ct]+"'>"+arrToCity[ct]+"</option>");
	}
	$('select#toCity>option').tsort();
}

function loadFromCities()
{
	$('#fromCity').empty();
	$('#fromCity').append('<option value="0">Loading...</option>');
	$.ajax({
		url: '/resource/GetFromCities/',
		dataType: "html",
		data: {
			out: 'html',
			ajx: 1
		},
		success: function( htm ) {
			$('#fromCity').empty();
			$('#fromCity').append(htm)
		}
	})
	loadToCities('2434');
}

/**
 * display pickUp details popup
 * @param routeScheduleId - the routeId to get the details for
 */
function showPickupDetails(routeScheduleId)
{
	if(!$("#pickupDetails_"+routeScheduleId).length){
	$.ajax({
		url: '/resource/GetPickups/'+routeScheduleId,
		dataType: "html",
		data: {
			out: 'html',
			ajx: 1
		},
		success: function( htm ) {
			$('#cache_pickupDetails').append(htm);
			openDialog();
		}
	})
	} else openDialog();
	
	function openDialog(){
		// close the message overlay
		var oOverlay = document.getElementById("routeDetailsOverlay");
		if(oOverlay) { $(oOverlay).dialog("close"); }
		
		$.fx.speeds._default = 1000;
		$( "#pickupDetails_"+routeScheduleId ).dialog({
			 autoOpen: false
			,show: "slide"
			,hide: "fade"
			,width: "auto"
			,modal:true
			,dialogClass: 'noTitleForDialog'
		});

		$( "#pickupDetails_"+routeScheduleId ).dialog( "open" );
	}
}

var seatReadOnly = false;
var maxSeatsToSelect = 6;
var totalSeatsSelected = 0;
var totalSeatPrice = 0;
var seatsSelected = new Array();

function selectSeat_leg1(el)
{
	selectSeat(el, 1);
}

function selectSeat_leg2(el)
{
	selectSeat(el, 2);
}

// escape normal css selector chars within jquery string
// this will be needed if the "id" attribute has css-selector chars 
function jq(string)
{ 
	return string.replace(/(:|\.|\(|\))/g,'\\$1');
}

function selectSeat(el, leg)
{
	if (!leg)
		leg = "";
	if(seatReadOnly) return;
	var type = "seater";
	var rsId = $(el).attr("rs_id");		// route schedule id
	var opHadDiscountPolicy = $('#bookTicket_'+rsId+' input[name="opHasDiscountPolicy"]').val();
	if(opHadDiscountPolicy === 'undefined')
		opHadDiscountPolicy = false;
	var opDiscountAmt = $('#bookTicket_'+rsId+' input[name="opDiscountAmt"]').val();
	var opDiscountPer = $('#bookTicket_'+rsId+' input[name="opDiscountPer"]').val();
	var chkbox = jq('#seat_'+rsId+"_"+$(el).attr("seat_no"));
	var companyID = $('#'+rsId).data('company_id');
	var isServiceChargeProvided = true;
	if(ty.inventory != 'crs'){
		var gdsSChargePCT = $('#seatArrangement_'+rsId+' form input[name="serviceChargePCT"]').val();
		if(gdsSChargePCT == '0.00')
			isServiceChargeProvided = false;
	}	

	// identify horiz sleeper
	if($(el).attr("colspan") == 2) { type = "sleeper_h"; }
	// identify vertical sleeper
	else if($(el).attr("rowspan") == 2) { type = "sleeper_v"; }

	// if first seat being selected, then init
	if(seatsSelected[rsId] === undefined)
	{
		seatsSelected[rsId] = new Array();
		seatsSelected[rsId]['totalSeats'] = 0;
		seatsSelected[rsId]['totalPrice'] = 0;
		seatsSelected[rsId]['opDiscountPrice'] = 0;
		seatsSelected[rsId]['serviceTax'] = 0;
		seatsSelected[rsId]['serviceCharge'] = 0;
		seatsSelected[rsId]['inp_gender'] = new Array();
	}

	var seatno = $(chkbox).val();
	var seatno2 = $(chkbox).val().removeSpaces(); // html ID attribs can't have spaces...
	var fare = parseInt($(chkbox).attr('fare'));
	var is_ac = parseInt($(chkbox).attr('is_ac'));
	var is_sleeper = parseInt($(chkbox).attr('is_sleeper'));
	var hasSTax = parseInt($(chkbox).attr('hasSTax'));
	var serviceTax = parseInt($(chkbox).attr('serviceTax'));
	var hasSCharge = parseInt($(chkbox).attr('hasSCharge'));
	var serviceCharge = parseInt($(chkbox).attr('serviceCharge'));

	if(hasSCharge && isServiceChargeProvided){
		fare = fare - serviceCharge;
	}
	
	if(hasSTax){
		if(companyID != 'undefined' && companyID == 11 && ty.inventory != 'undefined' && ty.inventory == 'crs')
			fare = Math.floor(fare/(1 + ty.search.serviceTax * 0.01));
		else
			fare = parseInt(fare - serviceTax);
		if(opHadDiscountPolicy){
			strikeclass = 'strike';
			if(opDiscountAmt > 0){
				var opDiscountPrice = fare - opDiscountAmt;
			}else{
				var opDiscountPrice = fare - Math.floor(fare*opDiscountPer/100);				
			}
			if(companyID != 'undefined' && companyID == 11 && ty.inventory != 'undefined' && ty.inventory == 'crs')
				var serviceTaxPerPax = Math.ceil(opDiscountPrice/100*ty.search.serviceTax);
			else
				var serviceTaxPerPax = serviceTax;
		}else{
			if(companyID != 'undefined' && companyID == 11 && ty.inventory != 'undefined' && ty.inventory == 'crs')
				var serviceTaxPerPax = Math.ceil(fare/100*ty.search.serviceTax);
			else
				var serviceTaxPerPax = serviceTax;
		}				
	}else{
		var serviceTaxPerPax = 0;
	}
		
	// click event is on <TD> elem; hence, check/uncheck the chkbox through script 
	if($(chkbox).attr('checked') == true)
	{
		$(chkbox).attr('checked', false);
		seatsSelected[rsId]['totalSeats'] -= 1;
		if(seatsSelected[rsId]['totalSeats'] < 0){
			seatsSelected[rsId]['totalSeats'] = 0;
			seatsSelected[rsId]['opDiscountPrice'] = 0;
		}
	}
	else
	{
		// max of 6 seats can be chosen..
		if(seatsSelected[rsId]['totalSeats'] < maxSeatsToSelect) { $(chkbox).attr('checked', true); }
		else { return; }
	}

	// if seat selected..
	if($(chkbox).attr('checked') == true)
	{
		seatsSelected[rsId]['totalSeats'] += 1;
		seatsSelected[rsId]['totalPrice'] += fare;
		seatsSelected[rsId]['serviceTax'] += serviceTaxPerPax;
		seatsSelected[rsId]['serviceCharge'] += serviceCharge;
		var strikeclass = '';
		if(opHadDiscountPolicy){
			strikeclass = 'strike';
			if(opDiscountAmt > 0){
				seatsSelected[rsId]['opDiscountPrice'] += +fare - opDiscountAmt;
			}else{
				seatsSelected[rsId]['opDiscountPrice'] += +fare - Math.floor(fare*opDiscountPer/100);
			}
		}
		
		//dynamically add heading for seat's info block
		if(seatsSelected[rsId]['totalSeats'] == 1 || $('#seathead_container_'+rsId).length == 0)
		{
			var seatheadInfo="<div id='seathead_container_"+rsId+"' style='height:20px;width:260px;position:relative;left:-65px;'>";
			if(ty.inventory == 'crs')
				seatheadInfo +="<div style='float:left;color:#f00; width:5px; margin-right: 13px;'><span class='alertNumber'>4</span></div>";
			else
				seatheadInfo +="<div style='float:left;color:#f00; width:5px; margin-right: 13px;'><span class='alertNumber'>3</span></div>";
			seatheadInfo +="<div style='float:left; width:50px;'>&nbsp;Gender</div>";
			seatheadInfo +="<div style='float:left;width:50px;'>Seat No</div>";
	    	seatheadInfo +="<div style='float:left;width:40px;'>Fare</div>";
	    	if( (companyID == 16 || companyID == 1171 || companyID == 2563) && (opHadDiscountPolicy == true)){
	    		seatheadInfo +="<div style='float:left;width:40px;'>Disc.</div>";
	    		$("#booking_header_container_"+rsId).find("td.seat-chart").attr('width','58%');
	    		$("#seathead_container_"+rsId).css('width','310px');
	    	}
	    	if( (ty.inventory == 'crs' && companyID!=11 && companyID!=570 && companyID!=15 && companyID!=257 && companyID!=1030 && companyID!=309 && companyID!=402 && companyID!=169) || (ty.inventory != 'crs' && companyID!=3928 && companyID!=3930) )
	    		seatheadInfo +="<div style='float:left;width:100px;'>GST+SCharge</div>";
	    	else
	    		seatheadInfo +="<div style='float:left;width:100px;'>GST</div>";
			$("#booking_header_container_"+rsId).append(seatheadInfo);
			if( (companyID == 16 || companyID == 1171 || companyID == 2563) && (opHadDiscountPolicy == true)){	    		
	    		$("#seathead_container_"+rsId).css('width','310px');
	    	}
		}
		
		// dynamically add this seat's info block 
		var seatInfo	 = "<div id='seat_selected_container_"+rsId+"_"+seatno2+"' style='height:22px;position:relative;left:-50px;'>";
		seatInfo        += "    <span style='color:#f00; width:3px;'>*</span>";
		seatInfo		+= "	<select name='gender"+leg+"[]' style='width:45px;' id='req_gender_"+rsId+"_"+seatno2+"'><option value=''>--</option><option value='M'>M</option><option value='F'>F</option></select>";
		seatInfo		+= "	<input type='text' name='dummy_seat"+leg+"[]' value='"+seatno+"' readonly='readonly' style='width:40px;background-color:#f2efef;border:0;padding:2px 0; text-align:center;' />";
		seatInfo		+= "	<input type='text' name='dummy_price"+leg+"[]' value='"+fare+"' readonly='readonly' style='width:40px;background-color:#f2efef;border:0;padding:2px 0; text-align:center;' />";
		if( (companyID == 16 || companyID == 1171 || companyID == 2563) && (opHadDiscountPolicy == true)){
			if(opDiscountAmt > 0){
				seatInfo		+= "	<input type='text' name='dummy_discprice2"+leg+"[]' value='"+(opDiscountAmt)+"' readonly='readonly' style='width:40px;background-color:#f2efef;border:0;padding:2px 0; text-align:center;' />";
			}else{
				seatInfo		+= "	<input type='text' name='dummy_discprice2"+leg+"[]' value='"+(Math.floor(fare*opDiscountPer/100))+"' readonly='readonly' style='width:40px;background-color:#f2efef;border:0;padding:2px 0; text-align:center;' />";
			}
			
		}
		if((ty.inventory == 'crs' && companyID==11 || companyID==15 || companyID==570 || companyID==257 || companyID==1030 || companyID==309 || companyID==402 || companyID==169) || (ty.inventory != 'crs' && companyID==3928 || companyID==3930)){
			seatInfo		+= "	<input type='text' name='dummy_serviceTaxCharge"+leg+"[]' value='"+(serviceTaxPerPax)+"' readonly='readonly' style='width:80px;background-color:#f2efef;border:0;padding:2px 0; text-align:center;' />";
		}else{
			seatInfo		+= "	<input type='text' name='dummy_serviceTaxCharge"+leg+"[]' value='"+(serviceTaxPerPax+serviceCharge)+"' readonly='readonly' style='width:80px;background-color:#f2efef;border:0;padding:2px 0; text-align:center;' />";
		}
		seatInfo		+= "	<input type='hidden' name='dummy_serviceTax"+leg+"[]' value='"+serviceTaxPerPax+"' />";
		seatInfo		+= "	<input type='hidden' name='isSleeper"+leg+"[]' value='"+is_sleeper+"' />";
		seatInfo		+= "	<input type='hidden' name='isAC"+leg+"[]' value='"+is_ac+"' />";
		seatInfo		+= "	<input type='hidden' name='hasSTax"+leg+"[]' value='"+hasSTax+"' />";
		seatInfo		+= "	<input type='hidden' name='serviceTax"+leg+"[]' value='"+serviceTax+"' />";
		seatInfo		+= "	<input type='hidden' name='serviceCharge"+leg+"[]' value='"+serviceCharge+"' />";
		seatInfo		+= "</div>";
		$("#booking_container_"+rsId).append(seatInfo);
		if( (companyID == 16 || companyID == 1171 || companyID == 2563) && (opHadDiscountPolicy == true)){	    		
    		$("#booking_container_"+rsId).css('width','310px');
    	}
		
		// store the selected seat's gender inp field
		seatsSelected[rsId]['inp_gender'][seatsSelected[rsId]['inp_gender'].length] = "req_gender_"+rsId+"_"+seatno2;
		
		// if this is the first seat chosen, then add the totalling data-row
		if(seatsSelected[rsId]['totalSeats'] == 1 || $('#total_container_'+rsId).length == 0)
		{
			var totalInfo	 = "<div id='total_container_"+rsId+"' style='height:25px;width:200px;position:relative;left:31px;'>";
			totalInfo		+= "<div style='width:55px;float:left;text-align:center;font-size:12px;font-weight:bold;height:20px;color: #6C6C6C;'>Total:</div>";
			totalInfo		+= "	<input type='text' name='totalSeats"+leg+"' id='totalSeats_"+rsId+"' value='"+seatsSelected[rsId]['totalSeats']+"' readonly='readonly' style='width:40px;background-color:#f2efef;border:0;padding:2px 0; text-align:center;' />";
			if( (ty.inventory == 'crs' && (companyID==11 || companyID==15 || companyID==570 || companyID==257 || companyID==1030 || companyID==309 || companyID==402 || companyID==169)) || (ty.inventory != 'crs' && (companyID==3928 || companyID==3930)) ){
				var totalPriceWithSTax = seatsSelected[rsId]['totalPrice'] + seatsSelected[rsId]['serviceTax'];
			}else{
				var totalPriceWithSTax = seatsSelected[rsId]['totalPrice'] + seatsSelected[rsId]['serviceTax'] + seatsSelected[rsId]['serviceCharge'];
			}
			totalInfo		+= " <input type='text' name='totalPriceWithSTaxCharge"+leg+"' id='totalPriceWithSTaxCharge_"+rsId+"' value='"+totalPriceWithSTax+"' readonly='readonly' class='"+strikeclass+"' style='width:40px;background-color:#f2efef;border:0;padding:2px 0; text-align:center;' />";
			totalInfo		+= " <input type='hidden' name='totalPrice"+leg+"' id='totalPrice_"+rsId+"' value='"+totalPriceWithSTax+"' />";
			if(opHadDiscountPolicy){
				if( (ty.inventory == 'crs' && (companyID==11 || companyID==15 || companyID==570 || companyID==257 || companyID==1030 || companyID==309 || companyID==402 || companyID==169)) || (ty.inventory != 'crs' && (companyID==3928 || companyID==3930)) )
					var totalPriceAfterDiscount = seatsSelected[rsId]['opDiscountPrice'] + seatsSelected[rsId]['serviceTax'];
				else
					var totalPriceAfterDiscount = seatsSelected[rsId]['opDiscountPrice'] + seatsSelected[rsId]['serviceTax'] + seatsSelected[rsId]['serviceCharge'];
				totalInfo		+= "	<div style='display:inline; width:40px;' id='totalOpDiscountPrice_"+rsId+"' class='opTotalDiscount'>"+totalPriceAfterDiscount+"</div>";
			}
			totalInfo		+= "</div>";
			$("#booking_footer_container_"+rsId).append(totalInfo);
		}
		
		// based on the type, display relevant icons
		if(type == "seater") { $(jq("#slot_"+rsId+"_"+seatno2)).removeClass("seat_unbooked").addClass("seat_selected"); }
		else if(type == "sleeper_h") { $(jq("#slot_"+rsId+"_"+seatno2)).removeClass("sleeper_unbooked").addClass("sleeper_selected"); }
		else { $(jq("#slot_"+rsId+"_"+seatno2)).removeClass("sleeper_unbooked_v").addClass("sleeper_selected_v"); }
	}
	// if seat is unselected
	else
	{
		seatsSelected[rsId]['totalPrice'] -= +fare;
		seatsSelected[rsId]['serviceTax'] -= serviceTaxPerPax;
		seatsSelected[rsId]['serviceCharge'] -= serviceCharge;
		if(opHadDiscountPolicy){
			if(opDiscountAmt > 0){
				seatsSelected[rsId]['opDiscountPrice'] -= +fare - opDiscountAmt;
			}else{
				seatsSelected[rsId]['opDiscountPrice'] -= fare - Math.floor(fare*opDiscountPer/100);
			}
		}
		if(seatsSelected[rsId]['totalPrice'] < 0 || seatsSelected[rsId]['totalPrice'] == NaN) {
			seatsSelected[rsId]['totalPrice'] = 0;
			seatsSelected[rsId]['opDiscountPrice'] = 0;
			seatsSelected[rsId]['serviceTax'] = 0;
			seatsSelected[rsId]['serviceCharge'] = 0;
		}

		// all this circus 'cos we can't validate dynamically added inp elements in jQ..
		// so we store the gender IDs in an array on selection; & remove on de-selection
		var dummy_inp_gender = new Array();
		$.each(seatsSelected[rsId]['inp_gender'], function(key, value) { 
			if(value != "req_gender_"+rsId+"_"+seatno2) { dummy_inp_gender[dummy_inp_gender.length] = value; }
		});
		seatsSelected[rsId]['inp_gender'] = dummy_inp_gender;

		// remove the seat info block..
		$(jq("#seat_selected_container_"+rsId+"_"+seatno2)).remove();
		
		// based on the type, display rlevant icons
		if(type == "seater") { $(jq("#slot_"+rsId+"_"+seatno2)).removeClass("seat_selected").addClass("seat_unbooked"); }
		else if(type == "sleeper_h") { $(jq("#slot_"+rsId+"_"+seatno2)).removeClass("sleeper_selected").addClass("sleeper_unbooked"); }
		else { $(jq("#slot_"+rsId+"_"+seatno2)).removeClass("sleeper_selected_v").addClass("sleeper_unbooked_v"); }
	}
	
	// if all seats have been removed from selection, then remove the totalling block
	if(seatsSelected[rsId]['totalSeats'] <= 0)
	{
		$("#total_container_"+rsId).remove();
		$("#seathead_container_"+rsId).remove();
	}
	// otherwise update totalling block..
	else
	{
		var totalPriceWithSTax = seatsSelected[rsId]['totalPrice'] + seatsSelected[rsId]['serviceTax'];
		var totalPriceAfterDiscount = seatsSelected[rsId]['opDiscountPrice'] + seatsSelected[rsId]['serviceTax'];
		$("#totalPrice_"+rsId).val(totalPriceWithSTax);
		if( (ty.inventory == 'crs' && (companyID==11 || companyID==15 || companyID==570 || companyID==257 || companyID==1030 || companyID==309 || companyID==402 || companyID==169)) || (ty.inventory != 'crs' && (companyID==3928 || companyID==3930)) )
			$("#totalPriceWithSTaxCharge_"+rsId).val(totalPriceWithSTax);
		else
			$("#totalPriceWithSTaxCharge_"+rsId).val(totalPriceWithSTax+seatsSelected[rsId]['serviceCharge']);
		if(opHadDiscountPolicy){
			if( (ty.inventory == 'crs' && (companyID==11 || companyID==15 || companyID==570 || companyID==257 || companyID==1030 || companyID==309 || companyID==402 || companyID==169)) || (ty.inventory != 'crs' && (companyID==3928 || companyID==3930)) )
				$("#totalOpDiscountPrice_"+rsId).text(totalPriceAfterDiscount);
			else
				$("#totalOpDiscountPrice_"+rsId).text(totalPriceAfterDiscount+seatsSelected[rsId]['serviceCharge']);
		}			
		$("#totalSeats_"+rsId).val(seatsSelected[rsId]['totalSeats']);
	}
}

function loadPaymentProviders(method)
{
	$('#provider').empty();
	$('#provider').append($('#'+method+'_provider').html());
	$('#provider').show();
}

// if displayed rows <= 2, then display a block at the bottom to negate page jerk behaviour due to scrollbar
function displayBottomHeight()
{
	if($("tr[name='busResults']:visible").length <= 2) { $("#addHeight").show(); }
	else { $("#addHeight").hide(); }
}

function displayNoRoutesMessage()
{
    if($("tr[name='busResults']:visible").length == 0) { $("#noBusResultsAfterFilter").show(); }
    else { $("#noBusResultsAfterFilter").hide(); }
}

/* FILTERS */

function filterSearchResults()
{
	// hide all the charts
	hideAllCharts();
    
	var show_city1 = $('#filter_city1').attr('checked');
    var city1 = $('#filter_city1').attr('inter_city');
    var show_city2 = $('#filter_city2').attr('checked');
    var city2 = $('#filter_city2').attr('inter_city');
    var show_city3 = $('#filter_city3').attr('checked');
    var city3 = $('#filter_city3').attr('inter_city');

	var filter_nstop  = $("#filter_nstop").attr("checked");
	var filter_stop   = $("#filter_stop").attr("checked");
    var filter_ac = $('#filter_ac').attr('checked');
    var filter_nac = $('#filter_nac').attr('checked');
    var filter_seater = $('#filter_seater').attr('checked');
    var filter_sleeper = $('#filter_sleeper').attr('checked');
	var filter_volvo  = $("#filter_volvo").attr("checked");
	var filter_nvolvo = $("#filter_nvolvo").attr("checked");
	var filter_op = $("#filter_operator").val();

    $('.routes').each(function (i, el) {
    	var show1 = false;	// AC
    	var show2 = false; 	// Sleeper
    	var show3 = false;	// Volvo
    	var show4 = false;	// depart time
    	var show5 = false;	// total time
    	var show6 = false;	// non-stop
    	var show7 = false;	// intermediate city
    	var show8 = false;	// operator
    	
    	var hop = $(this).attr("hop");
    	var rsid = $(this).attr("id");
    	
    	if (hop == "0" && filter_nstop) {
    		show6 = show7 = true;
    	} else if (hop == "1" && filter_stop) {
    		show6 = true;
    		var city = $(this).attr('inter_city');
        	
        	switch (city) {
        		case city1 :
        			if (show_city1) { show7 = true; }
        			break;
        		case city2 :
        			if (show_city2) { show7 = true; }
        			break;
        		case city3 :
        			if (show_city3) { show7 = true; }
        			break;
        		default :
        			show7 = false;
        			break;
        	}
    	} else {
    		show6 = show7 = false;
    	}
    	
    	if (!(show6 && show7)) {
    		// hide
			$(this).removeClass("showRow");
			$("#sa-row-"+rsid).removeClass("showRow");
			$("#"+rsid+"_dummy").removeClass("showRow");
			$(this).addClass("hideRow");
			$("#sa-row-"+rsid).addClass("hideRow");
			$("#"+rsid+"_dummy").addClass("hideRow");
    	} else {
        	// other filters here
        	if (hop == "0") {
        	    var rsid = $(this).attr("id");
        	        
    	        var has_ac 		= $("#"+rsid).attr('has_ac');
    	        var has_nac 	= $("#"+rsid).attr('has_nac');
    	        var has_sleeper = $("#"+rsid).attr('has_sleeper');
    	        var has_seater 	= $("#"+rsid).attr('has_seater');
    	    	var is_volvo  = $(this).attr("is_volvo");
    	    	var op  = $(this).attr("op");
        	  
    	        if ((filter_ac && has_ac==1) || (filter_nac && has_nac==1)) { show1 = true; }
    	        if ((filter_seater && has_seater==1) || (filter_sleeper && has_sleeper==1)) { show2 = true; }
    	        if ((filter_volvo && is_volvo==1) || (filter_nvolvo && is_volvo==0)) { show3 = true; }
    	        if ((filter_op == 0) || filter_op == op) { show8 = true; } 

        	} else if (hop == "1") {
        		
                var has_ac1, has_ac2, has_nac1, has_nac2, has_seater1, has_seater2, has_sleeper1, has_sleeper2, is_volvo1, is_volvo2;
                has_ac1 = has_ac2 = has_nac1 = has_nac2 = has_seater1 = has_seater2 = has_sleeper1 = has_sleeper2 = is_volvo1 = is_volvo2 = false;
                var op1 = 0;
                var op2 = 0;
                
                if (filter_ac && filter_nac) {
                	has_ac1 = has_ac2 = has_nac1 = has_nac2 = 1;
                } else {
                	has_ac1 		= $('#'+rsid).attr('has_ac1');
                    has_nac1 		= $('#'+rsid).attr('has_nac1');
                    has_ac2 		= $('#'+rsid).attr('has_ac2');
                    has_nac2 		= $('#'+rsid).attr('has_nac2');
                }
                
                if (filter_seater && filter_sleeper) {
                    has_sleeper1 = has_seater1 = has_sleeper2 = has_seater2 = 1;
                } else {
                    has_sleeper1 	= $('#'+rsid).attr('has_sleeper1');
                    has_seater1 	= $('#'+rsid).attr('has_seater1');
                    has_sleeper2 	= $('#'+rsid).attr('has_sleeper2');
                    has_seater2 	= $('#'+rsid).attr('has_seater2');
                }

                if (filter_volvo && filter_nvolvo) {
                	is_volvo1 = is_volvo2 = 1;
                } else {
                	is_volvo1 = $('#'+rsid).attr('is_volvo1');
                	is_volvo2 = $('#'+rsid).attr('is_volvo2');
                }
                
                if ((filter_ac && has_ac1==1 && has_ac2==1) || (filter_nac && has_nac1==1 && has_nac2==1)) { show1 = true; }
                if ((filter_seater && has_seater1==1 && has_seater2==1) || (filter_sleeper && has_sleeper1==1 && has_sleeper2==1)) { show2 = true; }
                if ((filter_volvo && is_volvo1==1 && is_volvo2==1) || (filter_nvolvo && is_volvo1==0 && is_volvo2==0)) { show3 = true; }
                if (filter_op == 0) {
                	show8 = true;
                } else {
	                op1 = $('#'+rsid).attr('op1');
	                op2 = $('#'+rsid).attr('op2');
	                if (op1 == filter_op && op2 == filter_op) {
	                	show8 = true;
	                }
                }
        	}

            var dr = parseInt($(el).attr('dr'));
            var hr = parseInt($(el).attr('hr'));
            
            if(dr >= dept_time_min && dr < dept_time_max) { show4 = true; }
            if (total_time_min == 0 && total_time_max == 48) {
            	show5 = true;
            } else if(hr >= total_time_min && hr < total_time_max) {
            	show5 = true;
            }
            
        	if (show1 && show2 && show3 && show4 && show5 && show8) {
    			$(this).removeClass("hideRow");
    			$("#sa-row-"+rsid).removeClass("hideRow");
    			$("#"+rsid+"_dummy").removeClass("hideRow");
    			$(this).addClass("showRow");
    			$("#sa-row-"+rsid).addClass("showRow");
    			$("#"+rsid+"_dummy").addClass("showRow");
        	} else {
    			$(this).removeClass("showRow");
    			$("#sa-row-"+rsid).removeClass("showRow");
    			$("#"+rsid+"_dummy").removeClass("showRow");
    			$(this).addClass("hideRow");
    			$("#sa-row-"+rsid).addClass("hideRow");
    			$("#"+rsid+"_dummy").addClass("hideRow");	
        	}
        }
    });
    
    displayNoRoutesMessage();
    displayBottomHeight();
}

function filterSearch()
{
    // hide all the charts
    hideAllCharts();

    // remove the separators between results
    $(".dummySeparator").remove();

    var filter_ac = $('#filter_ac').attr('checked');
    var filter_nac = $('#filter_nac').attr('checked');
    var filter_seater = $('#filter_seater').attr('checked');
    var filter_sleeper = $('#filter_sleeper').attr('checked');
    var filter_volvo = $('#filter_volvo').attr('checked');
    var filter_nvolvo = $('#filter_nvolvo').attr('checked');
    var filter_op = $('#filter_operator').val();
    
    $('.routes').each(function (i, el) {
        var has_ac = $(this).attr('has_ac');
        var has_nac = $(this).attr('has_nac');
        var has_sleeper = $(this).attr('has_sleeper');
        var has_seater = $(this).attr('has_seater');
        var is_volvo  = $(this).attr("is_volvo");
        var dr = $(el).attr('dr');
        var hr = $(el).attr('hr');
        var rsid = $(this).attr("id");
        var op = $(this).attr("op");

        var show1 = false;var show2 = false;var show3 = false;var show4 = false;var show5 = false;var show6 = false;
       
        if ((filter_ac && has_ac==1) || (filter_nac && has_nac==1)) { show1 = true; }
        if ((filter_seater && has_seater==1) || (filter_sleeper && has_sleeper==1)) { show2 = true; }
        if ((filter_volvo && is_volvo==1) || (filter_nvolvo && is_volvo==0)) { show3 = true; }
        if(dr >= dept_time_min && dr < dept_time_max) { show4 = true; }
        if (total_time_min == 0 && total_time_max == 24) {
        	show5 = true;
        } else if(hr >= total_time_min && hr < total_time_max) { 
        	show5 = true; 
        }
        if (filter_op == 0) {
        	show6 = true;
        } else {
        	if (op == filter_op) {
                show6 = true; 
            }
        }
       
        if (show1 && show2 && show3 && show4 && show5 && show6) {
            $(this).removeClass("hideRow");
            $(this).addClass("showRow");
            $(this).after(getRouteSeparator(rsid));
        } else {
            $(this).removeClass("showRow");
            $(this).addClass("hideRow");
        }
    });

    displayNoRoutesMessage();
    displayBottomHeight();
}

/**
 * to show validation errors
 * @param oElem - object - the element that's to be displayed as a dialog
 */
function openErrorDialog(oElem)
{
	$.fx.speeds._default = 1000;
	$(oElem).dialog({
		autoOpen: false,
		show: "slide",
		hide: "fade",
		width: "auto",
		modal:true,
		buttons: {
			Close: function() {
				$( this ).dialog( "close" );
			}
		}
	});

	$(oElem).dialog("open");
}

/**
 * A dialogbox to alert the user of any repiricing changes
 * when he comes from search-to-book 
 * @param obj oElem - display element that contains the repricing details
 * @note : if possible, combine this dialog & error dialog
 */
function openRepricingDialog(oElem)
{
	$.fx.speeds._default = 1000;
	$(oElem).dialog({
		autoOpen: false,
		show: "slide",
		hide: "fade",
		width: "auto",
		modal:true
	});

	$(oElem).dialog("open");
}

function displayPickupAddress(rsId)
{
	$("#pickupDetails_"+rsId).html($("#pickUp_"+rsId+" option:selected").attr("pickupAddress"));
}

/**
 * book validate for one hop
 */
function bookValidateOneHop(oForm)
{
	var rsId1 = $(oForm).children("input[name='routeScheduleId1']").val();
	var rsId2 = $(oForm).children("input[name='routeScheduleId2']").val();
	var rsId = rsId1+'-'+rsId2;
	var validated = genderValidated = totalGenderValidated = true;
	var msg = new Array();
	var message = "";

	// verify if seats are chosen
	// go ahead with other verifications only if this is satisfied!
	if(seatsSelected['1-'+rsId] === undefined || (seatsSelected['1-'+rsId] !== undefined && seatsSelected['1-'+rsId]['totalSeats'] == 0))
	{
		jAlert("Please choose a seat for Leg 1 of the journey before proceeding to book.", "Booking Error");
		return false;
	}

	if(seatsSelected['2-'+rsId] === undefined || (seatsSelected['2-'+rsId] !== undefined && seatsSelected['2-'+rsId]['totalSeats'] == 0))
	{
		jAlert("Please choose a seat for Leg 2 of the journey before proceeding to book.", "Booking Error");
		return false;
	}
	
	var m1 = f1 = 0;
	var m2 = f2 = 0;

	// sorry boss.. jquery form validation falls flat here..
	// use arcane JS to loop through a defined array for validation..
	$.each(seatsSelected['1-'+rsId]['inp_gender'], function(key, value) {
		if(genderValidated && ($("#"+value+" option:selected").attr('value') == "undefined" || $("#"+value+" option:selected").attr('value') == ""))
		{
			validated = genderValidated = false;
			msg[msg.length] = "Please set the gender of all passengers before proceeding to book.";
		} else {
			if ($("#"+value+" option:selected").attr('value') == "M")
				m1 += 1;
			else if ($("#"+value+" option:selected").attr('value') == "F")
				f1 += 1;
		}
	});	

	$.each(seatsSelected['2-'+rsId]['inp_gender'], function(key, value) { 
		if(genderValidated && ($("#"+value+" option:selected").attr('value') == "undefined" || $("#"+value+" option:selected").attr('value') == ""))
		{
			validated = genderValidated = false;
			msg[msg.length] = "Please set the gender of all passengers before proceeding to book.";
		} else {
			if ($("#"+value+" option:selected").attr('value') == "M")
				m2 += 1;
			else if ($("#"+value+" option:selected").attr('value') == "F")
				f2 += 1;
		}
	});	


	// validate if the no. of passangers of same sex are equal on both the legs of the journey
	if (m1 != m2 || f1 != f2) {
		validated = totalGenderValidated = false;
		msg[msg.length] = "The number of males/females in the two legs of the journey is not the same. Please check.";
	}
	
	// validate if pickup point is selected
	if($("#pickUp_1-"+rsId+" option:selected").attr('value') == "undefined" || $("#pickUp_1-"+rsId+" option:selected").attr('value') == "")
	{
		validated = false;
		msg[msg.length] = "Please choose pickup point for your first leg before proceeding to book.";
	}

	if($("#pickUp_2-"+rsId+" option:selected").attr('value') == "undefined" || $("#pickUp_2-"+rsId+" option:selected").attr('value') == "")
	{
		validated = false;
		msg[msg.length] = "Please choose your pickup point at the hop city before proceeding to book.";
	}
	
	// if perfect, then setup FROM values before submission 
	if(validated)
	{
		$(oForm).children("#pickUpID1").val($("#pickUp_1-"+rsId+" option:selected").attr('value'));
		$(oForm).children('#pickUpName1').val($("#pickUp_1-"+rsId+" option:selected").attr('pickupName'));
		$(oForm).children('#pickUpTime1').val($("#pickUp_1-"+rsId+" option:selected").attr('pickupTime'));
		$(oForm).children('#pickUpAddress1').val($("#pickUp_1-"+rsId+" option:selected").attr('pickupAddress'));
		$(oForm).children('#pickUpLandmark1').val($("#pickUp_1-"+rsId+" option:selected").attr('pickupLandmark'));
		$(oForm).children('#pickUpPhone1').val($("#pickUp_1-"+rsId+" option:selected").attr('pickupPhone'));

		$(oForm).children("#pickUpID2").val($("#pickUp_2-"+rsId+" option:selected").attr('value'));
		$(oForm).children('#pickUpName2').val($("#pickUp_2-"+rsId+" option:selected").attr('pickupName'));
		$(oForm).children('#pickUpTime2').val($("#pickUp_2-"+rsId+" option:selected").attr('pickupTime'));
		$(oForm).children('#pickUpAddress2').val($("#pickUp_2-"+rsId+" option:selected").attr('pickupAddress'));
		$(oForm).children('#pickUpLandmark2').val($("#pickUp_2-"+rsId+" option:selected").attr('pickupLandmark'));
		$(oForm).children('#pickUpPhone2').val($("#pickUp_2-"+rsId+" option:selected").attr('pickupPhone'));

		showOverlay(document.getElementById("goToCheckoutOverlay"));
		return true;
	}
	else
	{
		message += "<ol>";
		$.each(msg, function(key, value) {
			message += "<li>"+value+"</li>";
		});
		message += "<ol>";
		jAlert(message, "Booking Error");
		return false;
	}
}

/**
 * validate seat details before submission.
 * setup pickup details for this form.
 */

function bookValidatety(oForm)
{
	var rsId = $(oForm).children("input[name='routeScheduleId']").val();
	var validated = genderValidated = true;
	var msg = new Array();
	var message = "";

	// verify if seats are chosen
	// go ahead with other verifications only if this is satisfied!
	if(seatsSelected[rsId] === undefined || (seatsSelected[rsId] !== undefined && seatsSelected[rsId]['totalSeats'] == 0))
	{
		jAlert("Please choose a seat before proceeding to book.", "Booking Error");
		return false;
	}

	// sorry boss.. jquery form validation falls flat here..
	// use arcane JS to loop through a defined array for validation..
	$.each(seatsSelected[rsId]['inp_gender'], function(key, value) { 
		if(genderValidated && ($("#"+value+" option:selected").attr('value') == "undefined" || $("#"+value+" option:selected").attr('value') == ""))
		{
			validated = genderValidated = false;
			msg[msg.length] = "Please set the gender of all passengers before proceeding to book.";
		}
	});	

	// validate if pickup point is selected
	if($("#pickUp_"+rsId+" option:selected").attr('value') == "undefined" || $("#pickUp_"+rsId+" option:selected").attr('value') == "")
	{
		validated = false;
		msg[msg.length] = "Please choose your pickup point before proceeding to book.";
	}

	// if perfect, then setup FROM values before submission 
	if(validated)
	{
		$(oForm).children("#pickUpID").val($("#pickUp_"+rsId+" option:selected").attr('value'));
		$(oForm).children('#pickUpName').val($("#pickUp_"+rsId+" option:selected").attr('pickupName'));
		$(oForm).children('#pickUpTime').val($("#pickUp_"+rsId+" option:selected").attr('pickupTime'));
		$(oForm).children('#pickUpAddress').val($("#pickUp_"+rsId+" option:selected").attr('pickupAddress'));
		$(oForm).children('#pickUpLandmark').val($("#pickUp_"+rsId+" option:selected").attr('pickupLandmark'));
		$(oForm).children('#pickUpPhone').val($("#pickUp_"+rsId+" option:selected").attr('pickupPhone'));

		if( $('#journeyType').length ){
			var journeyType = document.getElementById('journeyType').value;
			
			if(journeyType == "(Onward Journey)"){
				
				var tocityarr = document.getElementById("fromCity").value.split("|");
				 var fromcityarr = document.getElementById("toCity").value.split("|");
				 var fromcity = capitaliseFirstLetter(fromcityarr[1]);
				 var tocity = capitaliseFirstLetter(tocityarr[1]);
				 document.getElementById("progressbar").style.display = 'block';
				  $('#prgFromCity').text( fromcity);
				  $('#prgToCity').text( tocity);
				  $('#prgMode').text("return");
				  $('#prgJourneyDate').text( document.getElementById("returnDate").value);
				  document.getElementById("progressbar").style.display = 'block';
					 ProgressImage = document.getElementById('progress_image');
					 setTimeout("ProgressImage.src = ProgressImage.src",50);
					 document.getElementById("fromCity").style.visibility = 'hidden'; 
					 document.getElementById("toCity").style.visibility = 'hidden';
					 $('html, body').animate({ scrollTop: 0 }, 0);
					 
				 
			}
		}
		$('#bookSubmit').hide();
		$('#bookSubmitWait').show();
		return true;
	}
	else
	{
		message += "<ol>";
		$.each(msg, function(key, value) {
			message += "<li>"+value+"</li>";
		});
		message += "<ol>";
		jAlert(message, "Booking Error");
		return false;
	}
}


function bookValidate(oForm)
{
	var rsId = $(oForm).children("input[name='routeScheduleId']").val();
	var validated = genderValidated = true;
	var msg = new Array();
	var message = "";
	//genderValidated = false;
	

	msg.length = 0;
	// verify if seats are chosen
	// go ahead with other verifications only if this is satisfied!
	if(seatsSelected[rsId] === undefined || (seatsSelected[rsId] !== undefined && seatsSelected[rsId]['totalSeats'] == 0))
	{
		jAlert("Please choose a seat before proceeding to book.", "Booking Message");
		return false;
	}
	var lower_pairs_arr = new Array();
	var upper_pairs_arr = new Array();
	var lower_pairs = $("#lower_pairs_"+rsId).val();
	var upper_pairs = $("#upper_pairs_"+rsId).val();
	lower_pairs_arr = lower_pairs.split("--");
	upper_pairs_arr = upper_pairs.split("--");
	var companyID = $('#'+rsId).data('company_id');
	// sorry boss.. jquery form validation falls flat here..
	// use arcane JS to loop through a defined array for validation..
	$.each(seatsSelected[rsId]['inp_gender'], function(key, value) { 
		if(genderValidated && ($("#"+value+" option:selected").attr('value') == "undefined" || $("#"+value+" option:selected").attr('value') == ""))
		{
			validated = genderValidated = false;
			msg[msg.length] = "Please set the gender of all passengers before proceeding to book.";
		}
		
		var curr_gender = $("#"+value+" option:selected").attr('value');
		if(genderValidated == false){
			return (this != "three");
		}
		// check for gender mapping here.
		//alert(value);
		seat_arr = new Array();
		seat_arr  = value.split("_");
		
		//alert(seat_arr[3]);
		seat_no = seat_arr[3];
		$.each(lower_pairs_arr, function(key, value) {
			
			value = value.replace("\"","");
			// case: if the seat is present in the current seat pair
			if(value.search(seat_no) != -1 && companyID!=2517){
				//case: split the seat pair
				pair_arr = value.split("-");
				//check the pair length,in case of 3 seat pair.
				pair_length = pair_arr.length;
				
				
				if(pair_length == 2){
					// case: it is 2X2 or 2X1 bus
					var index = $.inArray(seat_no,pair_arr);
					//alert(index);
					if(index == 0){
						// get the current seat info
						var seatObj = $('#slot_'+rsId+'_'+pair_arr[index]).attr("gender");
						var adjSeatObj = $('#slot_'+rsId+'_'+pair_arr[1]).attr("gender");
						
						var adjSeatStatus = $('#slot_'+rsId+'_'+pair_arr[1]).attr("is_available");
						var adjSeatGender;
						if(adjSeatObj == 'M'){adjSeatGender="Male";}
						if(adjSeatObj == 'F'){adjSeatGender="Female";}
						if(adjSeatStatus != 1 && adjSeatGender === undefined){adjSeatGender = "Male";}
						if(adjSeatStatus == "" && adjSeatObj == ""){adjSeatGender == "Male";adjSeatObj='M';}
						
						
						if(adjSeatObj !== undefined  && adjSeatStatus != 1 && curr_gender != adjSeatObj){
							validated = genderValidated = false;
							//msg[msg.length] = "Seat("+seat_no+") you chose is reserved for "+adjSeatGender+". Please choose a different seat.";
							//msg[msg.length] = "Sorry, the seat you've selected is reserved for a "+adjSeatGender+" passenger. Please select another seat";
							msg[msg.length] = "Sorry, you can't book a seat next to a passenger of opposite gender. Please select a different seat";
						}
					}
					if(index == 1){
						// get the current seat info
						var seatObj = $('#slot_'+rsId+'_'+pair_arr[index]).attr("gender");
						var adjSeatObj = $('#slot_'+rsId+'_'+pair_arr[0]).attr("gender");
						
						var adjSeatStatus = $('#slot_'+rsId+'_'+pair_arr[0]).attr("is_available");
						
						var adjSeatGender;
						if(adjSeatObj == 'M'){adjSeatGender="Male";}
						if(adjSeatObj == 'F'){adjSeatGender="Female";}
						if(adjSeatStatus != 1 && adjSeatGender === undefined){adjSeatGender = "Male"}
						if(adjSeatStatus == "" && adjSeatObj == ""){adjSeatGender == "Male";adjSeatObj='M';}
						
						if(adjSeatObj !== undefined && adjSeatStatus != 1 &&  curr_gender != adjSeatObj){
							validated = genderValidated = false;
							//msg[msg.length] = "Seat("+seat_no+") you chose is reserved for "+adjSeatGender+". Please choose a different seat.";
							//msg[msg.length] = "Sorry, the seat you've selected is reserved for a "+adjSeatGender+" passenger. Please select another seat";
							msg[msg.length] = "Sorry, you can't book a seat next to a passenger of opposite gender. Please select a different seat";
						}
					}
				}
				if(pair_length == 5){
					// case: the last seat where there is a middle seat also.
					var index = $.inArray(seat_no,pair_arr);
					var leftSeatGender;
					var rightSeatGender;
					
					if(index != 0){
						var leftSeatObj = $('#slot_'+rsId+'_'+pair_arr[index+1]).attr("gender");
						var leftSeatStatus = $('#slot_'+rsId+'_'+pair_arr[index+1]).attr("is_available");
						if(leftSeatObj == 'M'){leftSeatGender="Male";}
						else if(leftSeatObj == 'F'){leftSeatGender="Female";}
						else {leftSeatObj=curr_gender;}
						if(leftSeatStatus != 1 && leftSeatGender === undefined){leftSeatGender = "Male"}
						if(leftSeatObj !== undefined && leftSeatStatus != 1 &&  curr_gender != leftSeatObj ){
							validated = genderValidated = false;
							//msg[msg.length] = "Seat you chose is reserved for ladies.Please choose a different seat.";							
							msg[msg.length] = "Sorry, the seat you've selected is reserved for a "+leftSeatGender+" passenger. Please select another seat";
						}
						
						
					}
					var seatObj = $('#slot_'+rsId+'_'+pair_arr[index]).attr("gender");
					
					var rightSeatObj = $('#slot_'+rsId+'_'+pair_arr[index-1]).attr("gender");
					
					var rightSeatStatus = $('#slot_'+rsId+'_'+pair_arr[index-1]).attr("is_available");
					
					if(rightSeatObj == 'M'){rightSeatGender="Male";}
					if(rightSeatObj == 'F'){rightSeatGender="Female";}
					if(rightSeatStatus != 1 && rightSeatGender === undefined){rightSeatGender = "Male"}
					
					
					if(rightSeatObj !== undefined && rightSeatStatus != 1 &&  curr_gender != rightSeatObj){
						validated = genderValidated = false;
						//msg[msg.length] = "Seat you chose is reserved for ladies. Please choose a different seat.";
						//msg[msg.length] = "Sorry, the seat you've selected is reserved for a "+rightSeatGender+" passenger. Please select another seat";
						msg[msg.length] = "Sorry, you can't book a seat next to a passenger of opposite gender. Please select a different seat";
					}
				}
			}
		});
		
		// upper deck
		$.each(upper_pairs_arr, function(key, value) {
			
			// case: if the seat is present in the current seat pair
			value = value.replace("\"","");
			
			if(value.search(seat_no) != -1){
				//case: split the seat pair
				pair_arr = value.split("-");
				//check the pair length,in case of 3 seat pair.
				pair_length = pair_arr.length;
				//alert(pair_length);
				if(pair_length == 2){
					// case: it is 2X2 or 2X1 bus
					var index = $.inArray(seat_no,pair_arr);
					//alert(index);
					if(index == 0){
						// get the current seat info
						
						var seatObj = $('#slot_'+rsId+'_'+pair_arr[index]).attr("gender");
						var adjSeatObj = $('#slot_'+rsId+'_'+pair_arr[1]).attr("gender");
						var adjSeatStatus = $('#slot_'+rsId+'_'+pair_arr[1]).attr("is_available");
						if(adjSeatObj == 'M'){var adjSeatGender="Male"}
						if(adjSeatObj == 'F'){var adjSeatGender="Female"}
						if(adjSeatStatus != 1 && adjSeatGender === undefined){adjSeatGender = "Male"}
						// case : for some buses , is _available and gender will be blank for booked seat by male
						if(adjSeatStatus == "" && adjSeatObj == ""){adjSeatGender == "Male";adjSeatObj='M';}
						
						//alert("adj seat gender"+adjSeatObj);
						if(adjSeatObj !== undefined && adjSeatStatus != 1 && curr_gender != adjSeatObj){
							validated = genderValidated = false;
							//msg[msg.length] = "Seat("+seat_no+") you chose is reserved for "+adjSeatGender+". Please choose a different seat.";
							//msg[msg.length] = "Sorry, the seat you've selected is reserved for a "+adjSeatGender+" passenger. Please select another seat";
							msg[msg.length] = "Sorry, you can't book a seat next to a passenger of opposite gender. Please select a different seat";
						}
					}
					if(index == 1){
						// get the current seat info
						
						var seatObj = $('#slot_'+rsId+'_'+pair_arr[index]).attr("gender");
						var adjSeatObj = $('#slot_'+rsId+'_'+pair_arr[0]).attr("gender");
						var adjSeatStatus = $('#slot_'+rsId+'_'+pair_arr[0]).attr("is_available");
						if(adjSeatObj == 'M'){var adjSeatGender="Male"}
						if(adjSeatObj == 'F'){var adjSeatGender="Female"}
						if(adjSeatStatus != 1 && adjSeatGender === undefined){adjSeatGender = "Male";}
						if(adjSeatStatus == "" && adjSeatObj == ""){adjSeatGender == "Male";adjSeatObj='M';}
						if(adjSeatObj !== undefined && adjSeatStatus != 1 && curr_gender != adjSeatObj){
							validated = genderValidated = false;
							//msg[msg.length] = "Seat("+seat_no+") you chose is reserved for "+adjSeatGender+". Please choose a different seat.";
							//msg[msg.length] = "Sorry, the seat you've selected is reserved for a "+adjSeatGender+" passenger. Please select another seat";
							msg[msg.length] = "Sorry, you can't book a seat next to a passenger of opposite gender. Please select a different seat";
						}
					}
					
				}
			}
			
			//if(valu)
		});
	});	
	
	//return false;
	// validate if pickup point is selected
	if($("#pickUp_"+rsId+" option:selected").attr('value') == "undefined" || $("#pickUp_"+rsId+" option:selected").attr('value') == "")
	{
		validated = false;
		msg[msg.length] = "Please choose your pickup point before proceeding to book.";
	}
	// check if pickups are available
	if($("#pickUp_"+rsId).size() == 0){
		validated = false;
		msg[msg.length] = "Please choose your pickup point before proceeding to book.";
	}
	// validate if dropoff point is selected
	if($("#dropoff_"+rsId+" option:selected").attr('value') == "undefined" || $("#dropoff_"+rsId+" option:selected").attr('value') == "")
	{
		validated = false;
		msg[msg.length] = "Please choose your dropoff point before proceeding to book.";
	}

	// if perfect, then setup FROM values before submission 
	if(validated)
	{
		$(oForm).children("#pickUpID").val($("#pickUp_"+rsId+" option:selected").attr('value'));
		$(oForm).children('#pickUpName').val($("#pickUp_"+rsId+" option:selected").attr('pickupName'));
		$(oForm).children('#pickUpTime').val($("#pickUp_"+rsId+" option:selected").attr('pickupTime'));
		$(oForm).children('#pickUpAddress').val($("#pickUp_"+rsId+" option:selected").attr('pickupAddress'));
		$(oForm).children('#pickUpLandmark').val($("#pickUp_"+rsId+" option:selected").attr('pickupLandmark'));
		$(oForm).children('#pickUpPhone').val($("#pickUp_"+rsId+" option:selected").attr('pickupPhone'));
		$(oForm).children("#dropOffID").val($("#dropoff_"+rsId+" option:selected").attr('value'));
		$(oForm).children('#dropOffName').val($("#dropoff_"+rsId+" option:selected").attr('dropffName'));
		if( $('#journeyType').length ){
			var journeyType = document.getElementById('journeyType').value;
			
			if(journeyType == "(Onward Journey)"){
				
				var tocityarr = document.getElementById("fromCity").value.split("|");
				 var fromcityarr = document.getElementById("toCity").value.split("|");
				 var fromcity = capitaliseFirstLetter(fromcityarr[1]);
				 var tocity = capitaliseFirstLetter(tocityarr[1]);
				 document.getElementById("progressbar").style.display = 'block';
				  $('#prgFromCity').text( fromcity);
				  $('#prgToCity').text( tocity);
				  $('#prgMode').text("return");
				  $('#prgJourneyDate').text( document.getElementById("returnDate").value);
				  document.getElementById("progressbar").style.display = 'block';
					 ProgressImage = document.getElementById('progress_image');
					 setTimeout("ProgressImage.src = ProgressImage.src",50);
					 document.getElementById("fromCity").style.visibility = 'hidden'; 
					 document.getElementById("toCity").style.visibility = 'hidden';
					 $('html, body').animate({ scrollTop: 0 }, 0);
					 
				 
			}else{
				showOverlay(document.getElementById("goToCheckoutOverlay"));
			}
		}
		$('#bookSubmit').hide();
		$('#bookSubmitWait').show();
		return true;
	}
	else
	{
		message += "<ul>";
		$.each(msg, function(key, value) {
			message += "<li>"+value+"</li>";
		});
		message += "<ul>";
		jAlert(message, "Booking Message");
		msg.length = 0;
		return false;
	}
}


function setRouteHighlight(pRouteScheduleId) 
{
 $("#"+pRouteScheduleId).addClass("routeSelected");	
}

/*
function setRouteHighlight1(pRouteScheduleId,hop)
{
	if(hop==0)
	{
	$("#"+pRouteScheduleId).addClass("routeSelected");
	}
	else
	if(hop==1)
	{
	$("#"+pRouteScheduleId).addClass("routeSelected_onehop");
	}
}
*/

function showOverlay(oElem)
{
	$(oElem).show();
	$.fx.speeds._default = 1000;
	$(oElem).dialog({
		 autoOpen: false
		,width: "auto"
		,modal:true
		,dialogClass: 'noTitleForDialog'
	});
	$(oElem).dialog("open");
}

function fancyPickup(routeScheduleId)
{
	$("a.iframe").fancybox({	
	    'showCloseButton'   : true,
		'width'				: '75%',
		'height'			: '75%',
		'autoScale'			: false,
		'transitionIn'		: 'none',
		'transitionOut'		: 'none',
		'type'				: 'iframe'
	});	
}

function loadRouteDetails(pRouteScheduleId)
{
	$.ajax({
		url: "/resource/GetSeatArrangementOneHop"
		,type: "POST"
		,dataType: "html"
		,data: {
			out: "html"
			,ajx: 1
			,r: hopRoute
			,q: q
			,fromCity: fromCity
			,toCity: toCity
		}
		,success: function( htm ) {
			$("#seatArrangement_"+routeScheduleIds).empty();
			$("#seatArrangement_"+routeScheduleIds).append(htm);
		}
	});
}

var q = "";
// display seat chart..

function loadSeatArrangementOneHop(routeScheduleIds, hopRoute, fromCity, toCity)
{
	if(routeScheduleIds == "" || hopRoute == "") { return; }
	
	$("#seatArrangement_"+routeScheduleIds).show();
	$("#seatArrangement_"+routeScheduleIds).empty();
	$("#seatArrangement_"+routeScheduleIds).append("<span style='padding:20px 0px; text-align:center; font-size:14px; display:block; border:5px solid #f2efef;background-color:#fff; '><img src='/img/loader.gif' width='100' height='100' /><br /><br />Getting Seat Chart  Please wait...</span>");
	
	$.ajax({
		url: "/resource/GetSeatArrangementOneHop"
		,type: "POST"
		,dataType: "html"
		,data: {
			out: "html"
			,ajx: 1
			,r: hopRoute
			,q: q
			,fromCity: fromCity
			,toCity: toCity
		}
		,success: function( htm ) {
			$("#seatArrangement_"+routeScheduleIds).empty();
			$("#seatArrangement_"+routeScheduleIds).append(htm);
		}
	});
}

function loadSeatArrangement(routeScheduleId, route, returnJourney)
{
	if(routeScheduleId == "" || route == "") { return; }
	//if(seatsSelected[routeScheduleId]['totalPrice'])
	if( typeof seatsSelected[routeScheduleId] != 'undefined' ){
		delete seatsSelected[routeScheduleId];
	}
	
	if($("#"+routeScheduleId+"_seatArrangement").length == 0)
	{
		var newRow = $("<tr id='"+routeScheduleId+"_seatArrangement' name='seatArrangement'><td colspan='9' style='height:auto; padding:0;border:0;'><div id='seatArrangement_"+routeScheduleId+"' name='seatArrangement' class='ab3' style='display:none;'>&nbsp;</div></td></tr>");
		$("#"+routeScheduleId).after(newRow);
	}
	var jt = $("#jt").val();
	
	$("#"+routeScheduleId+" .select-seats").hide();
	$("#"+routeScheduleId+" .loadingBar").show();
	
	$("#seatArrangement_"+routeScheduleId).show();
	$("#seatArrangement_"+routeScheduleId).empty();
	$("#seatArrangement_"+routeScheduleId).append("<span  class='ab1'><img src='/img/loader.gif' width='100' height='100' /><br /><br />Getting Seat Chart Please wait...</span>");
	$.ajax({
		url: "/resource/GetSeatArrangement"
		,type: "POST"
		,dataType: "html"
		,data: {
			out: "html"
			,ajx: 1
			,r: route
			,rjd: returnJourney
			,jt: jt
			,q: q
		}
		,success: function( htm ) {
			$("#seatArrangement_"+routeScheduleId).empty();
			$("#seatArrangement_"+routeScheduleId).append(htm);
			$("#"+routeScheduleId+" .loadingBar").hide();
		}
	});
}

function loadSeatArrangement_crs2(routeCode,route,returnJourney)
{
	if(routeCode == "") { return; }
	
	if( typeof seatsSelected[routeCode] != 'undefined' ){
		delete seatsSelected[routeCode];
	}
	
	if($("#"+routeCode+"_seatArrangement").length == 0)
	{
		
			var newRow = $("<tr id='"+routeCode+"_seatArrangement' name='seatArrangement'><td colspan='9' style='height:auto; padding:0;border:0;'><div id='seatArrangement_"+routeCode+"' name='seatArrangement' class='ab2' style='display:none;'>&nbsp;</div></td></tr>");
			
			$("#"+routeCode).after(newRow);
		
		
	}

	$("#"+routeCode+" .select-seats").hide();
	$("#"+routeCode+" .loadingBar").show();
	
	$("#seatArrangement_"+routeCode).show();
	$("#seatArrangement_"+routeCode).empty();
	$("#seatArrangement_"+routeCode).append("<span style='padding:20px 0px; text-align:center; font-size:14px; display:block; border:5px solid #F2EFEF;background-color:#fff; '><img src='/img/loader.gif' width='100' height='100' /><br /><br />Getting Seat Chart Please wait...</span>");
	$.ajax({
		url: "/resourceCrs2/GetSeatArrangement"
		,type: "POST"
		,dataType: "html"
		,data: {
			out: "html"
			,ajx: 1
			,r: routeCode
			,route:route
			,rjd: returnJourney
			,q: q
		}
		,success: function( htm ) {
			$("#seatArrangement_"+routeCode).empty();
			$("#seatArrangement_"+routeCode).append(htm);
			$("#"+routeCode+" .loadingBar").hide();
			showDistinctFaresBlock("#seatArrangement_"+routeCode);
		}
	});
}

function showDistinctFaresBlock(El) {
	var priceListHTML = '<div class="price-list"><span class="selected">All Fares</span></div>';
	var distinctFares = getDistinctFares(El); 
	if(distinctFares.length > 1){
		$(El).find('table#seatchart_table').css('border-top','none');
		$(El).find('table#seatchart_table td').css('border-top','none');
		$(El).find('table#seatchart_table').before(priceListHTML);
		$(El).find('table#seatchart_table').prev('.price-list')
		for(var i=0; i<distinctFares.length; i++){
			$(El).find('.price-list').append('<span>'+distinctFares[i]+'</span>');
		}
		$(El).find('.price-list span').click(function(){
			$(El).find('.price-list span').removeClass('selected');
			$(this).addClass('selected');
			var fareSel = $(this).text();
			if(fareSel == 'All Fares'){
				$(El).find('table#seatchart_table table td[fare]').css('visibility','visible');
			}else{
				$(El).find('table#seatchart_table table td[fare]').css('visibility','hidden');
				$(El).find('table#seatchart_table table td[fare="'+fareSel+'"]').css('visibility','visible');
			}
		});
	}	
}

function getDistinctFares(El){
	var distinctFares = new Array();
	var tempFare;
	$(El).find('table#seatchart_table table td[fare]').each(function(){
		tempFare = $(this).attr('fare');
		if($.inArray(tempFare, distinctFares) == -1){
			distinctFares.push(tempFare);
		}
	});
	return distinctFares;
}
// hide other charts in the search page on selection of 1
function hideOtherCharts(current_chart)
{
	$("div[name='seatArrangement']").each(function(i,v) {
		if($(v).attr("id") != "seatArrangement_"+current_chart)
		{
			$(v).empty();
			$(v).hide();
		}
	});
	resetCounters();
}

//hide allv charts in the search page (mostly on filtering..)
function hideAllCharts()
{
	$("tr[name='seatArrangement']").each(function(i,v) {
		$(v).empty();
		$(v).remove();
		//$(v).hide();
	});
	resetCounters();
}

function hideCurrentChart(current_chart)
{
	$("#seatArrangement_"+current_chart).empty();
	$("#seatArrangement_"+current_chart).hide();
	$("#"+current_chart+" .loadingBar").hide();
	$("#"+current_chart+" .select-seats").show();
	resetCounters();
}

// reset totalling counters
function resetCounters()
{
	totalSeatsSelected = 0;
	totalSeatPrice = 0;
}

function validateEmail(strEmail)
{
	var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
	return emailReg.test(strEmail);
}

function validateName(strName){
	var nameReg = /^[a-zA-Z\s-, ]+$/;
	return nameReg.test(strName);
}
function validateIndianMobile(strMobile)
{
	var validMobileNums = new Array(6,7,8,9);
	if($.inArray(parseInt(strMobile.charAt(0)), validMobileNums) > -1) { return true; }
	else { return false; }
}


function isValueExists(oElem)
{
	if($(oElem).val() == undefined || $(oElem).val() == "") { return false; }
	else { return true; }
}

function validateCheckout(fromElem)
{
	var validated = true;
	var message = "";
	var msg = new Array();
	if($("input[name=customerName]").val() == "")
	{
		validated = false;
		msg[msg.length] = "Please provide the 'Name' of the traveller.";
	}
	if($("input[name=email]").val() == "")
	{
		validated = false;
		msg[msg.length] = "Please provide the 'Email' to which the ticket should be emailed.";
	}else if(!validateName($("input[name=customerName]").val())){
		validated = false;
		msg[msg.length] = "Please provide a valid 'Name' of the traveller.";
	}
	else if(!validateEmail($("input[name=email]").val()))
	{
		validated = false;
		msg[msg.length] = "Please provide a valid 'Email' to which the ticket should be emailed.";
	}
	if(!isValueExists($("input[name=mobile]")))
	{
		validated = false;
		msg[msg.length] = "Please provide the 'Mobile Number' to which the ticket details should be messaged.";
	}
	else if(isNaN($("input[name=mobile]").val()) || $("input[name=mobile]").val().length != 10 || !validateIndianMobile($("input[name=mobile]").val()))
	{
		validated = false;
		msg[msg.length] = "Please provide a valid 'Mobile Number' to which the ticket details should be messaged.";
	}
	if(!isValueExists($("input[name=method]")))
	{
		validated = false;
		msg[msg.length] = "Please choose a payment option.";
	}
	// if COD
	//else if(($("input[name=method]").val() == 100) && (!isValueExists($("input[name=hd_address]")) || !isValueExists($("input[name=hd_city]")) || !isValueExists($("input[name=hd_area]")) || !isValueExists($("input[name=hd_pin]"))) )
	else if(($("input[name=method]").val() == 100) && 
				(	!isValueExists($("#hd_address")) || 
					!isValueExists($("#hd_city")) || 
					!isValueExists($("#hd_area")) || 
					!isValueExists($("#hd_pin")) || $("#hd_pin").val().length != 6 || isNaN($("#hd_pin").val())
				)
			)
	{
		validated = false;
		msg[msg.length] = "Please provide all required details for 'Cash on Delivery' of tickets.";
	}
	else if (($("input[name=method]").val() != 100) && !isValueExists($("input[name=provider]")))
	{
		validated = false;
		msg[msg.length] = "Please choose a payment option.";		
	}

	if(validated) {
		$('#checkoutSubmit').hide();
		$('#checkoutSubmitWait').show();
		$('input[type="submit"]').attr('disabled','disabled');
		if(typeof ty.checkout.data.checkoutConfirmPopUp != 'undefined' && ty.checkout.data.checkoutConfirmPopUp){
			 $("a#paymentConfirmOverlay").fancybox().trigger('click');
			 paymentConfirmOverlayInit();
			 return false;
		}else{
			return true;
		}
	 }else{
		message += "<ol>";
		$.each(msg, function(key, value) {
			message += "<li>"+value+"</li>";
		});
		message += "<ol>";
		jAlert(message, "Booking Error");
		return false;
	}
}

function paymentConfirmOverlayInit(){
	var overlayContent = $('#journeyDetails').html();
	$('#ret_overlay span').html(overlayContent);
	$('#fancybox-wrap').css('top','60px');
	$('#fancybox-close').click(function(){
		$('#checkoutSubmitWait').hide();
		$('#checkoutSubmit').show();
		$('input[type=submit]').attr('disabled','enabled');
	});
}

function setPayment(method, provider)
{
	$("#method").val(method);
	$("#provider").val(provider);
}

function resetPayment()
{
	$("#provider").val("");
	$("#method").val("");
}

//for swapping arrow img in search page
function chang_arrow_sea(o)
{
	if($(o).attr("id") == "myimg")
	{
		var elem = "#li_myimg";
		var elem2 = "#li_myimg2";
	}
	else
	{
		var elem = "#li_myimg2";
		var elem2 = "#li_myimg";
	}

	if($(elem).attr("src").search(/img_swap_off/) > 0)
	{
		$(elem).attr("src", $(elem).attr("src").replace(/img_swap_off/, "img_swap_on"));
		$(elem2).attr("src", $(elem).attr("src").replace(/img_swap_on/, "img_swap_off"));
	}
	else
	{
		$(elem).attr("src", $(elem).attr("src").replace(/img_swap_on/, "img_swap_off"));
		$(elem2).attr("src", $(elem).attr("src").replace(/img_swap_on/, "img_swap_off"));		
	}	
}

function getRouteSeparator(rsid)
{
	return "<tr id='"+rsid+"_dummy' class='dummySeparator'><td colspan='9' style='padding:0; border:none; height:10px;'></td></tr>";
}

function setHDCharges(type)
{
	if (type == "") { type = 0; }
	var codNote = "";

	if(type == 1)
	{
		// is HD
		var hdCharges = $("#hd_city option:selected").attr("hdc");
		if(isNaN(hdCharges)) { hdCharges = 0; }
		codNote = "Cash On Delivery charges of Rs. "+hdCharges+"/- will be added to the total price.";
		totalJourneyFare = parseInt(totalPrice) + parseInt(hdCharges) - parseInt(discount) - parseInt(pgFees);
		currentHDCharges = parseInt(hdCharges);
		deductPGFees = parseInt(pgFees);
	}
	else
	{
		// is PG
		codNote = "Cash On Delivery charge will be added to the total price.";
		if (parseInt(currentHDCharges) > 0) {
			// from HD to PG
			totalJourneyFare = parseInt(totalPrice) - parseInt(discount);
			currentHDCharges = 0;
			deductPGFees = 0;
		}
	}

	$("#codNote").html(codNote);
	$("#hdCharges").html(currentHDCharges);
	$("#pgCharges").html(type == 1 ? 0 : pgFees);
	$("#hd_charges").val(currentHDCharges);
	$("#totalJourneyFare").html(totalJourneyFare);
}

function validateCODVerification()
{
	if($("#mvc").val() == "")
	{
		jAlert("Please provide the verification code sent through SMS.", "COD Verification Error");
		return false;
	}

	return true;
}

function validateCoupon()
{
	var validated = true;
	var msg = new Array();
	var message = "";

	if($("input[name=coupon_code]").val() != "")
	{
		if($("input[name=customerName]").val() == "") {
			validated = false;
			msg[msg.length] = "Please provide the 'Name' of the traveller.";
		}
		if($("input[name=email]").val() == "") {
			validated = false;
			msg[msg.length] = "Please provide the 'Email' to which the ticket should be emailed.";
		}
		else if(!validateEmail($("input[name=email]").val())) {
			validated = false;
			msg[msg.length] = "Please provide a valid 'Email' to which the ticket should be emailed.";
		}
		if(!isValueExists($("input[name=mobile]"))) {
			validated = false;
			msg[msg.length] = "Please provide the 'Mobile Number' to which the ticket details should be messaged.";
		}
		else if(isNaN($("input[name=mobile]").val()) || $("input[name=mobile]").val().length != 10 || !validateIndianMobile($("input[name=mobile]").val())) {
			validated = false;
			msg[msg.length] = "Please provide a valid 'Mobile Number' to which the ticket details should be messaged.";
		}

		if(validated == false) {
			message += "<ol>";
			$.each(msg, function(key, value) {
				message += "<li>"+value+"</li>";
			});
			message += "<ol>";
			jAlert(message, "Discount Coupon Error");
			return false;
		}

		$.ajax({
			url: "/resource/validateCoupon"
			,type: "POST"
			,dataType: "html"
			,data: {
				out: "json"
				,ajx: 1
				,c: $("input[name=coupon_code]").val()
				,o: $("#o").val()
				,e: $("input[name=email]").val()
			}
			,success: function( json ) {
				var msg = "";
				var resp = JSON.parse(json);
				$("#couponValidityInfo").empty();
				switch(resp.code)
				{
					case 1:
						$("#coupon").val(resp.couponCode);
						msg = "Congratulations! A discount of Rs. "+resp.discountAmount+"/- has been applied on the Journey Fare.";
	
						discount = resp.discountAmount;
						$("#headerTier").html("Coupon <span style='color:#000;'>:");
						$("#tier").html(resp.couponCode);
						$("#tierData").html(resp.couponCode);
						$("#discountAmount").html(resp.discountAmount);
	
						totalJourneyFare = parseInt(totalPrice) + parseInt(currentHDCharges) - parseInt(deductPGFees) - parseInt(resp.discountAmount);
						$("#totalJourneyFare").html(totalJourneyFare);
	
						$("#discount_div").css({ display: "block" });
						break;
					case 0:
						msg = resp.errorMsg;
						break;
				}
				jAlert(msg, "Discount Coupon");
			}
		});
	}
	else { jAlert("Please enter Coupon code.", "Discount Coupon Error!"); }

	return false;
}

function getLocalizedCC()
{
	if( typeof( $("#fromCity option:selected").attr("stateName") ) != 'undefined' ) { 
		stateName	= $("#fromCity option:selected").attr("stateName").toLowerCase();
	}	
	cityName	= $("#fromCity option:selected").text();
	
	// only for Mumbai, localize to Mumbai CC
	if(cityName.search(/mumbai/i) > -1) { var cc = "Mumbai<span style='padding:2px 3px 0 5px;'>&nbsp;</span> : (022)&shy; 44820000"; }
	else if(cityName.search(/vashi/i) > -1) { var cc = "Mumbai<span style='padding:2px 3px 0 5px;'>&nbsp;</span> : (022)&shy; 44820000"; }
	else if(cityName.search(/thane/i) > -1) { var cc = "Mumbai<span style='padding:2px 3px 0 5px;'>&nbsp;</span> : (022)&shy; 44820000"; }
	else if(cityName.search(/delhi/i) > -1) { var cc = "New Delhi<span style='padding:2px 3px 0 5px;'>&nbsp;</span> : 1800&shy;-103-4482"; }
	else if(cityName.search(/new delhi/i) > -1) { var cc = "New Delhi<span style='padding:2px 3px 0 5px;'>&nbsp;</span> : 1800&shy;-103-4482"; }
	else if(cityName.search(/kolkata/i) > -1) { var cc = "Kolkata <span style='padding:2px 3px 0 5px;'>&nbsp;</span> : 1800-&shy;103-4482 "; }
	else if(cityName.search(/chandigarh/i) > -1) { var cc = "Chandigarh <span >&nbsp;</span> : (0172)&shy; 4482001"; }
	else if(cityName.search(/ludhiana/i) > -1) { var cc = "Chandigarh <span >&nbsp;</span> : (0172)&shy; 4482001"; }
	else if(cityName.search(/amritsar/i) > -1) { var cc = "Chandigarh <span >&nbsp;</span> : (0172)&shy; 4482001"; }
	else if(cityName.search(/jalandhar/i) > -1) { var cc = "Chandigarh <span >&nbsp;</span> : (0172)&shy; 4482001"; }
	else if(cityName.search(/indore/i) > -1) { var cc = "Indore<span style='padding:2px 3px 0 5px;'>&nbsp;</span> : 1800-103-&shy;4482 "; }
	else if(cityName.search(/jaipur/i) > -1) { var cc = "Jaipur<span style='padding:2px 3px 0 5px;'>&nbsp;</span> : 1800-103-&shy;4482"; }
	else if(cityName.search(/nagpur/i) > -1) { var cc = "Nagpur<span style='padding:2px 3px 0 5px;'>&nbsp;</span> : 1800-103-&shy;4482"; }
	else if(cityName.search(/surat/i) > -1) { var cc = "Surat<span style='padding:2px 3px 0 5px;'>&nbsp;</span> : 1800-103-&shy;4482"; }
	else if(cityName.search(/baroda/i) > -1) { var cc = "Baroda<span style='padding:2px 3px 0 5px;'>&nbsp;</span> : 1800-103-&shy;4482"; }
	else if(cityName.search(/goa/i) > -1) { var cc = "Goa<span style='padding:2px 3px 0 5px;'>&nbsp;</span> : 1800-103-&shy;4482"; }
	else if(cityName.search(/pune/i) > -1) { var cc = "Pune<span style='padding:2px 3px 0 5px;'>&nbsp;</span> : (020)&shy; 44820000 "; }
	else if(cityName.search(/rajkot/i) > -1) { var cc = "Rajkot<span style='padding:2px 3px 0 5px;'>&nbsp;</span> : 1800-&shy;103-4482"; }
	else if( typeof( stateName ) != 'undefined' ) {
		switch(stateName) {
			case "karnataka":
			case "tamil nadu":
			case "kerala":
			case "":
				var cc = "Bangalore <span style='padding:2px 3px 0 5px;'>&nbsp;</span> : (080)&shy; 44820000 ";
				break;
			case "andhra pradesh":
				var cc = "Hyderabad <span style='padding:2px 3px 0 5px;'>&nbsp;</span> : (040)&shy; 44820000 ";
				break;
			case "punjab":
				var cc = "Chandigarh <span >&nbsp;</span> : (0172)&shy; 4482001";
				break;
			case "west bengal":
				var cc = "Kolkata <span style='padding:2px 3px 0 5px;'>&nbsp;</span> : 1800-103-&shy;4482 ";
				break;
			
			default:
				var cc = "Ahmedabad<span >&nbsp;</span> : (079)&shy; 44820000";
				break;
		}
	}
	//$("#CC option[value="+cc+"]").attr("selected", "selected");
	
	
	//city = $("div.of").find(cc);
	//alert(city.text());
	//selectMItem(cc, 'all');
}

/**
* If multiple fares exist, they are shown in a tooltip
*/
function initMultipleFareTooltip() {
	$('table.tablesorter').find('td.fare .multi').qtip({
		content: {
			text: function() {
				return $(this).data('fareinfo')
			}
		},
		style: {
			classes: 'qtip-blue qtip-multifare'
		},
		position: {
			my: 'bottom right',
			at: 'top center'
		}
	});
}


function initInsuranceCheck(){
	$('#checkoutForm input#insuranceCheckbox1').change(function(){
		if($(this).attr('checked')){			
			$('#checkoutForm #totalJourneyFare').text(ty.data.totalJourneyFare+ty.data.totalInsuranceFare);
			$('#checkoutForm #insuranceFare').show();
		}else{
			$('#checkoutForm #totalJourneyFare').text(ty.data.totalJourneyFare);
			$('#checkoutForm #insuranceFare').hide();
		}
	});
}

function validateCheckoutJs(insuranceadded){
	validationMethods();
	$("form#checkoutForm").validate({
        rules: {                              
            email: {
                required: true,
                email: true
            },                
            mobile: {
                required: true,                
			    validateIndianMobile2: true
            },
        },
        messages: {                
            email: "",
            mobile: ""
        },
        submitHandler: function(form) {
        	event.preventDefault();
        	if(validateCheckout('form#checkoutForm')){
        		form.submit();
        	}            
        }
   });	
   if(insuranceadded){
		$('#Passenger_info .pax-details input').each(function () {						
			var nameAttr = $(this).attr('name');
			var nameAge = nameAttr.match(/paxAge/g);
			var nameseatNo = nameAttr.match(/paxSeatNo/g);
			if(nameAge=='paxAge'){				
				$(this).rules("add", {
		            required: true,
		            number: true,
	            	messages: {
				   		required: "",
				   		number:""
				  	}
	        	});
			}else if(nameseatNo!='paxSeatNo'){				
				$(this).rules("add", {
	            	required: true,
	            	messages: {
				   		required: ""
				  	}
	       	 	});
			}	        
		});
   }else{
   		$('#Passenger_info #customerNameDiv input#customerName').rules("add", {
	            required: true,
            	messages: {
			   		required: ""
			  	}
	    });
   }

}

function validationMethods(){
	$.validator.addMethod("validateIndianMobile2", function(value, element) {
	  	var strMobile = $("input[name=mobile]").val();
		var validMobileNums = new Array(6,7,8,9);
		if($.inArray(parseInt(strMobile.charAt(0)), validMobileNums) > -1) { return true; }
		else { return false; }
	}, "");	
}

function validateIndianMobile2(){
	var strMobile = $("input[name=mobile]").val();
	var validMobileNums = new Array(6,7,8,9);
	if($.inArray(parseInt(strMobile.charAt(0)), validMobileNums) > -1) { return true; }
	else { return false; }
}
