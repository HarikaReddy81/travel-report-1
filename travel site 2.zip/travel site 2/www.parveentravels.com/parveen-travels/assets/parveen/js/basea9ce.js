// JavaScript Document
$(document).ready(function () {


	/** use it as $.ErrorMessage(relatedId ,message)*/

	(function ( $ ) {
	$.ErrorMessage = function(relatedId ,message)  {
		relatedId.empty().append(message).slideDown(200);
		relatedId.removeClass("hide").addClass("show");
		window.setTimeout(function(){relatedId.slideUp(300, function() {relatedId.removeClass("show").addClass("hide")})},4500);
	};
	}( jQuery ));

	/** use it as $.SuccessMessage(relatedId ,message)*/

	(function ( $ ) {
	$.SuccessMessage = function(relatedId ,message)  {
		relatedId.empty().append(message).slideDown(200);
		relatedId.removeClass("hide").addClass("show");
		window.setTimeout(function(){relatedId.slideUp(300, function() {relatedId.removeClass("show").addClass("hide")})},4500);
	};
	}( jQuery ));


    $(window).scroll(function () {
        if ($(this).scrollTop() > 80) {
            $('#header').addClass('fixed');
            $('#page-header').addClass('hide');
			$('.bg-white').show;
        } else {
            $('#header').removeClass('fixed');
            $('#page-header').removeClass('hide');
			$('.bg-white').hide;
        }
    });

	$("#mobileNo").keypress(function(e){
		return PureMobile(e);
	});
	
	$("#mini-myaccount").unbind('click').on('click',function(e){
		window.location.href = "/parveen-travels/myAccount";
	});
	
	$("#showMiniMenu").click(function(){
		$('.mini-menu').toggle();
		$('.mini-menu').toggleClass('fadeInRight animated');
		if($("#mini-currentUser").val()=='guest@parveentravels.com')
			{
			$("#mini-reg").addClass('show').removeClass('hide');
			$("#mini-sign").addClass('show').removeClass('hide');
			}
		else{
			$("#mini-reg").addClass('hide').removeClass('show');
			$("#mini-sign").addClass('hide').removeClass('show');
			/*$("#mini-logout").addClass('show').removeClass('hide');*/
			$("#mini-loggedIn").css('display' , 'block');
		}
		$('#showMiniMenu > i').toggleClass('whitecolor flipInX animated');
			});
	
	 function NoSpecialChar(e) {
			e = (e) ? e : (window.event) ? event : null;
			if (e) {
				var num = (e.charCode) ? e.charCode : ((e.keyCode) ? e.keyCode : ((e.which) ? e.which : 0));
				if ((num >= 97 && num <= 122) || (num >= 65 && num <= 90) || (num >= 48 && num <= 57) || num == 8 || num == 9 || (e.key == 'Home')
						|| (e.key == 'End') || (e.key == 'Left') || (e.key == 'Right') || (e.key == 'Up') || (e.key == 'Down') || (e.key == 'Del')) {
					return true;
				} else {
					return false;
				}
			}
		}

		 function PureMobile(e) {

				e = (e) ? e : (window.event) ? event : null;
				if (e) {
					/* numbers, Backspace, Hor Tab,  allowed */
					var num = (e.charCode) ? e.charCode : ((e.keyCode) ? e.keyCode : ((e.which) ? e.which : 0));
					if ((num >= 48 && num <= 57) || num == 8 || num == 9 || (e.key == 'Home') || (e.key == 'End') || (e.key == 'Left')
							|| (e.key == 'Right') || (e.key == 'Up') || (e.key == 'Down') || (e.key == 'Del')) {
						return true;
					} else {
						return false;
					}
				}
			}

    $('#userLogin, #getNewPass, #userReg').addClass('hide');
    $("#modelWindow, .close-icon").on('click', function () {
        $('#modelWindow, #signinCont, #playVideo,#showPic, .close-icon, #requestTicket, .requestCont, #homePagePopup, #womanhood-tc').hide();
        $('#signinCont, #modelWindow, #playVideo,#showPic, .close-icon, #newRegister, #userLogin, #getNewPass, #userReg, #requestTicket, .requestCont, #homePagePopup,  #womanhood-tc').removeClass('show fadeInDown animated reg-height forgot-height' );
    });

    $('#newRegister').on('click', function () {
    	$('#signinCont').addClass('show fadeInDown animated reg-height');
    	$('#userReg, #modelWindow, .close-icon').removeClass('hide');
        $('#signInForm').children().removeClass('error');
    	$('#registerForm').children().removeClass('error');
    	$('#forgotPasswordForm').children().removeClass('error');
    	$('#modelWindow, .close-icon, #userReg').addClass('show');
        $('#userId').val('');
        $('#password').val('');
        $('#userIdR').val('');
        $('#passwordR').val('');
        $('#mobileNo').val('');
        $('#register-errMsg').html('');
        $('#login-errMsg').html('');
        $('#userIdF').val('');
        $('#forgetPassword-errMsg').html('');
    });
    
    $('#mini-reg').on('click', function () {
    	$('#signinCont').addClass('show fadeInDown animated reg-height');
    	$('#userReg, #modelWindow, .close-icon').removeClass('hide');
        $('#signInForm').children().removeClass('error');
    	$('#registerForm').children().removeClass('error');
    	$('#forgotPasswordForm').children().removeClass('error');
    	$('#modelWindow, .close-icon, #userReg').addClass('show');
        $('#userId').val('');
        $('#password').val('');
        $('#userIdR').val('');
        $('#passwordR').val('');
        $('#mobileNo').val('');
        $('#register-errMsg').html('');
        $('#login-errMsg').html('');
        $('#userIdF').val('');
        $('#forgetPassword-errMsg').html('');
    });
    

    $('#custReg').on('click', function () {
     	$('#signinCont').addClass('show fadeInDown animated reg-height');
    	$('#userReg, #modelWindow, .close-icon').removeClass('hide');
        $('#signInForm').children().removeClass('error');
    	$('#registerForm').children().removeClass('error');
    	$('#forgotPasswordForm').children().removeClass('error');
    	$('#modelWindow, .close-icon, #userReg').addClass('show');
        $('#userId').val('');
        $('#password').val('');
        $('#userIdR').val('');
        $('#passwordR').val('');
        $('#mobileNo').val('');
        $('#register-errMsg').html('');
        $('#login-errMsg').html('');
        $('#userIdF').val('');
        $('#forgetPassword-errMsg').html('');
    });
    
    
    
    $('#showLogin').on('click', function () {
        $('#signinCont').addClass('show fadeInDown animated');
        $('#signinCont, #modelWindow, .close-icon').removeClass('hide');
    	$('#registerForm').children().removeClass('error');
        $('#signInForm').children().removeClass('error');
        $('#forgotPasswordForm').children().removeClass('error');
        $('#modelWindow, .close-icon, #userLogin').addClass('show');
        $('#userReg').addClass('hide');
        $('#userId').val('');
        $('#password').val('');
        $('#userIdR').val('');
        $('#passwordR').val('');
        $('#mobileNo').val('');
        $('#register-errMsg').html('');
        $('#login-errMsg').html('');
        $('#userIdF').val('');
        $('#forgetPassword-errMsg').html('');
    });
    
    $('#mini-sign').on('click', function () {
        $('#signinCont').addClass('show fadeInDown animated');
        $('#signinCont, #modelWindow, .close-icon').removeClass('hide');
    	$('#registerForm').children().removeClass('error');
        $('#signInForm').children().removeClass('error');
        $('#forgotPasswordForm').children().removeClass('error');
        $('#modelWindow, .close-icon, #userLogin').addClass('show');
        $('#userReg').addClass('hide');
        $('#userId').val('');
        $('#password').val('');
        $('#userIdR').val('');
        $('#passwordR').val('');
        $('#mobileNo').val('');
        $('#register-errMsg').html('');
        $('#login-errMsg').html('');
        $('#userIdF').val('');
        $('#forgetPassword-errMsg').html('');
    });

    
    $('#forgotPass').on('click', function () {
    	 $('#userIdF').val('');
     	$('#forgetPassword-errMsg').html('');
        $('#getNewPass').addClass('show flipInY animated');
        $('#signinCont').addClass('forgot-height');
        $('#userLogin, #userReg').addClass('hide');
        $('#userLogin, #userReg').removeClass('show flipInY animated');
    });

    $('#newReg').on('click', function () {
        $('#userReg').addClass('show flipInY animated');
        $('#signinCont').addClass('reg-height');
        $('#getNewPass, #userLogin').addClass('hide');
        $('#userLogin, #forgotPass').removeClass('show flipInY animated');
    });

    $('#closeNotify').on('click', function () {
    	$('.nofify').hide();
    	$('.home-bg').addClass('new_height');
    });

    $('#goBack, #goBack2').on('click', function () {
    	$('#userIdF').val('');
    	$('#forgetPassword-errMsg').html('');
        $('#userLogin').addClass('show flipInY animated');
        $('#getNewPass, #userReg').addClass('hide');
        $('#getNewPass, #userReg').removeClass('show flipInY animated');
        $('#signinCont').removeClass('reg-height forgot-height');
    });

    $('#signinCont, #playVideo, #showPic, .requestCont, #homePagePopup, #womanhood-tc').css({
        'position': 'fixed',
        'z-Index': 99,
        'top': function () {
            return (($(window).height() / 2) - ($("#" + this.id).height() / 2));
        },
        'left': function () {
            return (($(window).width() / 2) - ($("#" + this.id).width() / 2));
        }
    });

    $('.amenities li').tooltip({
        placement: 'bottom'
    });


    $(' #modifySearch').unbind('click').on('click', function () {
    	$('#showModify').toggle();

    });


    $("#pnrShowTicket,#pnrCancel").keypress(function(e) {
    	return NoSpecialChar(e);
		});

    $('#pnrDetails, #canInfo').hide();
    $(function () {
        $('#showTicket').on('click', function () {
            $('#pnrDetails, #canInfo').show();
            return false;
        });
    });

    $('#pnrDetails, #pnrInfo, #cancelPNR, #cancelPNRInfo, #canInfo').hide();
    $(function () {
        $('#cancelTicket').on('click', function () {
            $('#pnrDetails, #pnrInfo, #canInfo').show();
            return false;
        });
        $(' #cancelTxt').on('click', function () {
            $('#pnrDetails, #pnrInfo').hide();
            $('#cancelPNR, #cancelPNRInfo').show();
        });
        $(' #backStage').on('click', function () {
            $('#pnrDetails, #pnrInfo').show();
            $('#cancelPNR, #cancelPNRInfo').hide();
        });
    });

    $('#tabs-2, #tabs-3,#tabs-5,#showCode, #showCash, #showloyalty_div').hide();
    $("#tab-1").click(function () {
        $("#tabs-1").show();
        $("#tab-1").addClass('active-tab');
        $("#tab-2, #tab-3,#tab-5").removeClass('active-tab');
        $("#tabs-2, #tabs-3,#tabs-5").hide();
    });

    $('#tab-2').click(function () {
    	$('#tabs-2').show();
    	$("#tab-2").addClass('active-tab');
    	$("#tab-1, #tab-3,#tab-5").removeClass('active-tab');
    	$('#tabs-1, #tabs-3,#tabs-5').hide();
    });

    $('#tab-3').click(function () {
        $('#tabs-3').show();
        $("#tab-3").addClass('active-tab');
        $("#tab-1, #tab-2,#tab-5").removeClass('active-tab');
        $('#tabs-1, #tabs-2,#tabs-5').hide();
    });
    
    $('#tab-5').click(function () {
		$('#tabs-5').show();
		$("#tab-5").addClass('active-tab');
		$("#tab-1,#tab-2,#tab-3").removeClass('active-tab');
		$('#tabs-1,#tabs-2,#tabs-3').hide();
	});

    $('#showOffer').unbind("click").on("click", function (e) {
    	passengerDetailInterface.totalFare = passengerDetailInterface.totalSeatFare + passengerDetailInterface.serviceTax + passengerDetailInterface.rtnServiceTax;
        if(!$('#showOffer').prop("checked")) {
        	$('#showCode').css("display","none");
        	$("#discMsg").empty(); // green msg
        	$("#discountCode").val(""); // text box cash coupon
        	passengerDetailInterface.normalDiscountFare = 0.0;
        	$("#summeryDiscount").empty();
        	$("li#summeryTotalFare").html(passengerDetailInterface.totalFare);
        } else {
        	$('#showCode').css("display","block");
        	$("#cashCouponMsg").empty(); // green msg
        	$("#cashCouponVal").val(""); // text box cash coupon
        	passengerDetailInterface.normalDiscountFare = 0.0;
        	$("#summeryDiscount").empty();
        	$("li#summeryTotalFare").html(passengerDetailInterface.totalFare);
        	if($("#showCoupon").prop("checked")) {
        		$('#showCash').css("display","none");
        		$("#showCoupon").prop("checked", false);
        	}
        	$("#discountCode").focus();
        }
        if($('#showOffer').attr("checked") == undefined){
        	$("#summeryDiscount").html("");
        	var totalFare=passengerDetailInterface.calculateTotalFare;
        	$("#summeryTotalFare").text(totalFare);
        	$("#discMsg").html("");
        	passengerDetailInterface.availableDiscountCode=null;
        }
        
    });

    $('#showCoupon').unbind("click").on("click", function (e) {
    	passengerDetailInterface.totalFare = passengerDetailInterface.totalSeatFare + passengerDetailInterface.serviceTax + passengerDetailInterface.rtnServiceTax;
        if(!$('#showCoupon').prop("checked")) {
        	$('#showCash').css("display","none");
        	$("#cashCouponMsg").empty(); // green msg
        	$("#cashCouponVal").val(""); // text box cash coupon
        	passengerDetailInterface.normalDiscountFare = 0.0;
        	$("#summeryDiscount").empty();
        	$("li#summeryTotalFare").html(passengerDetailInterface.totalFare);
        } else {
        	$('#showCash').css("display","block");
        	$("#discMsg").empty(); // green msg
        	$("#discountCode").val(""); // text box cash coupon
        	passengerDetailInterface.normalDiscountFare = 0.0;
        	$("#summeryDiscount").empty();
        	$("li#summeryTotalFare").html(passengerDetailInterface.totalFare);
        	if($("#showOffer").prop("checked")) {
        		$('#showCode').css("display","none");
        		$("#showOffer").prop("checked", false);
        	}
        	
        	$("#cashCouponVal").focus();
        }
        if($('#showCoupon').attr("checked") == undefined){
        	$("#summeryDiscount").html("");
        	var totalFare=passengerDetailInterface.calculateTotalFare;
        	$("#summeryTotalFare").text(totalFare);
        	$("#cashCouponMsg").html("");
        	passengerDetailInterface.availableDiscountCode=null;
        }
    });

    $('#showloyalty').unbind("click").on("click", function (e) {
    	passengerDetailInterface.totalFare = passengerDetailInterface.totalSeatFare + passengerDetailInterface.serviceTax + passengerDetailInterface.rtnServiceTax;
    	if(!$('#showloyalty').prop("checked")) {
    		$('#showloyalty_div').css("display","none");
    		passengerDetailInterface.clpDiscountFare = 0.0;
    		$("#summeryDiscount").empty();
    		$("li#summeryTotalFare").html(passengerDetailInterface.totalFare);
    	} 
    	else {
    		$("#discMsg").empty();
    		passengerDetailInterface.clpDiscountFare = 0.0;
    		$("#summeryDiscount").empty();
    		$("li#summeryTotalFare").html(passengerDetailInterface.totalFare);
    		var cardNo = $("#mobNo").val();
    		if(cardNo != ""){
    			$.ajax({
    				type : "POST",
    				url : "/parveen-travels/getloyaltypoints/"+cardNo+".json",
    				headers : {"Content-Type" : "application/json"},
    				beforeSend: function() {
							$("#loyaltyBlur").removeClass("hide");
					},
    				dataType:'json',
    				success : function(response) {
    					var data = response.data;
    					if (data.returnStatus==1) {
    						$("#loyaltyMsg").text("Your points: " + data.currentPoints);
    						$("#loyaltyPointsView").text("Your points: " + data.currentPoints);
    						$('#showloyalty_div').css("display","block");
    						if(data.currentPoints >= 200){
    							$("#loyalty_gen_otp").removeClass('hide').addClass('show');
    							passengerDetailInterface.availableclpDiscount = true;
    							passengerDetailInterface.clpPointvalue = data.pointValue;
    							passengerDetailInterface.availableclpPoints = data.currentPoints;
    						}
    						else{
    							passengerDetailInterface.availableclpDiscount = false;
    							passengerDetailInterface.clpPointvalue = data.pointValue;
    							passengerDetailInterface.availableclpPoints = data.currentPoints;
    						}
    					}
    					else{
    						$('#showloyalty_div').css("display","block");
    						$("#loyaltyMsg").html("Your are not yet registered. Please proceed transaction to automatically get registered with Parveen Rewardz.");
    					}
    				},
    				complete: function() {
						$("#loyaltyBlur").addClass("hide");
					}
    			});
    		}
    		else{
    			alert("Please enter mobile number");
    		}
    		if($("#showOffer").prop("checked")) {
    			$('#showCode').css("display","none");
    			$("#showOffer").prop("checked", false);
    		}
    		if($("#showCoupon").prop("checked")) {
        		$('#showCash').css("display","none");
        		$("#showCoupon").prop("checked", false);
        	}
    		$("#cashCouponVal").focus();
    	}
    	if($('#showloyalty').attr("checked") == undefined){
    		$("#summeryDiscount").html("");
    		var totalFare=passengerDetailInterface.calculateTotalFare;
    		$("#summeryTotalFare").text(totalFare);
    		$("#cashCouponMsg").html("");
    		passengerDetailInterface.availableDiscountCode=null;
    	}
    });

	/*Boarding*/
	$(".showArrPoints").mouseover(function () {
		var idclass=this.id;
		 $(this).closest(".showArrPoints").addClass('brd-points-act');
        $("#arrpoints"+idclass).show();
    });
	$(".showArrPoints").mouseout(function () {
		var idclass=this.id;
		$(this).closest(".showArrPoints").removeClass('brd-points-act');
        $("#arrpoints"+idclass).hide();
    });

	$(".shwBoarding").mouseover(function() {
		var idclass=this.id;
		 $(this).closest(".shwBoarding").addClass('brd-points-act');
	    $("#boarding-points"+idclass).show();
	 });
	$(".shwBoarding").mouseout(function () {
		var idclass=this.id;
		$(this).closest(".shwBoarding").removeClass('brd-points-act');
        $("#boarding-points"+idclass).hide();
    });

	/* via station code starts */
	$(".shwVia").mouseover(function() {
		var idclass=this.id;
		 $(this).closest(".shwVia").addClass('brd-points-act');
	    $("#viaStation"+idclass).show();
	 });
	$(".shwVia").mouseout(function () {
		var idclass=this.id;
		$(this).closest(".shwVia").removeClass('brd-points-act');
        $("#viaStation"+idclass).hide();
    });

	/* via station code ends */


	$('#showVideo').on('click', function () {
        $('#modelWindow, #playVideo').removeClass('hide');
        $('#modelWindow, #playVideo').addClass('show');
    });
	$('#womanhood').on('click', function () {
		$('#modelWindow, #womanhood-tc').removeClass('hide');
		$('#modelWindow, #womanhood-tc').addClass('show');
		$('#womanhood-tc').addClass('fadeInDown animated');
	});
	$('#showPicture').on('click', function () {
        $('#modelWindow, #playVideo').removeClass('hide');
        $('#modelWindow, #playVideo').addClass('show');
    });

	$('.showBusPic').on('click', function () {
		var busPic =  this.id;
		$("#iframePic").attr("src",busPic);
        $('#modelWindow, #showPic').removeClass('hide');
        $('#modelWindow, #showPic').addClass('show');
    });

	$('#showVideo').on('click', function () {
        $('#modelWindow, #playVideo').removeClass('hide');
        $('#modelWindow, #playVideo').addClass('show');
    });
	$('#showPicture').on('click', function () {
        $('#modelWindow, #playVideo').removeClass('hide');
        $('#modelWindow, #playVideo').addClass('show');
    });

	$('#hideVideo').on('click',function () {
		 $("#iframeVideo").empty().attr("src",$("#iframeVideo").attr("src"));
	});

	$("#loggedIn").mouseover(function () {
		$(".sub-menu").addClass("show").removeClass("hide");
		$.ajax({
			type : "POST",
			url : "/parveen-travels/agent/currentUser.json",
			headers: {
				'Accept': 'application/json',
				'Content-Type': 'application/json'
			},
			success : function(response) {
				if(response.role.code=="AGT" || response.role.code=="APIAGT"){
					$(".balance b").empty().text(response.currentBalance);

				}
			}
		});
	});

	$("#loggedIn").mouseout(function () {
		$(".sub-menu").removeClass("show").addClass("hide");
	});
	$('#hidePic').on('click',function () {
		 $("#iframeVideo").empty().attr("src",$("#iframePic").attr("src"));
	});


	$('#myAccount').on('click', function () {
		window.location.href = "/parveen-travels/myAccount";
    });
	
	
	$('#back-top').hide();
	$(function() {
		$(window).scroll(function() {
			if ($(this).scrollTop() > 150) {
				$('#back-top').fadeIn();
			} else {
				$('#back-top').fadeOut();
			}
		});

		$('#back-top, #mini-back-top').click(function() {
			$('body,html').animate({
				scrollTop : 0
			}, 800);
			return false;
		});
		
		$('#down').click(function() {
			$('body,html').animate({
				scrollTop : $('body').height()
			}, 800);
			return false;
		});
	});

	$("#googleLogin").click(function(){

		loginGoogle();
	});

	function updateButton(response) {
		var accessToken = response.authResponse.accessToken;
	    var button = document.getElementById('fb-auth');

	    if (response.authResponse) {
	      FB.api('/me', function(response) {
	    	  var socialLogin = "/parveen-travels/socialLogin/FBLogin.json";
	     	  var data = {"uid": response.id , "email":response.email , "name" : response.name,"firstname":response.first_name , "lastname":response.last_name,"accessToken" :accessToken} ;
	    	  createAccount(data,socialLogin,"FBLogin");
	      });
	      button.onclick = function() {
		        FB.logout(function(response) {
		        	$("#bgmaskb").hide();
		        	$("#auth").hide();
		    	});
	      };
	    }
	  }

	$('#faceBookLogin').on('click',function(){
		FB.init({ appId: '259953837521848',
		       status: true,
		       cookie: true,
		       xfbml: true,
		       oauth: true});

			 FB.login(function(response) {
			      if (response.authResponse) {
			          FB.api('/me', function(response) {
			        	 $("#lgTyp").val("1");
			        	 var VALIDURL = "/parveen-travels/socialLogin/FBLogin.json";
			     	     var data = {"uid": response.id , "email":response.email , "firstname":response.first_name , "lastname":response.last_name , "accessToken" : accessToken} ;
			       		 createAccount(data,VALIDURL,"FBLogin");
			            });
			        } else {
			        	$("#bgmaskb").hide();
			        	$("#auth").hide();
			            //user cancelled login or did not grant authorization
			        	}
		   }, {scope:'email'});
			 FB.getLoginStatus(updateButton);
			 FB.Event.subscribe('auth.statusChange',updateButton);
			  // run once with current status and whenever the status changes
	});

/*	$('a').click(function(){
	    $('html, body').animate({
	        scrollTop: $( $.attr(this, 'href') ).offset().top - 150
        }, 1000);
	    return false;
	});*/



	/*js for menu bar active link*/

/*	var url=unescape(window.location.href);
	if(url.indexOf("home")!=-1 || url.indexOf("home")!=-1 ){
		hlmenulink("homePageActive");
	}
	else if(url.indexOf("print")!=-1 || url.indexOf("print")!=-1 ){
		hlmenulink("printTicket");
	}
	else if(url.indexOf("cancel")!=-1 || url.indexOf("cancel")!=-1 ){
		hlmenulink("cancelTicket");
	}
	else if(url.indexOf("deals")!=-1 || url.indexOf("deals")!=-1 ){
		hlmenulink("offerDealsPage");
	}
	else if(url.indexOf("agentReg")!=-1 || url.indexOf("agentReg")!=-1 ){
		hlmenulink("agentRegistrationPage");
	}
	else if(url.indexOf("contactus")!=-1 || url.indexOf("contactus")!=-1 ){
		hlmenulink("contactUsPage");
	}

	function hlmenulink(linkid){
		$("nav ul li a").removeClass("selected");
		$("#"+linkid).addClass("selected");
	}*/
	
	/*code for rwd	auto-focus*/
	
	/*$('#fs').focus(function(){
		alert('test');
	    $(this).next('select').focus();
	    alert('test2');
	});*/
	
	$("#fs").click(function () {
		 $(this).next('select').focus();
		});
	
});




//google Login
var OAUTHURL = 'http://accounts.google.com/o/oauth2/auth?';
var VALIDURL = 'https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=';
var SCOPE = 'https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email';
var CLIENTID = '854357765335-dqipk0fgm60bupbas44lsj889cijd1f6.apps.googleusercontent.com';
//var CLIENTID = '224220123694.apps.googleusercontent.com';
var REDIRECT = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port: '')+'/parveen-travels/googleLogin';
var IEREDIRECT = window.location.protocol+'/parveen-travels/static/googleIERedirect.html';
var LOGOUT = 'http://accounts.google.com/Logout';
var TYPE = 'token';
var _url = OAUTHURL + 'scope=' + SCOPE + '&client_id=' + CLIENTID
		+ '&redirect_uri=' + REDIRECT + '&response_type=' + TYPE;
var acToken;
var tokenType;
var expiresIn;
var user;
var loggedIn = false;
function loginGoogle() {
	var win;
	$("#bgmaskb").show();
//	if(navigator.appName=="Microsoft Internet Explorer"){
//		 win         =   window.open(IEREDIRECT, "windowname1", 'width=500, height=500,resizable=1,top=200,left=400,scrollbars=1,menubar=0,fullscreen=no');
//	}else{
    var win         =   window.open(_url, "windowname1", 'width=800, height=600');

    var pollTimer   =   window.setInterval(function() {
        try {
            console.log(win.document.URL);
            if (win.document.URL.indexOf(REDIRECT) != -1) {
                window.clearInterval(pollTimer);
                var url =   win.document.URL;
                acToken =   gup(url, 'access_token');
                tokenType = gup(url, 'token_type');
                expiresIn = gup(url, 'expires_in');
                win.close();

                validateToken(acToken);
            }
        } catch(e) {
        }
    }, 100);
//   }
    var timer = setInterval(function() {
        if(win.closed) {
            clearInterval(timer);
            $("#bgmaskb").hide();
            $("#auth").hide();
        }
    }, 100);
}
function validateToken(token) {
    $.ajax({
        url: VALIDURL + token,
        data: null,
        success: function(responseText){
            getUserInfo();
        },
        error: function(responseText){
        	$("#bgmaskb").hide();
        	 $("#auth").hide();
        },
        dataType: "jsonp"
    });
}

function getUserInfo() {

    $.ajax({
        url: 'https://www.googleapis.com/oauth2/v1/userinfo?access_token=' + acToken,
        data: null,
        success: function(resp) {
        	var socialLogin = "/parveen-travels/socialLogin/GoogleLogin.json";
	     	var data = {"uid": resp.id , "email":resp.email , "name" : resp.name,"firstname":resp.given_name , "lastname":resp.family_name,"accessToken" :acToken} ;
            createAccount(data,socialLogin,"GoogleLogin");
        },
        error: function(resp){
        	$("#bgmaskb").hide();
        	$("#auth").hide();
        },
        dataType: "jsonp"
    });
}



/*function ieval(url){
	acToken =   gup(url, 'access_token');
	validateToken(acToken);
}
*/
//credits: http://www.netlobo.com/url_query_string_javascript.html
function gup(url, name) {

	name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
	var regexS = "[\\#&]" + name + "=([^&#]*)";
	var regex = new RegExp(regexS);
	var results = regex.exec(url);
	if (results == null)
		return "";
	else
		return results[1];
}

function createAccount(dataGot,socialLogin,LoginType){
	$.ajax({
		type : "POST",
		url : socialLogin,
		dataType: "json",
		async: false,
		headers: {
			'Accept': 'application/json',
			'Content-Type': 'application/json'
		},
		data: JSON.stringify(dataGot),
		success : function(response) {
			if(response.success)
			{
				if(response.data != null){
		    		var data = {'email' : response.data.email,'password' : '','logintype':LoginType};
		    		ajaxService.getLogin(data);
				}
			}
			else
			{
				var dataGot = JSON.parse(response);

				$("#login-errMsg").html(dataGot.error.globalErrors[0]);
				$("#login-errMsg").show();
				setTimeout(function() {
					$("#login-errMsg").hide();
				}, 5000);
			}

		},
		error : function(e) {
			$("#login-errMsg").html("Some technical issue..Please try again later");
			$("#login-errMsg").show();
			setTimeout(function() {
				$("#login-errMsg").hide();
			}, 5000);
		}
	});

//Facebook login

	//facebook login

}

