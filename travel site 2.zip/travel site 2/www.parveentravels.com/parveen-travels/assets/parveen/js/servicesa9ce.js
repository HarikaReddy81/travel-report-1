var AjaxService  =function(){
	var self = this;	
	rootUrl= "/parveen-travels/";
	registeration=false;
};
AjaxService.prototype={
	getLogin:function(data){		
		$.ajax({
			type : "post",
			url : rootUrl+"processLogin",			
			async: false,
			dataType :"json",
			headers: {				
				'Content-Type': 'application/x-www-form-urlencoded'
			},
			data:data,			
			success : function(response) {				
				if(response.success==true)
				{	
					sucessHandler.login(response);
				}
				else
				{
					failureHandler.login(405,response);
				}  
				
			},
			error : function(e) {						
				failureHandler.login(e);				
			}
		});			
	},
	getPopUp :function(){
		$.ajax({
			type : "post",
			url : rootUrl+"agent/currentUser.json",			
			async: false,
			success : function(response) {				
				if(response.role.code=="AGT")
				{
					$(".close-icon").click();
					//alert("hello agent");
					
				}
			},
			error : function(e) {						
			}
		});		
	},
	register:function(data)
	{
		$.ajax({
			type : "post",
			url : rootUrl+"register.json",			
			async: false,
			dataType :"json",
			headers: {
				'Accept': 'application/json',
				'Content-Type': 'application/json'
			},
			data:JSON.stringify(data),			
			success : function(response) {				
					sucessHandler.register(response);
					ajaxService.registeration=true;
				
			},
			error : function(e) {						
				failureHandler.register(e);	
				ajaxService.registeration=false;
			}
		});			
	},
	forgetPassword:function(data)
	{
		$.ajax({
			type : "POST",
			url : rootUrl+"forgetPassword.json",			
			dataType: "json",
			async: false,
			headers: {
				'Accept': 'application/json',
				'Content-Type': 'application/json'
			},
			data: JSON.stringify(data),			
			success : function(response) {	
				if(response.success)
				{	
					sucessHandler.forgetPassword(response);
				}
				else
				{
					failureHandler.forgetPassword(405,response);
				}	  
				
			},
			error : function(e) {						
				failureHandler.forgetPassword(e);				
			}
		});
	},
	getStaions:function(data)
	{
		$.ajax({
			type : "get",
			url : rootUrl+"booking/stations.json",			
			dataType: "json",
			async: false,
			headers: {
				'Accept': 'application/json',
				'Content-Type': 'application/json'
			},
			data:data,			
			success : function(response) {					  
				sucessHandler.getStations(response);
			},
			error : function(e) {						
				failureHandler.getStations(e);				
			}
		});	
	},
	getScheduleList :function(data)
	{
		$.ajax({
			type : "POST",
			url : rootUrl+"booking/search.json",			
			dataType: "json",
			async: false,
			headers: {
				'Accept': 'application/json',
				'Content-Type': 'application/json'
			},
			data: JSON.stringify(data),			
			success : function(response) {					  
				sucessHandler.getScheduleList(response);
			},
			error : function(e) {						
				failureHandler.getScheduleList(e);				
			}
		});	
	},
	showTicket:function(pnr)
	{
		$.ajax({
			type : "GET",
			url : rootUrl+"booking/"+pnr+"/showTicket",		
			async: false,		
			success : function(response) {	
				if(response == '{"success":false,"error":{"globalErrors":["Invalid PNR"]}}'){
					$("#errorMsg").html("Invalid PNR");
					$("#errorMsg").show();
					$("#successMsg").html("");
					$("#successMsg").hide();
					$("#printTicketDiv").html("");
					
				}else{
					sucessHandler.showTicket(response);
				}
				
				
			},
			error : function(e) {						
				failureHandler.showTicket(e);				
			}
		});
	},
	confirmCancel:function(pnr,data)
	{
		$.ajax({
			type : "POST",
			url : rootUrl+"booking/"+pnr+"/cancel",		
			dataType: "json",
			async: false,
			headers: {
				'Accept': 'application/json',
				'Content-Type': 'application/json'
			},
			data: JSON.stringify(data),	
			success : function(response) {					  
				sucessHandler.confirmCancel(response);
			},
			error : function(e) {						
				failureHandler.confirmCancel(e);				
			}
		});
	},
	cancelTicket:function(pnr)
	{
		$.ajax({
			type : "GET",
			url : rootUrl+"booking/"+pnr+"/showCancel",		
			async: false,		
			success : function(response) {
				if(response == '{"success":false,"error":{"globalErrors":["Invalid PNR"]}}'){
					$("#errorMsg").html("Invalid PNR");
					$("#errorMsg").show();
					$("#successMsg").html("");
					$("#successMsg").hide();
					$("#cancelTicketDiv").html("");
					
				}else{
					sucessHandler.cancelTicket(response);
				}

			},
			error : function(e) {						
				failureHandler.cancelTicket(e);				
			}
		});
	},
	sendSms:function(pnr)
	{
		var dataSent={"pnr":pnr};
		$.ajax({
			type : "POST",
			url : rootUrl+"booking/sendsms.json",
			data : JSON.stringify(dataSent),
			dataType: "json",
			async: false,
			headers: {
				'Accept': 'application/json',
				'Content-Type': 'application/json'
			},				
			success : function(response) {					  
				sucessHandler.sendSms(response,pnr);
			},
			error : function(e) {						
				failureHandler.sendSms(e);				
			}
		});
	}
};
window.ajaxService = new AjaxService();