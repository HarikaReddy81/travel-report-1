var HomePageInterface = function() {
	this.stationUrl = "booking/stations.json";
	this.latestNewsAndSliderUrl = "booking/getLatestNewsAndSliderImage.json";
	this.sliderCode = "SLIDER";
	this.newsCode = "LATEST";
	this.newsInfo = "NEWSINFO";
	this.printAdCode = "PRINTAD";
	this.acConnectivityText = "A/C Connectivity At Madurai";
	this.busConnectivity = "Pick up in Sankarankoil and connectivity At Rajapalayam";
	this.midNightPopup = "Departure/Arrival time is tentative. Kindly confirm the Departure / Arrival time of your Selected bus from our Trichy Office - Contact No. - 0431-2419811.";
	this.PackagePopup = "This Package includes:\n * Up & Down bus tickets \n * Breakfast & Lunch  included \n* DharmaDharshan / Spl Dharshan \n* Ladies with T-Shirts, Jeans & Skirts are not allowed \n* Gents with Shorts are not allowed";
	this.PackagePopupExtra = "This Package includes: \n * Up & Down bus tickets \n* Breakfast & Lunch  included \n* DharmaDharshan / Spl Dharshan \n* Moderate Accommodation with freshup facilities \n*Ladies with T-Shirts, Jeans & Skirts are not allowed \n * Gents with Shorts are not allowed";
	this.vanPickUpAlert = "Parveen Travels has introduced connecting service between Pondicherry and Villupuram through Luxurious A/c Mini Buses.\nPassengers can board the destination of their choices from Villupuram.";
	this.allStations;
};
HomePageInterface.prototype = {
	init: function() {
		this.loadstations();
		this.bindTripEvents();
		this.binddateevents();
		this.bindsearchevents();
		this.bindTopRouteEvents();
		//this.bindLatestNewsAndSlider();
		//this.loadHide();
		//this.getCookieValues();
	},
	isAlpha: function(e) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if (charCode > 31 && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 122)) {
			return false;
		}
		return true;
	},
	loadHide: function() {
		$("#radio4").on("click", function() {
			$("#return").addClass("hide");
		});
		$("#radio5").on("click", function() {
			$("#return").removeClass("hide");
		});
	},
	loadstations: function() {
		var _self = this;
		$.ajax({
			url: _self.stationUrl,
			method: "GET",
			headers: {
				'Content-Type': 'application/json'
			},
			success: function(data) {
				var fromcookieid = _self.getCookie("fromStationId");
				var tocookieid = _self.getCookie("toStationId");
				_self.buildstations(data.data, fromcookieid, tocookieid, _self);
			},
			error: function() {}
		});
	},
    //removed on 20181218
    
	bindTopRouteEvents: function() {
		$(".list1 ul li").click(function() {
			var text = $(this).text().split("-");
			var fromObj = $.grep(homeinterface.allStations, function(e) {
				if (e.stationName == text[0]) {
					return e;
				} else {
					return null;
				}
			});
			var toObj = $.grep(homeinterface.allStations, function(e) {
				if (e.stationName == text[1]) {
					return e;
				} else {
					return null;
				}
			});
			$("#fs1").attr('value', fromObj[0].id);
			$("#ts1").attr('value', toObj[0].id);
			$("#src").val(fromObj[0].stationName);
			$("#ts").val(toObj[0].stationName);
			var d = new Date();
			var curr_date = d.getDate();
			var curr_month = d.getMonth() + 1;
			var curr_year = d.getFullYear();
			$("input[name='travelDate']").val(curr_date + "/" + curr_month + "/" + curr_year);
			$("#hsearch").click();
		});
		$("#tour1-pilgrim").click(function() {
			//var texts = $(this).text().split("-");
			$('[name=originStationId]').val(43);
			$('[name=destinationStationId]').val(108);
			//var d = new Date();
			//var curr_date = d.getDate();
			//var curr_month = d.getMonth() + 1;
			//var curr_year = d.getFullYear();
			//$("input[name='travelDate']").val(curr_date + "/" + curr_month + "/" + curr_year);
			//$('[name=travelDate]').val(curr_date + "/" + curr_month + "/" + curr_year);
			//alert('from' + texts[0] + ' to ' +texts[1] + 'today date:' + curr_date + "/" + curr_month + "/" + curr_year );
			//$("#hsearch").click();
			$('[name=travelDate]').focus();
		});
		$("#tour2-pilgrim").click(function() {
			$('[name=originStationId]').val(81);
			$('[name=destinationStationId]').val(108);
			$('[name=travelDate]').focus();
		});
	},
	
    //end removed on 20181218
    //added on 20181218
    //additional feature for top routes url passed with users date
    /*bindTopRouteEvents: function() {
		$(".list1 ul li").click(function() {
			var text = $(this).text().split("-");
			var fromObj = $.grep(homeinterface.allStations, function(e) {
				if (e.stationName == text[0]) {
					return e;
				} else {
					return null;
				}
			});
			var toObj = $.grep(homeinterface.allStations, function(e) {
				if (e.stationName == text[1]) {
					return e;
				} else {
					return null;
				}
			});
            $("#datbtn").click();
            $( "#date_ex" ).datepicker({
                dateFormat: "dd-mm-yy",numberOfMonths:[1,2],
                onSelect: function(dateText, inst) {
                    var date = $(this).val();
                    $("#start").text(dateText);
                    var data =$('#start').text();
                    var arr = data.split('-');
			         var curr_date = arr[0];
			         var curr_month = arr[1];
			         var curr_year = arr[2];
			         $("input[name='travelDate']").val(curr_date + "/" + curr_month + "/" + curr_year);
                     $("#fs1").attr('value', fromObj[0].id);
			         $("#ts1").attr('value', toObj[0].id);
			         $("#src").val(fromObj[0].stationName);
			         $("#ts").val(toObj[0].stationName);
                    if(curr_date != '\0'){
                        $("#hsearch").click();
                    }
                }
            });
		});
	},*/
    //end added on 20181218
	bindTripEvents: function() {
		$('input:radio[name="tripChoice"]').unbind("change").on("change", function() {
			if ($(this).is(':checked') && $(this).val() == 'oneWay') {
				$("#todate").val("");
				$("#tdate").datepicker("option", "maxDate", moment().add('days', 90).format("DD/MM/YYYY"));
				$("#todate").prop("disabled", true);
			} else if ($(this).is(':checked') && $(this).val() == 'returnTrip') {
				$("#todate").prop("disabled", false);
			}
		});
	},
	buildstations: function(data, fromcookieid, tocookieid, _self) {
		var _self = this;
		var stationPoints = 0;
		var stations = new Array();
		for (var i = 0; i < data.length; i++) {
			if (data[i].stationPoints != undefined && data[i].stationPoints.length > 0) {
				stations[stationPoints] = data[i];
				stationPoints++;
			}
		}
		stations.sort(function(a, b) {
			if (a.stationName > b.stationName) return 1;
			else if (a.stationName < b.stationName) return -1;
			else return 0;
		});
		var fromOptions = "<ul class='fromList' style='display:none;'>";
		var toOptions = "<ul class='toList' style='display:none;'>";
		var options = "";
		$.each(stations, function(i) {
			options += "<li id=" + stations[i].id + ">" + stations[i].stationName + "</li>";
		});
		fromOptions += options + "</ul>";
		toOptions += options + "</ul>";
		$("#fromStationDiv").append(fromOptions);
		$("#toStationDiv").append(toOptions);
		_self.stationChange();
		_self.allStations = stations;
	},
	stationChange: function() {
		var _self = this;
		var fromSearchFlag = true;
		var toSearchFlag = true;
		var fromResult = "";
		var toResult = "";
		var fromScrollIndex = 0;
		var toScrollIndex = 0;
		String.prototype.equalstring = function(p) {
			var i, j, r, p = isNaN(p) ? 4 : p > 10 ? 10 : p < 4 ? 4 : p,
				m = {
					BFPV: 1,
					CGJKQSXZ: 2,
					DT: 3,
					L: 4,
					MN: 5,
					R: 6
				},
				r = (s = this.toUpperCase().replace(/[^A-Z]/g, "").split("")).splice(0, 1);
			for (i in s)
				for (j in m)
					if (j.indexOf(s[i]) + 1 && r[r.length - 1] != m[j] && r.push(m[j])) break;
			return r.length > p && (r.length = p), r.join("") + (new Array(p - r.length + 1)).join("0");
		};
		$("#src").keypress(function(e) {
			if (e.keyCode == 13) {
				$("#src").val($(".from-station-list-min[data-id='" + fromScrollIndex + "']").text());
				$("#orgList").hide();
				e.preventDefault();
				fromSearchFlag = false;
			}
		});
		$("#src").unbind("keyup").on('keyup', function(e) {
			if (!fromSearchFlag) {
				fromSearchFlag = true;
				return false;
			}
			var searchText = $(this).val().trim();
			fromResult = "";
			if (searchText == "") {
				$("#orgList").hide();
				return false;
			}
			if (e.keyCode == 40) {
				$(".from-station-list-min[data-id='" + fromScrollIndex + "']").removeClass("hb");
				fromScrollIndex++;
				if (fromScrollIndex >= $(".from-station-list-min").length) {
					$("#orgList").scrollTop(0);
					fromScrollIndex = 0;
				}
				if (fromScrollIndex > 2) {
					$("#orgList").scrollTop($("#orgList").scrollTop() + 22);
				}
				$(".from-station-list-min[data-id='" + fromScrollIndex + "']").addClass("hb");
			} else if (e.keyCode == 38) {
				$(".from-station-list-min[data-id='" + fromScrollIndex + "']").removeClass("hb");
				fromScrollIndex--;
				if (fromScrollIndex < 0) {
					fromScrollIndex = $(".from-station-list-min").length - 1;
					$("#orgList").scrollTop(fromScrollIndex * 22);
				}
				if (fromScrollIndex < $(".from-station-list-min").length - 3) {
					$("#orgList").scrollTop($("#orgList").scrollTop() - 22);
				}
				$(".from-station-list-min[data-id='" + fromScrollIndex + "']").addClass("hb");
			} else {
				var fromListCount = 0;
				fromScrollIndex = 0;
				var j = 0,
					x = searchText.trim(),
					y = x.length,
					a = eval('/^' + x + '/i');
				if (y < 1) {
					return;
				}
				$('.fromList > li').each(function() {
					var m = $(this).text();
					if (a.test(m)) {
						if (fromListCount == 0) {
							fromResult += "<a href=\"#\"><div data-id='" + fromListCount + "' class='from-station-list-min hb' id='" + $(this).attr('id') + "' value='" + $(this).text() + "'>" + $(this).text() + "</div></a> ";
						} else {
							fromResult += "<a href=\"#\"><div data-id='" + fromListCount + "' class='from-station-list-min' id='" + $(this).attr('id') + "' value='" + $(this).text() + "'>" + $(this).text() + "</div></a> ";
						}
						fromListCount++;
						j = j + 1;
					}
				});
				if (j == 0) {
					$('.fromList > li').each(function() {
						var m = $(this).text();
						if (x.equalstring() == m.equalstring()) {
							if (fromListCount == 0) {
								fromResult += "<a href=\"#\"><div data-id='" + fromListCount + "' class='from-station-list-min hb' id='" + $(this).attr('id') + "' value='" + $(this).text() + "'>" + $(this).text() + "</div></a> ";
							} else {
								fromResult += "<a href=\"#\"><div data-id='" + fromListCount + "' class='from-station-list-min' id='" + $(this).attr('id') + "' value='" + $(this).text() + "'>" + $(this).text() + "</div></a> ";
							}
							fromListCount++;
							j = j + 1;
						}
					});
				}
				var height = "200px";
				if (fromListCount < 5) {
					height = fromListCount * 22 + 1 + 'px';
				}
				$("#orgList").height(height);
				if (fromListCount == 2) {
					$("#orgList").removeAttr("style").attr("style", "height");
				}
				$("#orgList").html(fromResult);
				$("#orgList").show();
			}
		});
		$("#ts").keypress(function(e) {
			if (e.keyCode == 13) {
				e.preventDefault();
				$("#ts").val($(".to-station-list-min[data-id='" + toScrollIndex + "']").text());
				$("#desList").hide();
				toSearchFlag = false;
			}
		});
		$("#ts").unbind("keyup").on('keyup', function(e) {
			if (!toSearchFlag) {
				toSearchFlag = true;
				return false;
			}
			var searchText = $(this).val().trim();
			searchText = searchText.toLowerCase();
			searchText = searchText.replace(/\s+/g, '');
			toResult = "";
			if (searchText == "") {
				$("#desList").hide();
				return false;
			}
			if (e.keyCode == 40) {
				$(".to-station-list-min[data-id='" + toScrollIndex + "']").removeClass("hb");
				toScrollIndex++;
				if (toScrollIndex >= $(".to-station-list-min").length) {
					$("#desList").scrollTop(0);
					toScrollIndex = 0;
				}
				if (toScrollIndex > 2) {
					$("#desList").scrollTop($("#desList").scrollTop() + 22);
				}
				$(".to-station-list-min[data-id='" + toScrollIndex + "']").addClass("hb");
			} else if (e.keyCode == 38) {
				$(".to-station-list-min[data-id='" + toScrollIndex + "']").removeClass("hb");
				toScrollIndex--;
				if (toScrollIndex < 0) {
					toScrollIndex = $(".to-station-list-min").length - 1;
					$("#desList").scrollTop(toScrollIndex * 22);
				}
				if (toScrollIndex < $(".to-station-list-min").length - 3) {
					$("#desList").scrollTop($("#desList").scrollTop() - 22);
				}
				$(".to-station-list-min[data-id='" + toScrollIndex + "']").addClass("hb");
			} else {
				var toListCount = 0;
				toScrollIndex = 0;
				var j = 0,
					x = searchText.trim(),
					y = x.length,
					a = eval('/^' + x + '/i');
				if (y < 1) {
					return;
				}
				$('.toList > li').each(function() {
					var m = $(this).text();
					if (a.test(m)) {
						if (toListCount == 0) {
							toResult += "<a href=\"#\"><div data-id='" + toListCount + "' class='to-station-list-min hb' id='" + $(this).attr('id') + "' value='" + $(this).text() + "'>" + $(this).text() + "</div></a> ";
						} else {
							toResult += "<a href=\"#\"><div data-id='" + toListCount + "' class='to-station-list-min' id='" + $(this).attr('id') + "' value='" + $(this).text() + "'>" + $(this).text() + "</div></a> ";
						}
						toListCount++;
						j = j + 1;
					}
				});
				if (j == 0) {
					$('.toList > li').each(function() {
						var m = $(this).text();
						if (x.equalstring() == m.equalstring()) {
							if (toListCount == 0) {
								toResult += "<a href=\"#\"><div data-id='" + toListCount + "' class='to-station-list-min hb' id='" + $(this).attr('id') + "' value='" + $(this).text() + "'>" + $(this).text() + "</div></a> ";
							} else {
								toResult += "<a href=\"#\"><div data-id='" + toListCount + "' class='to-station-list-min' id='" + $(this).attr('id') + "' value='" + $(this).text() + "'>" + $(this).text() + "</div></a> ";
							}
							toListCount++;
							j = j + 1;
						}
					});
				}
				var height = "200px";
				if (toListCount < 5) {
					height = toListCount * 22 + 1 + 'px';
				}
				$("#desList").height(height);
				if (toListCount == 2) {
					$("#desList").removeAttr("style").attr("style", "height");
				}
				$("#desList").html(toResult);
				$("#desList").show();
			}
		});
		$(document).on('mousedown', '.from-station-list-min', function() {
			var id = $(this).attr('id');
			var value = $(this).attr('value');
			$("#src").attr('value', id);
			$("#src").attr('value', value);
			$("#src").val(value);
			$("#orgList").hide();
		});
		$(document).on('mousedown', '.to-station-list-min', function() {
			var id = $(this).attr('id');
			var value = $(this).attr('value');
			$("#ts").attr('value', id);
			$("#ts").attr('value', value);
			$("#ts").val(value);
			$("#desList").hide();
		});
		$(document).on('click', function() {
			if ($("#orgList").is(":visible")) {
				$("#src").val($(".from-station-list-min").first().text());
				$("#orgList").hide();
			}
			if ($("#desList").is(":visible")) {
				$("#ts").val($(".to-station-list-min").first().text());
				$("#desList").hide();
			}
		});
	},
	binddateevents: function() {
		var traveldate = $("#tdate");
		traveldate.datepicker({
			numberOfMonths: 1,
			dateFormat: 'dd/mm/yy',
			minDate: 0,
			maxDate: 90,
			beforeShow: function() {
				if ($('#todate').val() != "DD/MM/YYYY" || $('#todate').val() != "") {
					jQuery(this).datepicker('option', 'mindate', jQuery('#todate').val());
				}
			},
			onSelect: function(selected) {
				$("#todate").datepicker("option", "minDate", selected);
			}
		});
		$("#todate").datepicker({
			numberOfMonths: 1,
			dateFormat: 'dd/mm/yy',
			minDate: 0,
			maxDate: 90,
			beforeShow: function() {
				if ($('#tdate').val() != "DD/MM/YYYY") {
					jQuery(this).datepicker('option', 'minDate');
				}
			},
			onSelect: function(selected) {
				$("#tdate").datepicker("option", "maxDate", selected);
			}
		});
	},
	bindsearchevents: function() {
		var _self = this;
		$("#hsearch").unbind("click").on("click", function() {
			if ($("#src").val() == "" || $("#src").val() == undefined) {
				alert("Please select origin station");
				$("#src").focus();
				return false;
			} else if ($("#ts").val() == "" || $("#ts").val == "undefined") {
				alert("Please select destination station");
				$("#ts").focus();
				return false;
			} else if ($("#src").val() == $("#ts").val()) {
				alert("Both origin and destination cannot be the same");
				return false;
			} else if ($("#tdate").val() == null || $("#tdate").val() == undefined || $("#tdate").val() == "DD/MM/YYYY" || $("#tdate").val() == "") {
				alert("Please select onward date");
				$("#searchForm [name='travelDate']").focus();
				return false;
			} else {
				var v;
				var fromStationText = $("#src").val();
				var toStationText = $("#ts").val();
				if ((jQuery.trim(fromStationText) == "Sankarankoil" && jQuery.trim(toStationText) == "Chennai") || ((jQuery.trim(fromStationText) == "Chennai" && jQuery.trim(toStationText) == "Sankarankoil"))) {
					v = confirm(_self.acConnectivityText);
				}
				if ((jQuery.trim(fromStationText) == "Sankarankoil" && jQuery.trim(toStationText) == "Bangalore") || ((jQuery.trim(fromStationText) == "Bangalore" && jQuery.trim(toStationText) == "Sankarankoil"))) {
					v = confirm(_self.busConnectivity);
				}
				if (((jQuery.trim(fromStationText) == "Salem" && jQuery.trim(toStationText) == "Chennai") || (jQuery.trim(fromStationText) == "Trichy" && jQuery.trim(toStationText) == "Chennai") || (jQuery.trim(fromStationText) == "Coimbatore" && jQuery.trim(toStationText) == "Ernakulam") || (jQuery.trim(fromStationText) == "Trichy" && jQuery.trim(toStationText) == "Trivandrum") || (jQuery.trim(fromStationText) == "Dindugal" && jQuery.trim(toStationText) == "Bangalore")) || (((jQuery.trim(fromStationText) == "Chennai" && jQuery.trim(toStationText) == "Salem") || (jQuery.trim(fromStationText) == "Chennai" && jQuery.trim(toStationText) == "Trichy") || (jQuery.trim(fromStationText) == "Ernakulam" && jQuery.trim(toStationText) == "Coimbatore") || (jQuery.trim(fromStationText) == "Trivandrum" && jQuery.trim(toStationText) == "Trichy") || (jQuery.trim(fromStationText) == "Bangalore" && jQuery.trim(toStationText) == "Dindugal")))) {
					v = confirm(_self.midNightPopup);
				}
				if ((jQuery.trim(fromStationText) == "Chennai" && (jQuery.trim(toStationText) == "Thirupathi" || jQuery.trim(toStationText) == "Thirupathi (Pilgrimage Tour)")) || ((jQuery.trim(fromStationText) == "Thirupathi" && jQuery.trim(toStationText) == "Chennai"))) {
					v = confirm(_self.PackagePopup);
				}
				if ((jQuery.trim(fromStationText) == "Coimbatore" && (jQuery.trim(toStationText) == "Thirupathi" || jQuery.trim(toStationText) == "Thirupathi (Pilgrimage Tour)")) || (((jQuery.trim(fromStationText) == "Thirupathi" || jQuery.trim(toStationText) == "Thirupathi (Pilgrimage Tour)") && jQuery.trim(toStationText) == "Coimbatore"))) {
					v = confirm(_self.PackagePopupExtra);
				}
				if ((jQuery.trim(fromStationText) == "Pondicherry")) {
					v = confirm(_self.vanPickUpAlert);
				}
				if (v == undefined || v) {
					$('#searchForm').attr('action', '/parveen-travels/search');
					_self.setCookie("fromStationId", fromStationText, 365);
					_self.setCookie("toStationId", toStationText, 365);
					var fromObj = $.grep(window.homeinterface.allStations, function(e) {
						if (e.stationName == fromStationText) {
							return e;
						} else {
							return null;
						}
					});
					var toObj = $.grep(window.homeinterface.allStations, function(e) {
						if (e.stationName == toStationText) {
							return e;
						} else {
							return null;
						}
					});
					$("#fs1").attr('value', fromObj[0].id);
					$("#ts1").attr('value', toObj[0].id);
					$('#searchForm').submit();
				} else {
					return false;
				}
			}
			e.preventDefault();
		});
	},
	bindLatestNewsAndSlider: function() {
		var _self = this;
		$.ajax({
			url: _self.latestNewsAndSliderUrl,
			method: "GET",
			headers: {
				'Content-Type': 'application/json'
			},
			success: function(data) {
				localStorage.clear();
				var dataGot = data.data;
				var carouselIndicators = "";
				var carouselInner = "";
				$.each(dataGot, function(i) {
					if (dataGot[i].code == _self.sliderCode) {
						var announcementData = dataGot[i].announcements;
						$.each(announcementData, function(j) {
							if (j == 0) {
								carouselIndicators += "<li data-target='#carousel-example-generic' data-slide-to='" + j + "' class='active'></li>";
								carouselInner += "<div class='item active'>";
								carouselInner += "<a href='" + announcementData[j].redirectUrl + "' target='_blank' id='slider-href'><img src='" + announcementData[j].url + "' width='628' height='375' alt='' title='" + announcementData[j].title + "'></a>";
								carouselInner += "</div>";
							} else {
								carouselIndicators += "<li data-target='#carousel-example-generic' data-slide-to='" + j + "'></li>";
								carouselInner += "<div class='item'>";
								carouselInner += "<a href='" + announcementData[j].redirectUrl + "' target='_blank' id='slider-href'><img src='" + announcementData[j].url + "' width='628' height='375' alt='' title='" + announcementData[j].title + "'></a>";
								carouselInner += "</div>";
							}
						});
						$("#carousel-indicators").html(carouselIndicators);
						$("#carousel-inner").html(carouselInner);
					} else if (dataGot[i].code == _self.newsCode) {
						var announcementData = dataGot[i].announcements;
						var newsMsg = "";
						$.each(announcementData, function(j) {
							newsMsg += "<p>" + announcementData[j].url + "<p> ";
						});
						if (newsMsg == "") {
							$("#news-msg").html("<p>Now Advance Booking Open Upto 30 Days For Online BusTickets</p></br></br></br></br>");
						} else {
							$("#news-msg").html(newsMsg);
						}
					} else if (dataGot[i].code == _self.printAdCode) {
						var announcementData = dataGot[i].announcements;
						var newsMsg = "";
						$.each(announcementData, function(j) {
							newsMsg += announcementData[j].url;
						});
						if (!(jQuery.trim(newsMsg) == "")) {
							newsMsg += " <a href='newsinfo'> More </a>";
							$("#announcement").attr("style", "");
						}
					} else if (dataGot[i].code == _self.newsInfo) {
						var announcementData = dataGot[i].announcements;
						var newsMsg = "";
						var latestNews = announcementData[announcementData.length - 1].url;
						$.each(announcementData, function(j) {
							newsMsg += "<p>" + announcementData[j].url + "</p>";
						});
						if (!(jQuery.trim(newsMsg) == "")) {
							$(".home-bg").attr("style", "padding-top:67px");
							localStorage.setItem("name", newsMsg);
							latestNews = latestNews.substring(0, 150) + ".....";
							latestNews += " <a href='newsinfo' id='moreNewInfo'> More </a>";
							$("#announcement").attr("style", "");
						}
						$("#printAdMsg").html(latestNews);
					}
				});
			},
			error: function() {}
		});
		$("#moreNewInfo").on("click", function() {
			$("#newsInfoData").text(newsMsg);
			window.location = this.href;
		});
		$("#closeNotify").on("click", function() {
			$(".home-bg").removeAttr("style");
			$(".home-bg").addClass("new_height");
		});
	},
	// cookies
	trim: function(obj) {
		var txt = obj.value;
		if ((txt != "") || (txt != null)) {
			while (txt.charAt(txt.length - 1) == " " || txt.charAt(txt.length - 1) == ".") {
				txt = txt.substring(0, txt.length - 1);
			}
			while (txt.charAt(0) == " " || txt.charAt(0) == ".") {
				txt = txt.substring(1, txt.length);
			}
		}
		obj.value = txt;
		return txt;
	},
	getCookie: function(c_name) {
		if (document.cookie.length > 0) {
			c_start = document.cookie.indexOf(c_name + "=");
			if (c_start != -1) {
				c_start = c_start + c_name.length + 1;
				c_end = document.cookie.indexOf(";", c_start);
				if (c_end == -1) c_end = document.cookie.length;
				return unescape(document.cookie.substring(c_start, c_end));
			}
		}
		return "";
	},
	setCookie: function(c_name, value, expiredays) {
		var exdate = new Date();
		exdate.setDate(exdate.getDate() + expiredays);
		document.cookie = c_name + "=" + escape(value) + ((expiredays == null) ? "" : "; expires=" + exdate.toGMTString()) + ";path=/";
	},
	isNull: function(a) {
		if (typeof a == "undefined") {
			return true;
		} else {
			if (a == null || a == "") {
				return true;
			} else {
				return false;
			}
		}
	},
	getCookieValues: function() {
		var self = this;
		var cookieData = $.cookie("pastChoice");
		if (!self.isNull(cookieData)) {
			var pastChoice = $.parseJSON(cookieData);
			$("#pastChoice").removeClass('hide');
			$("#latestNews").removeClass('show').addClass('hide');
			$("#pastChoiceResultTable").html($("#pastChoice-list-render").render(pastChoice));
		}
		$("a.btn-past-choice").on('click', function() {
			var scheduleId = $(this).attr('scheduleId');
			var fromStationId = $(this).attr('fromStationId');
			var toStationId = $(this).attr('toStationId');
			var chooseDate = $("#travelDate-" + scheduleId + "-" + fromStationId + "-" + toStationId);
			var stageId = $(this).attr('stageId');
			chooseDate.datepicker({
				numberOfMonths: 1,
				dateFormat: 'dd/mm/yy',
				minDate: 0,
				maxDate: 90
			});
			chooseDate.focus();
			$("#travelDate-" + scheduleId + "-" + fromStationId + "-" + toStationId).on("change", function() {
				var searchString = "/parveen-travels/search?";
				searchString += "originStationId=" + $(this).attr('fromStationId') + "&destinationStationId=" + $(this).attr('toStationId') + "&pastChoiceId=" + stageId + "&travelDate=" + $("#travelDate-" + scheduleId + "-" + fromStationId + "-" + toStationId).val();
				location.href = searchString;
			});
		});
	},
};
window.homeinterface = new HomePageInterface();