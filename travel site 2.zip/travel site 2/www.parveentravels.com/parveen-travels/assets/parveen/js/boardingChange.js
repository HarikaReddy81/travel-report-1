var BoardingChange = function() {
    rootUrl = "/parveen-travels/";
};

BoardingChange.prototype = {
    init: function() {
        $("#pnrShowTicket").focus();
    },

    getBoardingPointList: function() {
        var pnr = $("#pnrShowTicket").val();
        if (pnr == "") {
            $("#errorMsg").html("Please Enter the PNR");
            $("#errorMsg").show();
        } else {
            $("#boardingEdit").hide();
            $("#successMsg").html("");
            $("#errorMsg").html("");
            $("#errorMsg").hide();
            $("#successMsg").hide();
            var boardingTable = $("<table></table>");
            var userTr = $("<tr></tr>");
            var userTd = $("<td></td>");
            userTd.attr("style", "padding-left: 10px;");
            var emailId = $("<input />");
            emailId.attr("type", "text");
            emailId.attr("class", "form-control input-sm boardingPointClass");
            emailId.attr("placeholder", "Enter the EmailId");
            emailId.attr("id", "emailId");
            userTd.append(emailId);
            userTr.append(userTd);

            var buttonTd = $("<td></td>");
            buttonTd.attr("style", "padding-left: 20px;");
            var submitButton = $("<button></button>", {
                "type": "button"
            });
            submitButton.attr("class", "btn btn-primary");
            submitButton.attr("id", "boardingUpdation");
            submitButton.attr("onclick", "boardingChange.emailCheck()");
            submitButton.text("Check");
            buttonTd.append(submitButton);
            userTr.append(buttonTd);
            boardingTable.append(userTr);
            $("#boardingChangeDiv").html(boardingTable);
            $("#boardingChangeDiv").show();
            $("#emailId").focus();
        }

        $("#pnrShowTicket").bind("input", function() {
            $("#boardingChangeDiv").hide();
            $("#boardingEdit").show();
            $("#addressDiv").hide();
        });
    },

    getBoardingPoints: function() {
        $("#boardingChangeDiv").html("");
        var pnr = $("#pnrShowTicket").val();
        if (pnr != "") {
            $.ajax({
                type: "GET",
                url: rootUrl + "booking/" + pnr + "/boardingEdit.json",
                async: true,
                dataType: "json",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                success: function(response) {
                    if (response.data.length > 0) {
                        $("#errorMsg").html("");
                        $("#errorMsg").hide();
                        boardingChange.buildBoardingPointList(response);
                    } else {
                        $("#errorMsg").html("Invalid PNR");
                        $("#errorMsg").show();
                        $("#successMsg").html("");
                        $("#successMsg").hide();
                        $("#boardingChangeDiv").html("");
                    }
                },
                error: function(e) {
                    $("#errorMsg").html("Invalid PNR");
                }
            });
        } else {
            $("#errorMsg").html("Please Enter the PNR");
            $("#errorMsg").show();
            $("#pnrShowTicket").focus();
        }
    },

    emailCheck: function() {
        var pnr = $("#pnrShowTicket").val();
        var email = $("#emailId").val();
        if (pnr == "") {
            $("#errorMsg").html("Please Enter the PNR");
            $("#errorMsg").show();
            $("#pnrShowTicket").focus();
        } else if (email == "") {
            $("#errorMsg").html("Please Enter the Email");
            $("#errorMsg").show();
            $("#emailId").focus();
        } else {
            $.ajax({
                type: "GET",
                url: rootUrl + "booking/" + pnr + "/" + email + "/emailVerfication.json",
                async: true,
                dataType: "json",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                success: function(response) {
                    if (response.data) {
                        $("#errorMsg").html("");
                        $("#errorMsg").hide();
                        boardingChange.validateDepatureTime();
                        boardingChange.getBoardingPoints();
                    } else {
                        $("#boardingEdit").show();
                        $("#errorMsg").html("User Verfication failed");
                        $("#errorMsg").show();
                        $("#successMsg").html("");
                        $("#successMsg").hide();
                        $("#boardingChangeDiv").html("");
                    }
                },
                error: function(e) {
                    $("#errorMsg").html("Invalid PNR");
                }
            });
        }
    },
    validateDepatureTime: function() {

    },
    buildBoardingPointList: function(data) {
        $("#boardingEdit").hide();
        var boardingTable = $("<table></table>");
        var selectionTr = $("<tr></tr>");
        var selectionTd = $("<td></td>");
        selectionTd.attr("style", "padding-left: 10px;");
        var availableBoardingTag = $("<select></select>");
        availableBoardingTag.attr("class", "form-control input-sm boardingPointClass");
        availableBoardingTag.attr("style", "margin-bottom:2px; width:275px;");
        availableBoardingTag.attr("id", "boardingPointId");
        var startTag = $("<option></option>");
        startTag.attr("value", "-1");
        startTag.text("Select Boarding Points");
        availableBoardingTag.append(startTag);
        $(data.data).each(function(i) {
            var boardingList = $("<option></option>");
            boardingList.attr("value", data.data[i].operatorStationId);
            boardingList.attr("title", data.data[i].addressLine1 + ", " + data.data[i].addressLine2 + ", " + data.data[i].addressLandMark);
            boardingList.text(data.data[i].pointName);
            availableBoardingTag.append(boardingList);
        });
        selectionTd.append(availableBoardingTag);
        selectionTr.append(selectionTd);
        var buttonTd = $("<td></td>");
        buttonTd.attr("style", "padding-left: 20px;");
        var submitButton = $("<button></button>", {
            "type": "button"
        });
        submitButton.attr("class", "btn btn-primary");
        submitButton.attr("id", "boardingUpdation");
        submitButton.attr("onclick", "boardingChange.boardingUpdation()");
        submitButton.text("Update");
        buttonTd.append(submitButton);
        selectionTr.append(buttonTd);
        boardingTable.append(selectionTr);
        $("#boardingChangeDiv").html(boardingTable);
        $("#boardingChangeDiv").show();
        $("#boardingPointId").change(function() {
            var boardingPointId = $("#boardingPointId").val();
            if (boardingPointId != "-1") {
                var title = $(this).find("option:selected").attr("title");
                var spaceDiv = $("<div></div>");
                spaceDiv.attr("class", "space");
                var div = $("<div></div>");
                div.attr("class", "busmap_cond_txt align-left b-address show fadeInDown animated");
                div.attr("style", "width:37%;");
                div.attr("id", "boardingAddress");
                var span = $("<span></span>");
                span.text(title);
                div.append(span);
                spaceDiv.append(div);
                $("#addressDiv").html(spaceDiv);
                $("#addressDiv").show();
            } else {
                $("#addressDiv").hide();
            }
        });
    },

    boardingUpdation: function() {
        $("#addressDiv").hide();
        var boardingPointId = $("#boardingPointId").val();
        var pnr = $("#pnrShowTicket").val();
        if (boardingPointId != "-1") {
            $.ajax({
                type: "GET",
                url: rootUrl + "booking/" + boardingPointId + "/" + pnr + "/boardingUpdate.json",
                async: true,
                dataType: "json",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                success: function(response) {
                    console.log(response);
                    if (response.data == true) {
                        ajaxService.showTicket($('#pnrShowTicket').val());
                        $("#boardingChangeDiv").hide();
                        $("#successMsg").html("BoardingPoint Successfully Updated");
                        $("#boardingEdit").hide();
                        $("#successMsg").show();
                    } else {
                        $("#errorMsg").html("Boarding point changes are allowed only three hours before trip Depature time");
                        $("#errorMsg").show();
                        $("#successMsg").html("");
                        $("#successMsg").hide();
                        $("#printTicketDiv").html("");
                    }
                },
                error: function(e) {
                    $("#errorMsg").html("Invalid PNR");
                }
            });
        } else {
            alert("No changes in Boarding Point");
            $("#boardingChangeDiv").hide();
            $("#boardingEdit").show();
        }
    },
};
window.boardingChange = new BoardingChange();