var rootUrl= "/parveen-travels/";
var emailFilter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
var IdSpec ={
		"userID":"userId",
		"registerUserID":"userIdR",
		"forgetUserID":"userIdF",
		"password":"password",
		"registerPassword":"passwordR",
		"mobilenumber":"mobileNo",
		"pnrP":"pnrShowTicket",
		"pnrC":"pnrCancel",
		"sendSms":"sendSmsTicket",
		"loginBtn":"loginBtn",
		"search":"searchBtn",
		"register":"registerBtn",
		"fogetPass":"forgetPassBtn",
		"showTicket":"showTicketBtn",
		"cancelTicket":"cancelTicketBtn",		
		"confirmCancel":"confirmCancelBtn",
		"printHtml" : "printHtmlTicket",
		"printPDF"  : "printPdfTicket",
		"confirmCancel1":"confirmCancelBtn1",
		"printHtml1" : "printHtmlTicket1",
		"printPDF1"  : "printPdfTicket1"
		};

var renderDivID ={
	"printTicket":"printTicketDiv",
	"cancelTicket":"cancelTicketDiv"
};
var showTicketValidator;
var signInValidator;
var forgotPwdValidator;
var registerValidator;

$(document).ready(function() {
	$("#errorMsg").hide();
	$("#successMsg").hide();
	$('body').on("click","input[type='checkbox'][name='cancelAll']",function() {
	    var $this = $(this);
	    // $this will contain a reference to the checkbox   
	    if ($this.is(':checked')) {
	    	$("input[type='checkbox'][name='seatIds']","#refundDetailTable").attr('checked',true);
	    } else {
	    	$("input[type='checkbox'][name='seatIds']","#refundDetailTable").attr('checked',false);
	    }
	});
	// Login Method 
    $('#'+IdSpec['loginBtn']).click(function(e){

    	
    	if(validataion.login().form())
    	{
    		var data = {email:$('#'+IdSpec.userID).val(), password:$('#'+IdSpec.password).val()};
    		ajaxService.getLogin(data);
    		ajaxService.getPopUp();
    	} else {
    		 $("#signInForm").validate().focusInvalid();
    	}
    	 e.preventDefault();
     });
    // Register Method   
    $('#'+IdSpec['register']).unbind("click").on("click",function(e){
        if(validataion.register().form())
    	{	
        	
    			var data = {email:$('#'+IdSpec.registerUserID).val(), password:$('#'+IdSpec.registerPassword).val(),mobile:$('#'+IdSpec.mobilenumber).val()};
    			ajaxService.register(data);
        		if(ajaxService.registeration)
        			{
        			ajaxService.getLogin(data);
        			}
        }    	
        e.preventDefault();
    });

    // forget Password Method
    $('#'+IdSpec['fogetPass']).click(function(){
  		if(validataion.forgetPassword().form())
    	{	
  				
  				var data = {email:$('#'+IdSpec.forgetUserID).val()};
  				ajaxService.forgetPassword(data);
   		 }
    	
    });

    // Show Ticket 
     $('#'+IdSpec['showTicket']).unbind('click').click(function(){
     	
  		if(validataion.showTicket())
    	{   		
    		ajaxService.showTicket($('#'+IdSpec.pnrP).val());    	
   		}
    	
    });
     
     
     //Send Sms
     
     $('#'+IdSpec['sendSms']).unbind('click').click(function(){
      	
   		if(validataion.showTicket())
     	{   		
     		ajaxService.sendSms($('#'+IdSpec.pnrP).val());    	
    	}
     	
     });
     

     // Cancel Ticket
     $('#'+IdSpec['cancelTicket']).unbind('click').on('click',function(){
     	$("#cancelLabel").removeClass("show").addClass("hide");
  		if(validataion.cancelTicket())
    	{   		
    		ajaxService.cancelTicket($('#'+IdSpec.pnrC).val());    	
   		}
    	
    });

    // Confirm Cancel     
  	$('body').on('click','#'+IdSpec['confirmCancel'],function(){
     	
  		if(validataion.cancelTicket())
    	{   
  				var FORM_LIST = {"pnr":"","seatIds":""};
				var pnr =$("#pnrCC").val();;
				FORM_LIST["pnr"]=pnr;
				var seatArray=new Array();
				$("td .cancelCheck:checked").each(function(){
					var seatArrayVal = $(this).val().replace(new RegExp(",", 'g'), "");
					
					seatArray.push(seatArrayVal);
		        });
				
				
				FORM_LIST["seatIds"]=seatArray;
				
				if(seatArray == undefined || !(seatArray.length > 0)){
					
					alert("Please select seats to cancel");
					
				}else{
				var confirmBox = confirm("Are you sure about cancelling the seats ?");
				if(confirmBox){
				$("#confirmCancelBtn").parent().append('<img id="loadingImg" src="/parveen-travels/assets/parveen/images/loading-mini.GIF"/>');
				$("#confirmCancelBtn").addClass("hide");
				}
				if(confirmBox == true){
				
				 $.ajax({
					url :rootUrl+"booking/" +pnr + "/cancel.json",
					dataType : 'json',
					type : "POST",
					contentType : "application/json; charset=utf-8",
					data : JSON.stringify(FORM_LIST),
					//async: false,
					dataType :"json",
					headers: {				
						'Accept': 'application/json',
						'Content-Type': 'application/json' 
					},
					success : function(data){
						if(data.success){
							alert('Ticket Cancellation was successful');
							$("#confirmCancelBtn").removeClass("hide");
							$("#confirmCancelBtn").parent().html($("#confirmCancelBtn"));
							ajaxService.cancelTicket(pnr); 
//							$("#cancelForm").submit();
//							$("#errorMsg").html("");
//							$("#errorMsg").hide();
							
						}else{
							var dataGot = JSON.parse(data);
							$("#confirmCancelBtn").removeClass("hide");
							$("#confirmCancelBtn").parent().html($("#confirmCancelBtn"));
							$("#errorMsg").html(dataGot.error.globalErrors[0]);
							$("#errorMsg").show();
						}
					},
					error : function(data){
							$("#confirmCancelBtn").removeClass("hide");
							$("#confirmCancelBtn").parent().html($("#confirmCancelBtn"));
							$("#errorMsg").text("Failed to cancel the ticket");
							$("#errorMsg").show();
					}
				
  			});
  			}		 
//  			var data={};		
//    		ajaxService.confirmCancel($('#'+IdSpec.pnrCC).val(),data);    	
   		}
    	}
    	
    });
  
  	
  /** Confirm cancel for mobile site*/
  	$('body').on('click','#'+IdSpec['confirmCancel1'],function(){
     	
  		if(validataion.cancelTicket())
    	{   
  				var FORM_LIST = {"pnr":"","seatIds":""};
				var pnr =$("#pnrCC").val();;
				FORM_LIST["pnr"]=pnr;
				var seatArray=new Array();
				$("div .cancelCheck:checked").each(function(){
					var seatArrayVal = $(this).val().replace(",","");
					
					seatArray.push(seatArrayVal);
		        });
				FORM_LIST["seatIds"]=seatArray;
				
				if(seatArray == undefined || !(seatArray.length > 0)){
					
					alert("Please select seats to cancel");
					
				}else{
				var confirmBox = confirm("Are you sure about cancelling the seats ?");
				if(confirmBox){
				$("#confirmCancelBtn").parent().append('<img id="loadingImg" src="/parveen-travels/assets/parveen/images/loading-mini.GIF"/>');
				$("#confirmCancelBtn").addClass("hide");
				}
				if(confirmBox == true){
				
				 $.ajax({
					url :rootUrl+"booking/" +pnr + "/cancel.json",
					dataType : 'json',
					type : "POST",
					contentType : "application/json; charset=utf-8",
					data : JSON.stringify(FORM_LIST),
					//async: false,
					dataType :"json",
					headers: {				
						'Accept': 'application/json',
						'Content-Type': 'application/json' 
					},
					success : function(data){
						if(data.success){
							alert('Ticket Cancellation was successful');
							$("#confirmCancelBtn").removeClass("hide");
							$("#confirmCancelBtn").parent().html($("#confirmCancelBtn"));
							ajaxService.cancelTicket(pnr); 
//							$("#cancelForm").submit();
//							$("#errorMsg").html("");
//							$("#errorMsg").hide();
							
						}else{
							var dataGot = JSON.parse(data);
							$("#confirmCancelBtn").removeClass("hide");
							$("#confirmCancelBtn").parent().html($("#confirmCancelBtn"));
							$("#errorMsg").html(dataGot.error.globalErrors[0]);
							$("#errorMsg").show();
						}
					},
					error : function(data){
							$("#confirmCancelBtn").removeClass("hide");
							$("#confirmCancelBtn").parent().html($("#confirmCancelBtn"));
							$("#errorMsg").text("Failed to cancel the ticket");
							$("#errorMsg").show();
					}
				
  			});
  			}		 
//  			var data={};		
//    		ajaxService.confirmCancel($('#'+IdSpec.pnrCC).val(),data);    	
   		}
    	}
    	
    });
  	
  	
  	//printHtml button
  	
  	$('body').on('click','#'+IdSpec["printHtml"],function(){
  		var pnr = $("#pnrCC").val();
  		window.open(rootUrl+"/booking/"+pnr+"/print","PrintHTML");
  	});
  	
  	//printPDF button
  	
  	$('body').on('click','#'+IdSpec["printPDF"],function(){
  		var pnr = $("#pnrCC").val();
  		window.open(rootUrl+"/booking/"+pnr+"/printPdf","PrintPDF");
  	});
  	
  	
  	$('body').on('click','#'+IdSpec["printHtml1"],function(){
  		var pnr = $("#pnrCC").val();
  		window.open(rootUrl+"/booking/"+pnr+"/print","PrintHTML");
  	});
  	
  	//printPDF button
  	
  	$('body').on('click','#'+IdSpec["printPDF1"],function(){
  		var pnr = $("#pnrCC").val();
  		window.open(rootUrl+"/booking/"+pnr+"/printPdf","PrintPDF");
  	});
  	

 });

var validataion = {	
	login:function()
	{
		signInValidator = $("#signInForm").validate({
			ignore : [],
			onfocusout : function(element) {
				return $(element).valid();
			},
			rules : {
				username : {
					"required" : true,
				},
				password : {
					"required" : true,
				    "minlength" : 6,

				}
			},
			errorPlacement : function() {
				return false;
			},
			errorElement : "span",
			highlight : function(element) {
				$(element).closest('.form-group').addClass("error");
			},
			unhighlight : function(element) {
				$(element).closest('.form-group').removeClass("error");
			}
		});
		return signInValidator;
		
	},
	register:function()
	{
		var registerValidator = $("#registerForm").validate({
			ignore : [],
			onfocusout : function(element) {
				return $(element).valid();
			},
			rules : {
				email : {
					"required" : true,
				},
				password : {
					"required" : true,
				    "minlength" : 6,

				},
				mobileNum : {
					"required" : true,
				},
			},
			errorPlacement : function() {
				return false;
			},
			errorElement : "span",
			highlight : function(element) {
				$(element).closest('.form-group').addClass("error");
			},
			unhighlight : function(element) {
				$(element).closest('.form-group').removeClass("error");
			}
		});
		return registerValidator;
	},
	forgetPassword:function()
	{
		forgotPwdValidator = $("#forgotPasswordForm").validate({
			ignore : [],
			onfocusout : function(element) {
				return $(element).valid();
			},
			rules : {
				email : {
					"required" : true,
				}
			},
			errorPlacement : function() {
				return false;
			},
			errorElement : "span",
			highlight : function(element) {
				$(element).closest('.form-group').addClass("error");
			},
			unhighlight : function(element) {
				$(element).closest('.form-group').removeClass("error");
			}
		});
		return forgotPwdValidator;
		
	},
	showTicket:function()
	{
		if(jQuery.trim($("#pnrShowTicket").val()) == "" ||  $("#pnrShowTicket").val() == undefined){
			$("#errorMsg").html("Please enter your ticket PNR");
			$("#errorMsg").show();
			$("#pnrCancel").focus();
			$("#pnrShowTicket").focus();
			return false;
		}else{
			return true;
		}
	},
	cancelTicket:function()
	{
		if(jQuery.trim($("#pnrCancel").val()) == "" ||  $("#pnrCancel").val() == undefined){
			$("#errorMsg").html("Please enter your ticket PNR");
			$("#errorMsg").show();
			$("#pnrCancel").focus();
			return false;
		}else{
			return true;
		}
	},
	confirmCancel:function()
	{

	}
};

var sucessHandler ={
	login:function(data)
	{
		console.log("Success Login");
		location.reload();
	},
	register:function(data)
	{
		$('#signinCont,#userReg').removeClass('show');
		$('#signinCont,#userReg').addClass('hide');
    	$('#modelWindow').addClass('hide');
    	$('#modelWindow').removeClass('show');
    	
    	alert('Successfully registered');
	}
	,forgetPassword:function(data)
	{
		$('#forgetPassword-errMsg').html("Password reset instructions has been sent to your Email");
	},
	changePassword:function(data)
	{

	},
	updateProfile:function(data)
	{

	},
	getStations:function(data)
	{
		console.log(data);
	},
	getScheduleList:function(data)
	{
		getSearchResults(data);
	},
	getBusMap:function(data)
	{

	},
	getOpertorDetails:function(data)
	{

	},
	blockSeat:function(data)
	{

	},
	showTicket:function(data)
	{ 
		$("#errorMsg").html("");
		$("#successMsg").html("");
		$("#errorMsg").hide();
		$("#successMsg").hide();
		
		if(data == '{"success":false,"error":{"globalErrors":["ticket.invalid"]}}'){
			
			$("#errorMsg").html("Invalid PNR");
			$("#errorMsg").show();
			$('#'+renderDivID['printTicket']).html("");
		}else{
			$('#'+renderDivID['printTicket']).html(data);
			$("#errorMsg").html("");
			$("#errorMsg").hide();
		}
	},
	cancelTicket:function(data)
	{	
			if(data == '{"success":false,"error":{"globalErrors":["ticket.invalid"]}}'){
				$("#errorMsg").html("Invalid PNR");
				$("#errorMsg").show();
				$('#'+renderDivID['cancelTicket']).html("");
			}else{
				$('#'+renderDivID['cancelTicket']).html(data);
				$("#errorMsg").html("");
				$("#errorMsg").hide();
			}
	},
	confirmCancel:function(data)
	{
		
	},
	sendSms:function(response,pnr)
	{
		if(response.success== undefined){
	  		response = $.parseJSON(response);
	  		if (!response.success && (response.error).globalErrors=="ticket.invalid"){
	  			$("#successMsg").hide();
	  			$("#successMsg").html("");
				$("#errorMsg").show();
	  			$("#errorMsg").html("Invalid PNR");
	  		}
	  	}
	  	else{
	  		var data=response.data;
	  		console.log(data);
	  		if(response.success && (data == "BOOKED" || data == "PARTIAL_CANCEL"))
	  		{	
	  			$("#errorMsg").hide();
	  			$("#errorMsg").html("");
	  			$("#successMsg").show();
	  			$("#successMsg").html("Sms sent successfully");
	  			
	  				
	  		}
	  		else{
	  			if(data=="CANCELLED")
	  			{	
		  			$("#successMsg").hide();
		  			$("#successMsg").html("");
	  				$("#errorMsg").show();
	  				$("#errorMsg").html('This ticket '+pnr+' has been cancelled. No message service for this ticket.');
	  			}
	  			if(data=="BLOCKED")
	  			{
		  		$("#successMsg").hide();
	  			$("#successMsg").html("");
	  			$("#errorMsg").show();
	  			$("#errorMsg").html('This ticket '+pnr+' has been blocked. No message service for this ticket.');
	  			}
	  		}
	  	}
	}
};
var failureHandler ={
	login:function(code,errMsg)
	{	$('#login-errMsg').html("Please check your credentials");
		console.log("fail Login");
		$("#userId").focus();

	},
	register:function(code,errMsg)
	{
		$('#register-errMsg').html("Email Id already registered.");
//		$("#signinCont").show();
	}
	,forgetPassword:function(code,errMsg)
	{
		$('#forgetPassword-errMsg').html("Invalid Email Id");
	},
	changePassword:function(code,errMsg)
	{

	},
	updateProfile:function(code,errMsg)
	{

	},
	getStations:function(code,errMsg)
	{

	},
	getScheduleList:function(code,errMsg)
	{

	},
	getBusMap:function(code,errMsg)
	{

	},
	getOpertorDetails:function(code,errMsg)
	{

	},
	blockSeat:function(code,errMsg)
	{

	},
	showTicket:function(code,errMsg)
	{
		$("#errorMsg").html("Sorry !! Some error occurred , Try later !!");
	},
	cancelTicket:function(code,errMsg)
	{
		$("#errorMsg").html("Sorry !! Some error occurred , Try later !!");
	},
	confirmCancel:function(code,errMsg)
	{

	},
	sendSms:function(code,errMsg)
	{

	}
};