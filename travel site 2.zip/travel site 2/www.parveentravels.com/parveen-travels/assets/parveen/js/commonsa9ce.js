/**
 *
 */
var oldie = /msie\s*(8|7|6)/.test(navigator.userAgent.toLowerCase());
function getHeaderFooterHeight() {
	if (!window.headerHeight) {
		window.headerHeight = $("#navbar").innerHeight();
	}
	if (!window.footerHeight) {
		window.footerHeight = $("#footer").innerHeight();
	}
	return {
		header : headerHeight,
		footer : footerHeight
	};
}

$.fn.serializeObject = function() {
	var arrayData, objectData;
	arrayData = this.serializeArray();
	objectData = {};

	$.each(arrayData, function() {
		var value;

		if (this.value != null) {
			value = this.value;
		} else {
			value = '';
		}

		// search for "parent.id" like attribute
		if (this.name.indexOf('.') != -1) {
			var attrs = this.name.split('.');
			var tx = objectData;

			for (var i = 0; i < attrs.length - 1; i++) {
				if (objectData[attrs[i]] == undefined)
					objectData[attrs[i]] = {};
				tx = objectData[attrs[i]];
			}
			tx[attrs[attrs.length - 1]] = value;
		} else {
			if (objectData[this.name] != null) {
				if (!objectData[this.name].push) {
					objectData[this.name] = [ objectData[this.name] ];
				}

				objectData[this.name].push(value);
			} else {
				objectData[this.name] = value;
			}
		}
	});

	return objectData;
};

function cleanObject(object) {
	for ( var i in object) {
		delete object[i];
	}
}

function isCssSupported(property) {
	return property in document.body.style;
}

/**
 * Method to get the Query String value for form.
 */
function getAjaxFormData(formId) {
	var oForm;

	if (typeof formId == 'string') {
		// Determine if the argument is a form id or a form name.
		// Note form name usage is deprecated by supported
		// here for legacy reasons.
		oForm = (document.getElementById(formId) || document.forms[formId]);
	} else if (typeof formId == 'object') {
		// Treat argument as an HTML form object.
		oForm = formId;
	} else {
		return;
	}
	var formData = getFormData(oForm);
	return formData;
}

// Iterate over the form elements collection to construct the
// label-value pairs.
function getFormData(oForm) {
	var oElement, oName, oValue, oDisabled, hasSubmit;
	hasSubmit = false;
	var data = [], item = 0, i, len, j, jlen, opt;
	var utf8Coder = new Utf8();
	for (i = 0, len = oForm.elements.length; i < len; ++i) {
		oElement = oForm.elements[i];
		oDisabled = oElement.disabled;
		oName = oElement.name;

		// Do not submit fields that are disabled or
		// do not have a name attribute value.
		if (!oDisabled && oName) {
			oName = utf8Coder.encode(oName) + '=';
			oValue = utf8Coder.encode(oElement.value);

			switch (oElement.type) {
			// Safari, Opera, FF all default opt.value from .text if
			// value attribute not specified in markup
			case 'select-one':
				if (oElement.selectedIndex > -1) {
					opt = oElement.options[oElement.selectedIndex];
					data[item++] = oName + utf8Coder.encode((opt.attributes.value && opt.attributes.value.specified) ? opt.value : opt.text);
				}
				break;
			case 'select-multiple':
				if (oElement.selectedIndex > -1) {
					for (j = oElement.selectedIndex, jlen = oElement.options.length; j < jlen; ++j) {
						opt = oElement.options[j];
						if (opt.selected) {
							data[item++] = oName + utf8Coder.encode((opt.attributes.value && opt.attributes.value.specified) ? opt.value : opt.text);
						}
					}
				}
				break;
			case 'radio':
			case 'checkbox':
				if (oElement.checked) {
					data[item++] = oName + oValue;
				}
				break;
			case 'file':
				// stub case as XMLHttpRequest will only send the file path as a
				// string.
			case undefined:
				// stub case for fieldset element which returns undefined.
			case 'reset':
				// stub case for input type reset button.
			case 'button':
				// stub case for input type button elements.
				break;
			case 'submit':
				if (hasSubmit === false) {
					if (this._hasSubmitListener && this._submitElementValue) {
						data[item++] = this._submitElementValue;
					} else {
						data[item++] = oName + oValue;
					}

					hasSubmit = true;
				}
				break;
			default:
				data[item++] = oName + oValue;
			}
		}
	}
	return data.join('&');
}

$.fn.serializeForm = function() {
	var o = {};
	var a = this.serializeArray();
	$.each(a, function() {
		if (o[this.name]) {
			if (!o[this.name].push) {
				o[this.name] = [ o[this.name] ];
			}
			o[this.name].push(this.value || '');
		} else {
			o[this.name] = this.value || '';
		}
	});
	return o;
};

if (!Function.prototype.bind) {
	Function.prototype.bind = function(oThis) {
		if (typeof this !== "function") {
			// closest thing possible to the ECMAScript 5 internal IsCallable
			// function
			throw new TypeError("Function.prototype.bind - what is trying to be bound is not callable");
		}

		var aArgs = Array.prototype.slice.call(arguments, 1), fToBind = this, fNOP = function() {
		}, fBound = function() {
			return fToBind.apply(this instanceof fNOP && oThis ? this : oThis, aArgs.concat(Array.prototype.slice.call(arguments)));
		};

		fNOP.prototype = this.prototype;
		fBound.prototype = new fNOP();
		return fBound;
	};
}

if (!String.prototype.trim) {
	String.prototype.trim = function() {
		return this.replace(/^\s\s*/, '').replace(/\s\s*$/, '');
	};
}

if (!String.prototype.isEmpty) {
	String.prototype.isEmpty = function() {
		return this.length === 0 || this == " " || /^\s*$/.test(this);
	};
}

/**
 * Bind the object with function scope With Event Object.
 */
Function.prototype.bindEvent = function(object) {
	var __method = this, args = Array.prototype.slice.call(arguments), object = args.shift();
	return function(event) {
		return __method.apply(object, [ (event || window.event) ].concat(args).concat(Array.prototype.slice.call(arguments)));
	};
};

function toArray(obj) {
	return Array.prototype.slice.call(obj);
}

function bindScope(scope, fn /* , variadic args to curry */) {
	var args = Array.prototype.slice.call(arguments, 2);
	return function() {
		return fn.apply(scope, args.concat(toArray(arguments)));
	};
}

function findObject(array, property, value) {
	for (var i = 0, len = array.length; i < len; i++) {
		var item = array[i];
		if (item[property] === value) {
			return item;
		}
	}
}

function findObjectIndex(array, property, value) {
	for (var i = 0, len = array.length; i < len; i++) {
		var item = array[i];
		if (item[property] === value) {
			return i;
		}
	}
	return -1;
}

function checkExpiry(value) {
	var match = value.match(/^\s*(0?[1-9]|1[0-2])\/(\d{4})\s*$/);
	if (!match) {
		return false;
	}
	var exp = new Date(normalizeYear(1 * match[2]), 1 * match[1] - 1, 1).valueOf();
	var now = new Date();
	var currMonth = new Date(now.getFullYear(), now.getMonth(), 1).valueOf();
	if (exp <= currMonth) {
		return false;
	} else {
		return true;
	}
}

function normalizeYear(year) {
	// Century fix
	var YEARS_AHEAD = 20;
	if (year < 100) {
		var nowYear = new Date().getFullYear();
		year += Math.floor(nowYear / 100) * 100;
		if (year > nowYear + YEARS_AHEAD) {
			year -= 100;
		} else if (year <= nowYear - 100 + YEARS_AHEAD) {
			year += 100;
		}
	}
	return year;
}

jQuery.localStore = {

	get : function(key) {
		var value = undefined;
		if (window.localStorage != null) {
			var ctime = new Date().getTime();
			var item = localStorage.getItem(key);
			if (item != undefined && item != null && item != 'undefined') {
				item = JSON.parse(item);
				if (item.expires === 0 || ctime - item.time < item.expires) {
					value = item.value;
				} else {
					this.remove(key);
				}
			}
		}
		return value;
	},

	set : function(key, value, expireSeconds) {
		if (window.localStorage != null) {
			var time = new Date().getTime();
			var expires;

			if (expireSeconds && jQuery.isNumeric(expireSeconds)) {
				expires = parseInt(expireSeconds) * 1000;
			} else {
				expires = 0;
			}
			;
			var item = {
				value : value,
				time : time,
				expires : expires
			};
			localStorage.setItem(key, JSON.stringify(item));
		}
	},

	remove : function(key) {
		if (window.localStorage != null) {
			localStorage.removeItem(key);
		}
	},

	clear : function() {
		if (window.localStorage != null) {
			localStorage.clear();
		}
	}
};

jQuery.processTemplate = function(template, data) {

	var i = 0, len = data.length, fragment = '';

	// For each item in the object, make the necessary replacement
	function replace(obj) {
		var t, key = 0, reg;

		for (key in obj) {
			reg = new RegExp('{{' + key + '}}', 'ig');
			t = (t || template).replace(reg, obj[key]);
		}

		return t;
	}
	if (typeof data == 'object') {
		fragment = replace(data);
	} else if (typeof data == 'array') {
		for (; i < len; i++) {
			fragment += replace(data[i]);
		}
	}

	return fragment;
};

(function($) {
	$.extend({
		// public interface: $.tmpl
		tmpl : function(tmpl, vals) {
			var rgxp, repr;

			// default to doing no harm
			tmpl = tmpl || '';
			vals = vals || {};

			// regular expression for matching our placeholders; e.g.,
			// #{my-cLaSs_name77}
			rgxp = /#\{([^{}]*)}/g;

			// function to making replacements
			repr = function(str, match) {
				return typeof vals[match] === 'string' || typeof vals[match] === 'number' ? vals[match] : str;
			};

			return tmpl.replace(rgxp, repr);
		}
	});
})(jQuery);

function getErrorMessage(inResponse) {
	var message = "";
	if (typeof inResponse.error === 'string') {
		message = inResponse.error;
	} else {
		for ( var err in inResponse.error) {
			message += inResponse.error[err] + "\n";
		}
	}
	navigator.notification.alert(message, callback, "Failure", "Ok");
}

function isEmptyObject(obj) {
	if (obj === undefined || obj === null) {
		return true;
	}
	if (Object.keys) {
		return Object.keys(obj).length === 0;
	} else {
		for ( var prop in obj) {
			if (obj.hasOwnProperty(prop)) {
				return false;
			}
		}
		return true;
	}
}

jQuery.VahanaService = {
	get : function(url, options){
		options.method="GET";
		jQuery.VahanaService.execute(url, options);
	},
	execute : function(url, options) {
		var time = new Date().getTime();
		url = SERVER_URL + url;
		if (url.indexOf("?") == -1) {
			url += "?ts=" + time;
		} else {
			url += "&ts=" + time;
		}
		var defaults = {
			dataType : "json",
			cache : false,
			url : url,
			type : options.method ? options.method : "POST",
			sessionRequired : true,
			loading : false
		};

		options = $.extend({}, defaults, options);

		//console.log(options.loading);

		/***********************************************************************
		 * if (options.sessionRequired) { var sessionToken =
		 * $.localStore.get("sessionToken"); if (sessionToken === undefined ||
		 * sessionToken === null) { // $.trigger("loginRequest"); return; }
		 * options.data = $.extend(options.data, { sessionToken : sessionToken
		 * }); }
		 **********************************************************************/

		var successCallback = options.success;
		var errorCallback = options.error;
		options.success = success;
		options.error = error;
		var l = null;
		if(options.loading){
			$(options.loading).addClass('ladda-button').attr("data-style", "expand-right");
			l = Ladda.create(options.loading);
		 	l.start();
		}

		return jQuery.ajax(options).always(function() {
			if(l){
				l.stop();
				l=null;
			}
		});

		function success(response) {
			if (successCallback)
				successCallback(response);

		}

		function error(xhr, status, error) {
			if (errorCallback)
				errorCallback();
			/*******************************************************************
			 * Overlay.hide(); navigator.notification.alert( "Server is busy.
			 * Please try again later", jQuery.noop(), "Kachyng"); if
			 * (errorCallback) { errorCallback(); }
			 ******************************************************************/
		}
	}
};

function convertJson(o) {
	var oo = {}, t, parts, part;
	for ( var k in o) {
		t = oo;
		parts = k.split('.');
		var key = parts.pop();
		while (parts.length) {
			part = parts.shift();
			t = t[part] = t[part] || {};
		}
		t[key] = o[k];
	}
	return oo;
};
function createObjects(parent, chainArray, value) {
	if (chainArray.length == 1) {
		if ($.isArray(value)) {
			parent[chainArray[0]] = Object.expandArray(value);
		} else if ($.isPlainObject(value)) {
			parent[chainArray[0]] = Object.expand(value);
		} else {
			parent[chainArray[0]] = value;
		}
		return parent;
	} else {
		parent[chainArray[0]] = parent[chainArray[0]] || {};
		return createObjects(parent[chainArray[0]], chainArray.slice(1, chainArray.length), value);
	}
}

Object.expand = function(obj) {
	var result = {};
	for ( var key in obj) {
		createObjects(result, key.split('.'), obj[key]);
	}
	return result;
};

Object.expandArray = function(obj) {
	var result = new Array();
	for ( var key in obj) {
		result.push(Object.expand(obj[key]));
	}
	return result;
};

/*
 * ASCII Code or keyCode=Character
 * 48=0,49=1,50=2,51=3,52=4,53=5,54=6,55=7,56=8,57=9, 8=Backspace,9=Horizontal
 * tab, 32=(space), 44=(comma,) , 45=(hiphen-), 46=(dot.) 65=A,90=Z,97=a,122=z
 */

function NoSpecialChar(e) {
	e = (e) ? e : (window.event) ? event : null;
	if (e) {
		var num = (e.charCode) ? e.charCode : ((e.keyCode) ? e.keyCode : ((e.which) ? e.which : 0));
		if ((num >= 97 && num <= 122) || (num >= 65 && num <= 90) || (num >= 48 && num <= 57) || num == 8 || num == 9 || num == 32 || (e.key == 'Home')
				|| (e.key == 'End') || (e.key == 'Left') || (e.key == 'Right') || (e.key == 'Up') || (e.key == 'Down') || (e.key == 'Del')) {
			return true;
		} else {
			return false;
		}
	}
}

function alphaNumeric(e) {
	e = (e) ? e : (window.event) ? event : null;
	if (e) {
		var num = (e.charCode) ? e.charCode : ((e.keyCode) ? e.keyCode : ((e.which) ? e.which : 0));
		if ((num >= 97 && num <= 122) || (num >= 65 && num <= 90) || (num>=48 && num<=57) || (e.key == 'Home')
				|| (e.key == 'End') || (e.key == 'Left') || (e.key == 'Right') || (e.key == 'Up') || (e.key == 'Down') || (e.key == 'Del')) {
			return true;
		} else {
			return false;
		}
	}
}

function OnlyChar(e) {
	e = (e) ? e : (window.event) ? event : null;
	if (e) {
		var num = (e.charCode) ? e.charCode : ((e.keyCode) ? e.keyCode : ((e.which) ? e.which : 0));
		if ((num >= 97 && num <= 122) || (num >= 65 && num <= 90) || num == 8 || num == 9 || num == 32 || (e.key == 'Home') || (e.key == 'End')
				|| (e.key == 'Left') || (e.key == 'Right') || (e.key == 'Up') || (e.key == 'Down') || (e.key == 'Del') || (num == 45)) {
			return true;
		} else {
			return false;
		}
	}
}

function addressChar(e) {
		e = (e) ? e : (window.event) ? event : null;
		if (e) {
			var num = (e.charCode) ? e.charCode : ((e.keyCode) ? e.keyCode
					: ((e.which) ? e.which : 0));
			
			if ((num >= 44 && num <= 47) || (num >= 97 && num <= 122) || (num >= 65 && num <= 90) || num == 8 || num == 9 || num == 32 || (e.key == 'Home') || (e.key == 'End')
					|| (e.key == 'Left') || (e.key == 'Right') || (e.key == 'Up') || (e.key == 'Down') || (e.key == 'Del') || (num == 45)) {
				return true;
			} else {
				return false;
			}

		} else {
			return false;
		}
}

function SomeSpecial(e) {
	e = (e) ? e : (window.event) ? event : null;
	if (e) {
		/*
		 * uppercase, lowercase, numbers, Backspace, Hor Tab, dot, comma,
		 * hiphen, space, unserScore allowed
		 */
		var num = (e.charCode) ? e.charCode : ((e.keyCode) ? e.keyCode : ((e.which) ? e.which : 0));
		if ((num >= 97 && num <= 122) || (num >= 65 && num <= 90) || (num >= 48 && num <= 57) || num == 37 || num == 8 || num == 9 || num == 46 || num == 45 || num == 44
				|| num == 95 || num == 32 || (e.key == 'Home') || (e.key == 'End') || (e.key == 'Left') || (e.key == 'Right') || (e.key == 'Up')
				|| (e.key == 'Down') || (e.key == 'Del')) {
			return true;
		} else {
			return false;
		}
	}
}

function OnlyNumeric(e) {

	e = (e) ? e : (window.event) ? event : null;
	if (e) {
		/* numbers, Backspace, Hor Tab, space allowed */
		var num = (e.charCode) ? e.charCode : ((e.keyCode) ? e.keyCode : ((e.which) ? e.which : 0));
		if ((num >= 48 && num <= 57) || num == 8 || num == 9 || num == 32 || num == 46 || (e.key == 'Home') || (e.key == 'End') || (e.key == 'Left')
				|| (e.key == 'Right') || (e.key == 'Up') || (e.key == 'Down') || (e.key == 'Del')) {
			return true;
		} else {
			return false;
		}
	}
}

function PureNumeric(e) {
	
	e = (e) ? e : (window.event) ? event : null;
	if (e) {
		/* numbers, Backspace, Hor Tab, space allowed */
		var num = (e.charCode) ? e.charCode : ((e.keyCode) ? e.keyCode : ((e.which) ? e.which : 0));
		if ((num >= 48 && num <= 57) || num == 8 || num == 9 || (e.key == 'Home') || (e.key == 'End') || (e.key == 'Left')
				|| (e.key == 'Right') || (e.key == 'Up') || (e.key == 'Down') || (e.key == 'Del')) {
			return true;
		} else {
			return false;
		}
	}
}
function PureMobile(e) {
	
	e = (e) ? e : (window.event) ? event : null;
	if (e) {
		/* numbers, Backspace, Hor Tab,  allowed */
		var num = (e.charCode) ? e.charCode : ((e.keyCode) ? e.keyCode : ((e.which) ? e.which : 0));
		if ((num >= 48 && num <= 57) || num == 8 || num == 9 || (e.key == 'Home') || (e.key == 'End') || (e.key == 'Left')
				|| (e.key == 'Right') || (e.key == 'Up') || (e.key == 'Down') || (e.key == 'Del')) {
			return true;
		} else {
			return false;
		}
	}
}

function buildSelect(data, optionsOnly, key, value) {
	var response = data;
	if (!jQuery.isPlainObject(data) && !jQuery.isArray(data)) {
		response = jQuery.parseJSON(data);
	}
	var optionsArray = new Array();
	$.each(response,function(key,val){
		var optionsObj = new Object();
		optionsObj.key = key;
		optionsObj.value = val;
		optionsArray.push(optionsObj);
	});
	optionsArray = optionsArray.sort(function(a,b){
		if(((a.value).toUpperCase())==(b.value).toUpperCase()) return 0;
		else if(((a.value).toUpperCase())>(b.value).toUpperCase())return 1;
		else return -1;
	});
	var options = '';
	if (key && value) {
		for ( var k in optionsArray) {
			options += "<option value='" + optionsArray[k].value + "'>" + optionsArray[k].value + "</option>";
		}
	} else {
		for ( var key in optionsArray) {
			options += "<option value=" + optionsArray[key].key + ">" + optionsArray[key].value + "</option>";
		}
	}

	if (optionsOnly) {
		return options;
	}
	var selectOption = "<select>" + options + "</select>";
	return selectOption;
}

function minLength(value, colname) {
	if (colname == "name" && (value.length <= 2)) {
		return [ false, "name must have more than 2 chars", "" ];
	} else {
		return [ true, "", "" ];
	}
}

function isNull(a) {
	if (typeof a == "undefined") {
		return true;
	} else {
		if (a == null || a == "") {
			return true;
		} else {
			return false;
		}
	}
}

function isNotNull(a) {
	return !isNull(a);
}

function animate(el, x) {
	el.addClass(x + ' animated').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
		el.removeClass(x + ' animated');
	});
};

function getValidator(formId, options) {
	var defaults = {
		ignore : [],
		onfocusout : function(element) {
			return $(element).valid();
		},
		errorPlacement : function(error) {
			return false;
		},
		errorElement : "span",
		highlight : function(element) {
			var hasClass=$(element).next().hasClass('bootstrap-select');
			if(hasClass)element = $(element).next();
			$(element).addClass("error");
			animate($(element), 'flash');
		},
		unhighlight : function(element) {
			var hasClass=$(element).next().hasClass('bootstrap-select');
			if(hasClass)element = $(element).next();
			$(element).removeClass("error");
		}
	};
	if (!options)
		options == {};
	$.extend(options, defaults);
	var form = $(formId);
	return form.validate(options);
}

$(document).ready(function() {
	$.validator.addMethod("selectpicker", function(value, element) {
		return validateSelectPicker(element);
	}, "This field is required.");

	$.validator.methods.date = function(value, element) {
		var matches = /^(\d{2})[-\/](\d{2})[-\/](\d{4})$/.exec(value);
        return this.optional(element) || matches != null;
    };
});

function validateSelectPicker(element) {
	var selectedOptions = $(element).find("option:selected");
	console.log(selectedOptions);
	return selectedOptions != undefined;
}

function getGreenToRed(percent){
    r = percent<50 ? 165 : Math.floor(165-(percent*2-100)*165/100);
    g = percent>50 ? 165 : Math.floor((percent*2)*165/100);
    return 'rgba('+r+','+g+',0, .7)';
}

(function ( $ ) {
    $.numberWithCommas = function(x) {
    	return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    };
}( jQuery ));

(function ( $ ) {
	$.isValidURL = function(urlToCheck) {
		// Below regular expression can validate input URL with or without http:// etc
	    var pattern = new RegExp("^((http|https|ftp)\://)*([a-zA-Z0-9\.\-]+(\:[a-zA-Z0-9\.&%\$\-]+)*@)*((25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])|([a-zA-Z0-9\-]+\.)*[a-zA-Z0-9\-]+\.(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|[a-zA-Z]{2}))(\:[0-9]+)*(/($|[a-zA-Z0-9\.\,\?\'\\\+&%\$#\=~_\-]+))*$");
	    return pattern.test(urlToCheck);
	};
}( jQuery ));

(function ( $ ) {
	$.isNotValidURL = function(urlToCheck) {
		return !($.isValidURL(urlToCheck));
	};
}( jQuery ));

/**remove duplicate values for array*/
(function ( $ ) {
	$.unique = function(names) {
		var uniqueNames = [];
		$.each(names, function(i, el){
			if($.inArray(el, uniqueNames) === -1) uniqueNames.push(el);
		});
		return uniqueNames;		
	};
}( jQuery ));

/**sort the Number in array*/
function sortNumber(a,b) {
    return a - b;
}

/**sort the field with key as input in array*/
function keysrt(key,desc) {
	  return function(a,b){
	   return desc ? ~~(a[key] < b[key]) : ~~(a[key] > b[key]);
	  }
	}
