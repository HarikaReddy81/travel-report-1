﻿
function FetchRefund(ChkPNRNoID, Amt) 
{
    var RefundAmtID = document.getElementById('ctl00_sitecontent_lblTotalRefund');
    
    var TotalAmount = parseFloat(RefundAmtID.innerHTML);

    if (document.getElementById(ChkPNRNoID).checked == true) 
    {
        TotalAmount = TotalAmount + parseFloat(Amt);
    }
    else if (document.getElementById(ChkPNRNoID).checked == false) 
    {
        TotalAmount = TotalAmount - parseFloat(Amt);
    }
   RefundAmtID.innerHTML = TotalAmount;
}